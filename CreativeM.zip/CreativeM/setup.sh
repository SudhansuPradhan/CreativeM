#!/bin/bash
# CreativeM Studio - one-time project setup.
#
# This script turns the hand-written Swift sources + project.yml in this
# folder into an openable Xcode project. It does NOT compile anything on
# its own initiative that requires your password - if the Xcode license
# hasn't been accepted yet, it stops and tells you the exact command to run.
set -euo pipefail
cd "$(dirname "$0")"

echo "==> Checking Xcode license..."
if ! /usr/bin/xcrun --show-sdk-path --sdk macosx >/dev/null 2>&1; then
  echo ""
  echo "Xcode's license has not been accepted yet on this Mac."
  echo "Run this once (needs your account password), then re-run ./setup.sh:"
  echo ""
  echo "    sudo xcodebuild -license accept"
  echo ""
  exit 1
fi
echo "    OK"

echo "==> Checking for XcodeGen..."
if ! command -v xcodegen >/dev/null 2>&1; then
  echo "    Not found. Installing via Homebrew (brew install xcodegen)..."
  if ! command -v brew >/dev/null 2>&1; then
    echo "Homebrew is required. Install it from https://brew.sh and re-run this script."
    exit 1
  fi
  brew install xcodegen
fi
echo "    OK ($(xcodegen version 2>/dev/null || echo installed))"

echo "==> Generating CreativeM.xcodeproj..."
xcodegen generate

echo "==> Done."
echo ""
echo "Next steps:"
echo "    open CreativeM.xcodeproj"
echo "  then press Cmd+R to build and run."
echo ""
echo "First run checklist:"
echo "  - Grant Camera / Microphone access when macOS prompts you."
echo "  - The first time you click 'Record Screen', macOS will ask you to enable"
echo "    Screen Recording for CreativeM in System Settings > Privacy & Security,"
echo "    then you'll need to quit and relaunch the app once."
