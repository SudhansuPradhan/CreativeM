# CreativeM Studio

A native macOS audio/video editor: record camera, microphone, and screen; edit on a
multi-track timeline; grade with speed/transform/transitions/titles/audio mixing; add
on-device auto-captions; export to the presets people actually need (YouTube, Reels,
ProRes master, audio-only).

Built entirely with Swift/SwiftUI + AVFoundation/ScreenCaptureKit/Speech - no third-party
dependencies, no telemetry, no cloud processing.

## ⚠️ Before anything else: this has not been compiled yet

Every file here was written by hand against Apple's documented AVFoundation/
ScreenCaptureKit/Speech/SwiftUI APIs, but **this Mac's Xcode license was not accepted
during development**, which blocked `xcodegen`, `xcodebuild`, and every other local
build tool. That means: **no line of this project has been compiled or run this
session.** It is real, complete, from-scratch source - not a mockup - but treat the
first build like a first draft that needs a compiler pass.

If `./setup.sh` or your first build in Xcode throws errors, paste them back and they
can be fixed quickly - Swift/AVFoundation API mistakes (a renamed parameter, a slightly
wrong overload) are normally a one-line fix each once the compiler points at them.

## Setup

1. **Accept the Xcode license once** (one-time, needs your account password):
   ```bash
   sudo xcodebuild -license accept
   ```
2. Run the setup script from this folder. It installs [XcodeGen](https://github.com/yonaskolb/XcodeGen)
   via Homebrew if needed, then generates the `.xcodeproj` from `project.yml`:
   ```bash
   ./setup.sh
   ```
3. Open and run:
   ```bash
   open CreativeM.xcodeproj
   ```
   Press **Cmd+R** in Xcode.

### First-run permission checklist
- Grant **Camera** / **Microphone** access when prompted (needed for camera+mic recording).
- The first time you click **Record Screen**, macOS will ask you to enable **Screen
  Recording** for CreativeM in **System Settings → Privacy & Security**. You'll need to
  quit and relaunch the app once after granting it.
- The first time you click **Generate Captions**, macOS will ask for **Speech
  Recognition** access. Transcription runs fully on-device - audio never leaves the Mac.

The app is unsandboxed (see [Known limitations](#known-limitations-and-roadmap)), so it
can read/write media anywhere on disk without security-scoped bookmarks.

## Features

### Record
- **Camera + microphone**, with device pickers for both, live elapsed-time readout, and
  one-click "insert onto the timeline when you stop" (`Capture/CameraMicRecorder.swift`).
- **Screen recording** via ScreenCaptureKit, with per-display selection and an optional
  "include system audio" toggle (`Capture/ScreenRecorder.swift`).
- Recordings land in `~/Library/Application Support/CreativeM Studio/Recordings` and are
  auto-imported onto the video track when you stop.

### Edit
- Multi-track timeline: one video track, one title track, and any number of audio
  tracks (add more from the toolbar); drag to move, drag the clip edges to trim, split
  at playhead, delete (leaves a gap - the model layer also supports ripple-delete, but
  it isn't wired to a UI control yet).
- **Cross-dissolve transitions** between adjacent clips on a track, with a duration
  clamped to never eat more than 90% of the earlier clip.
- **Speed ramping** per clip (0.1x-4x) that correctly retimes both picture and embedded
  audio.
- **Transform** per video clip: scale, X/Y position, rotation - for simple picture-in-
  picture-style framing and reframing.
- **Titles/lower-thirds**: editable text, position (top/center/bottom), font size,
  color, background opacity, burned in via Core Animation at export and in preview.
- **Audio mixing**: per-clip volume, mute, fade-in/out; per-track volume; **auto-ducking**
  - mark a track (e.g. Music) as a duck target and another (e.g. Dialogue) as the
    ducking trigger, and music automatically dips under voice.
- Snapping while dragging clips (to the playhead, and to neighboring clip edges).
- Ripple-safe editing: embedded clip audio is tracked on alternating A/B composition
  tracks so overlapping cross-dissolves never corrupt previously-placed audio.
- Full **undo/redo** (Cmd-Z / Shift-Cmd-Z) via whole-project snapshots - every edit is
  undoable, including caption edits and track/ducking toggles.
- Autosave every 60 seconds to a scratch location whenever the project is dirty.

### Captions
- **On-device auto-captions**: renders a temporary audio mixdown of your whole timeline
  (so multi-clip timelines transcribe in sync), then transcribes it with
  `SFSpeechRecognizer` in on-device mode - no network round-trip, no server.
  (`Captions/CaptionsKit.swift`)
- Editable caption list: fix text, nudge start/end times, add/delete lines.
- Optional **burn-in** (rendered into the picture, in preview and export) in addition to
  **`.srt` export** for YouTube/social platforms.

### Export
- Preset catalog covering the cases people actually hit
  (`Export/ExportManager.swift`): 1080p H.264, 4K H.264, **vertical 9:16** (Reels/TikTok/
  Shorts), **square 1:1** (Instagram feed), **ProRes 422** (editing master / handoff),
  and **audio-only M4A**.
- Live progress bar with cancel.
- Optional simultaneous `.srt` export alongside the video.

### Project files
- `.cmproj` is a plain folder (`project.json` + cached `Thumbnails/`/`Waveforms/`) - open
  it, inspect it, back it up with any tool, no proprietary binary format.
- Media is referenced by path, not copied, so projects stay small.

## Keyboard shortcuts

| Shortcut | Action |
|---|---|
| Space | Play / Pause |
| S | Split clip at playhead |
| Delete / Forward-Delete | Delete selected clip |
| Cmd+N | New project |
| Cmd+O | Open project |
| Cmd+S | Save project |
| Shift+Cmd+S | Save project as... |
| Cmd+E | Export... |
| Cmd+Z | Undo |
| Shift+Cmd+Z | Redo |
| Cmd+K | Split at playhead (menu) |
| Cmd+Delete | Delete clip (menu) |
| Cmd+T | Add title clip |
| Shift+Cmd+G | Generate captions |
| Cmd+R | Record camera + mic |
| Shift+Cmd+R | Record screen |

Space/S/Delete work anywhere in the main window (guarded so they don't fire while
you're typing in a text field); the rest live in the menu bar.

## Architecture

```
CreativeM/
  App/            AppState (single @MainActor source of truth) + @main App/menus
  Models/         Codable value types: Project, Track, Clip, MediaAsset, CaptionSegment...
  Capture/        CameraMicRecorder (AVCaptureSession), ScreenRecorder (ScreenCaptureKit)
  Media/          Import, thumbnail generation, waveform peak extraction
  Timeline/       TimelineEngine (Project -> AVMutableComposition/VideoComposition/AudioMix)
                  TimelineViewModel (all editing operations, undo-aware)
  Captions/       SFSpeechRecognizer wrapper + .srt writer
  Export/         ExportPreset catalog + AVAssetExportSession-based ExportManager
  Persistence/    .cmproj save/open/autosave
  UI/             SwiftUI views (timeline, inspector, media library, preview, sheets)
  Utilities/      Paths, time formatting, color hex, key-event monitor
```

**Data flow:** every edit goes through `AppState.performEdit`/`setProject`, which
snapshots the previous `Project` for undo, marks the project dirty, and recompiles the
preview by rebuilding an `AVMutableComposition` from scratch via `TimelineEngine`. This
"rebuild the whole composition on every structural edit" approach trades a small amount
of CPU for a much simpler, much harder-to-corrupt mental model than incrementally
patching a persistent composition object.

**Why no custom compositor/filters:** color grading, chroma key, and spectral noise
reduction all need either a custom `AVVideoCompositing`/Core Image filter pipeline or a
DSP library. Those are exactly the subsystems most likely to contain a subtle, hard-to-
spot bug when written without a compiler to check them against - so this pass
deliberately kept the feature set to things buildable with high-confidence, well-
established AVFoundation APIs, and left the riskier subsystems as a documented roadmap
(below) rather than shipping unverified custom compositing code.

## Known limitations and roadmap

Not implemented yet - by design, to keep this pass's surface area buildable with high
confidence:

- **Color grading** (LUTs, curves, saturation/contrast/exposure) - needs a Core Image
  filter pipeline wired into a custom `AVVideoCompositing` class.
- **`.cube` LUT import** - depends on the above.
- **Chroma key / green screen** - same custom-compositor dependency.
- **Spectral noise reduction / audio cleanup** - needs a DSP pass (e.g. `vDSP`/Accelerate)
  beyond `AVAudioMix` volume automation.
- **GIF export** - needs `ImageIO`/`CGImageDestination` frame-sequence export, not just
  `AVAssetExportSession`.
- **Multiple simultaneous video tracks / true picture-in-picture compositing** - the
  current video composition supports one active video clip at a time (plus titles);
  layered video-over-video needs a second `AVMutableVideoCompositionLayerInstruction`
  per overlapping clip.
- **App Sandbox, Developer ID signing, and notarization** - currently unsandboxed
  (`ENABLE_HARDENED_RUNTIME: NO`, `com.apple.security.app-sandbox: false` in
  `project.yml`) to avoid entitlement/security-scoped-bookmark complexity while
  unverified; needed before any distribution outside your own Mac.
- **Finder package registration for `.cmproj`** - it's a plain folder today, not a
  UTI-registered document type, so Finder won't show a custom icon or "Open With"
  CreativeM automatically.

None of these are stubbed out with fake UI - they simply aren't present, so the app
never claims to do something it can't.

## Tech stack

Swift 5.10 - SwiftUI (macOS 15+) - AVFoundation - ScreenCaptureKit - Speech - AppKit
interop (`NSSavePanel`/`NSOpenPanel`) - [XcodeGen](https://github.com/yonaskolb/XcodeGen)
for project generation (`project.yml` is the source of truth; the `.xcodeproj` itself is
git-ignored and regenerated by `./setup.sh`).
