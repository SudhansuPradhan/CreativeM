import AVFoundation
import Combine
import CoreVideo
import Foundation
import ScreenCaptureKit

enum ScreenRecorderError: LocalizedError {
    case noDisplay
    case notRunning

    var errorDescription: String? {
        switch self {
        case .noDisplay: return "No display was available to record."
        case .notRunning: return "Screen recording is not currently running."
        }
    }
}

/// Records a display (optionally with system audio) via ScreenCaptureKit, muxing
/// frames straight to disk with `AVAssetWriter`. Microphone narration is recorded
/// separately with `CameraMicRecorder` and lands on the timeline as its own clip -
/// this keeps the writer pipeline here simple and avoids needing newer,
/// less-battle-tested ScreenCaptureKit microphone-mixing APIs.
final class ScreenRecorder: NSObject, ObservableObject {
    @Published private(set) var isRunning = false
    @Published private(set) var elapsedSeconds: TimeInterval = 0
    @Published var lastError: String?
    @Published private(set) var availableDisplays: [SCDisplay] = []
    @Published var selectedDisplayID: CGDirectDisplayID?
    @Published var includeSystemAudio: Bool = true

    private var stream: SCStream?
    private var assetWriter: AVAssetWriter?
    private var videoInput: AVAssetWriterInput?
    private var audioInput: AVAssetWriterInput?
    private var sessionStarted = false
    private let writerQueue = DispatchQueue(label: "com.creativem.studio.screenWriter")
    private var timer: Timer?
    private var startDate: Date?
    private var pendingOutputURL: URL?

    /// Call once (e.g. when the recording sheet appears) to populate `availableDisplays`.
    /// This is also what triggers the macOS "Screen Recording" permission prompt the
    /// first time it's called for this app.
    func refreshDisplays() async {
        do {
            let content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
            self.availableDisplays = content.displays
            if self.selectedDisplayID == nil {
                self.selectedDisplayID = content.displays.first?.displayID
            }
        } catch {
            self.lastError = error.localizedDescription
        }
    }

    func start(outputURL: URL) async throws {
        let content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
        guard let display = content.displays.first(where: { $0.displayID == selectedDisplayID }) ?? content.displays.first else {
            throw ScreenRecorderError.noDisplay
        }

        let filter = SCContentFilter(display: display, excludingWindows: [])
        let config = SCStreamConfiguration()
        config.width = display.width
        config.height = display.height
        config.minimumFrameInterval = CMTime(value: 1, timescale: 60)
        config.showsCursor = true
        config.pixelFormat = kCVPixelFormatType_32BGRA
        config.capturesAudio = includeSystemAudio
        config.sampleRate = 48000
        config.channelCount = 2

        let writer = try AVAssetWriter(outputURL: outputURL, fileType: .mov)

        let videoSettings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: config.width,
            AVVideoHeightKey: config.height,
        ]
        let vInput = AVAssetWriterInput(mediaType: .video, outputSettings: videoSettings)
        vInput.expectsMediaDataInRealTime = true
        if writer.canAdd(vInput) { writer.add(vInput) }

        var aInput: AVAssetWriterInput?
        if includeSystemAudio {
            let audioSettings: [String: Any] = [
                AVFormatIDKey: kAudioFormatMPEG4AAC,
                AVSampleRateKey: 48_000,
                AVNumberOfChannelsKey: 2,
                AVEncoderBitRateKey: 128_000,
            ]
            let a = AVAssetWriterInput(mediaType: .audio, outputSettings: audioSettings)
            a.expectsMediaDataInRealTime = true
            if writer.canAdd(a) { writer.add(a) }
            aInput = a
        }

        assetWriter = writer
        videoInput = vInput
        audioInput = aInput
        sessionStarted = false
        pendingOutputURL = outputURL

        let stream = SCStream(filter: filter, configuration: config, delegate: self)
        try stream.addStreamOutput(self, type: .screen, sampleHandlerQueue: writerQueue)
        if includeSystemAudio {
            try stream.addStreamOutput(self, type: .audio, sampleHandlerQueue: writerQueue)
        }
        self.stream = stream
        try await stream.startCapture()

        isRunning = true
        startDate = Date()
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { [weak self] _ in
            guard let self, let start = self.startDate else { return }
            self.elapsedSeconds = Date().timeIntervalSince(start)
        }
    }

    @discardableResult
    func stop() async throws -> URL {
        guard let stream, let writer = assetWriter, let url = pendingOutputURL else {
            throw ScreenRecorderError.notRunning
        }
        try await stream.stopCapture()
        self.stream = nil

        videoInput?.markAsFinished()
        audioInput?.markAsFinished()

        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            writer.finishWriting {
                continuation.resume()
            }
        }

        isRunning = false
        timer?.invalidate()
        timer = nil
        elapsedSeconds = 0
        pendingOutputURL = nil

        return url
    }
}

extension ScreenRecorder: SCStreamDelegate {
    func stream(_ stream: SCStream, didStopWithError error: Error) {
        DispatchQueue.main.async {
            self.lastError = error.localizedDescription
            self.isRunning = false
        }
    }
}

extension ScreenRecorder: SCStreamOutput {
    func stream(_ stream: SCStream, didOutputSampleBuffer sampleBuffer: CMSampleBuffer, of type: SCStreamOutputType) {
        guard sampleBuffer.isValid, let writer = assetWriter else { return }

        if !sessionStarted {
            guard writer.status == .unknown else { return }
            writer.startWriting()
            writer.startSession(atSourceTime: CMSampleBufferGetPresentationTimeStamp(sampleBuffer))
            sessionStarted = true
        }

        guard writer.status == .writing else { return }

        switch type {
        case .screen:
            if let input = videoInput, input.isReadyForMoreMediaData {
                input.append(sampleBuffer)
            }
        case .audio:
            if let input = audioInput, input.isReadyForMoreMediaData {
                input.append(sampleBuffer)
            }
        @unknown default:
            break
        }
    }
}
