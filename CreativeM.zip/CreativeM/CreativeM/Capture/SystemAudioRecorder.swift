import AVFoundation
import Combine
import CoreVideo
import Foundation
import ScreenCaptureKit

enum SystemAudioRecorderError: LocalizedError {
    case noDisplay
    case notRunning
    case noAudioCaptured

    var errorDescription: String? {
        switch self {
        case .noDisplay: return "No display was available to start system audio capture."
        case .notRunning: return "System audio recording is not currently running."
        case .noAudioCaptured: return "No audio was captured - make sure something was actually playing, then try again."
        }
    }
}

/// Records "whatever's currently playing" on the Mac (e.g. a YouTube tab, Music,
/// Zoom) to an AAC file, via the same ScreenCaptureKit audio tap `ScreenRecorder`
/// uses for its "Include System Audio" toggle - just without ever compositing or
/// writing a video track. ScreenCaptureKit still requires an `SCContentFilter`
/// anchored to a display even for audio-only capture, but which display is chosen
/// is irrelevant here: with `capturesAudio = true` the stream taps the whole
/// system audio mix, not just audio from windows on that display.
///
/// This reuses the "Screen Recording" TCC permission (there's no separate
/// Info.plist usage-description key for it - same as `ScreenRecorder`).
final class SystemAudioRecorder: NSObject, ObservableObject {
    @Published private(set) var isRunning = false
    @Published private(set) var elapsedSeconds: TimeInterval = 0
    @Published var lastError: String?

    private var stream: SCStream?
    private var assetWriter: AVAssetWriter?
    private var audioInput: AVAssetWriterInput?
    private var sessionStarted = false
    private let writerQueue = DispatchQueue(label: "com.creativem.studio.systemAudioWriter")
    private var timer: Timer?
    private var startDate: Date?
    private var pendingOutputURL: URL?

    func start(outputURL: URL) async throws {
        let content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
        guard let display = content.displays.first else {
            throw SystemAudioRecorderError.noDisplay
        }

        let filter = SCContentFilter(display: display, excludingWindows: [])
        let config = SCStreamConfiguration()
        // Smallest legal frame size - some ScreenCaptureKit builds reject anything
        // under 16x16. We never register a `.screen` stream output below, so this
        // video buffer is allocated but never read or encoded.
        config.width = 16
        config.height = 16
        config.minimumFrameInterval = CMTime(value: 1, timescale: 1)
        config.capturesAudio = true
        config.sampleRate = 48000
        config.channelCount = 2
        // Without this, our own app's audio (preview playback) gets captured too,
        // which is a feedback loop a user would hit on their very first attempt if
        // they're scrubbing the timeline while recording.
        config.excludesCurrentProcessAudio = true

        let writer = try AVAssetWriter(outputURL: outputURL, fileType: .m4a)
        let audioSettings: [String: Any] = [
            AVFormatIDKey: kAudioFormatMPEG4AAC,
            AVSampleRateKey: 48_000,
            AVNumberOfChannelsKey: 2,
            AVEncoderBitRateKey: 192_000,
        ]
        let aInput = AVAssetWriterInput(mediaType: .audio, outputSettings: audioSettings)
        aInput.expectsMediaDataInRealTime = true
        if writer.canAdd(aInput) { writer.add(aInput) }

        assetWriter = writer
        audioInput = aInput
        sessionStarted = false
        pendingOutputURL = outputURL

        let stream = SCStream(filter: filter, configuration: config, delegate: self)
        // Only the audio output type is registered - no `.screen` handler at all.
        try stream.addStreamOutput(self, type: .audio, sampleHandlerQueue: writerQueue)
        self.stream = stream
        try await stream.startCapture()

        isRunning = true
        startDate = Date()
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { [weak self] _ in
            guard let self, let start = self.startDate else { return }
            self.elapsedSeconds = Date().timeIntervalSince(start)
        }
    }

    @discardableResult
    func stop() async throws -> URL {
        guard let stream, let writer = assetWriter, let url = pendingOutputURL else {
            throw SystemAudioRecorderError.notRunning
        }
        try await stream.stopCapture()
        self.stream = nil

        isRunning = false
        timer?.invalidate()
        timer = nil
        elapsedSeconds = 0
        pendingOutputURL = nil

        // If no sample buffer ever arrived (nothing was playing, or Stop landed
        // before the first buffer did), `writer` never left `.unknown` -
        // `finishWriting` requires `.writing`, so finish safely via
        // `cancelWriting()` instead of risking an invalid-state call, and surface a
        // clear reason rather than a confusing failure from a zero-length file.
        guard sessionStarted else {
            writer.cancelWriting()
            throw SystemAudioRecorderError.noAudioCaptured
        }

        audioInput?.markAsFinished()
        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            writer.finishWriting {
                continuation.resume()
            }
        }

        return url
    }
}

extension SystemAudioRecorder: SCStreamDelegate {
    func stream(_ stream: SCStream, didStopWithError error: Error) {
        DispatchQueue.main.async {
            self.lastError = error.localizedDescription
            self.isRunning = false
        }
    }
}

extension SystemAudioRecorder: SCStreamOutput {
    func stream(_ stream: SCStream, didOutputSampleBuffer sampleBuffer: CMSampleBuffer, of type: SCStreamOutputType) {
        guard type == .audio, sampleBuffer.isValid, let writer = assetWriter, let input = audioInput else { return }

        if !sessionStarted {
            guard writer.status == .unknown else { return }
            writer.startWriting()
            writer.startSession(atSourceTime: CMSampleBufferGetPresentationTimeStamp(sampleBuffer))
            sessionStarted = true
        }

        guard writer.status == .writing, input.isReadyForMoreMediaData else { return }
        input.append(sampleBuffer)
    }
}
