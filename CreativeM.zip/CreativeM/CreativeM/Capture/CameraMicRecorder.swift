import AVFoundation
import Combine
import Foundation

/// Records webcam + microphone straight to a QuickTime movie file.
/// All `AVCaptureSession` configuration/start/stop calls are funneled through a
/// private serial queue, per Apple's guidance that `startRunning()` can block.
final class CameraMicRecorder: NSObject, ObservableObject {
    @Published private(set) var isSessionRunning = false
    @Published private(set) var isRecording = false
    @Published private(set) var elapsedSeconds: TimeInterval = 0
    @Published var lastError: String?
    @Published private(set) var availableCameras: [AVCaptureDevice] = []
    @Published private(set) var availableMicrophones: [AVCaptureDevice] = []
    @Published var selectedCameraID: String?
    @Published var selectedMicrophoneID: String?

    let session = AVCaptureSession()
    private let movieOutput = AVCaptureMovieFileOutput()
    private let sessionQueue = DispatchQueue(label: "com.creativem.studio.cameraSession")
    private var timer: Timer?
    private var recordingStartDate: Date?
    private var completion: ((Result<URL, Error>) -> Void)?

    override init() {
        super.init()
        refreshDevices()
    }

    // MARK: Devices & permissions

    func refreshDevices() {
        let cameraTypes: [AVCaptureDevice.DeviceType] = [.builtInWideAngleCamera, .external, .continuityCamera]
        availableCameras = AVCaptureDevice.DiscoverySession(deviceTypes: cameraTypes, mediaType: .video, position: .unspecified).devices
        availableMicrophones = AVCaptureDevice.DiscoverySession(deviceTypes: [.microphone], mediaType: .audio, position: .unspecified).devices
        if selectedCameraID == nil { selectedCameraID = availableCameras.first?.uniqueID }
        if selectedMicrophoneID == nil { selectedMicrophoneID = availableMicrophones.first?.uniqueID }
    }

    /// Prompts for camera + mic access if not already determined. Safe to call repeatedly.
    func requestPermissions() async -> Bool {
        let videoOK = await AVCaptureDevice.requestAccess(for: .video)
        let audioOK = await AVCaptureDevice.requestAccess(for: .audio)
        return videoOK && audioOK
    }

    // MARK: Session lifecycle

    func startSession() {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            self.session.beginConfiguration()
            self.session.sessionPreset = .high
            for input in self.session.inputs { self.session.removeInput(input) }
            for output in self.session.outputs { self.session.removeOutput(output) }

            if let cameraID = self.selectedCameraID,
               let camera = self.availableCameras.first(where: { $0.uniqueID == cameraID }),
               let input = try? AVCaptureDeviceInput(device: camera),
               self.session.canAddInput(input) {
                self.session.addInput(input)
            }
            if let micID = self.selectedMicrophoneID,
               let mic = self.availableMicrophones.first(where: { $0.uniqueID == micID }),
               let input = try? AVCaptureDeviceInput(device: mic),
               self.session.canAddInput(input) {
                self.session.addInput(input)
            }
            if self.session.canAddOutput(self.movieOutput) {
                self.session.addOutput(self.movieOutput)
            }
            self.session.commitConfiguration()

            if !self.session.isRunning {
                self.session.startRunning()
            }
            DispatchQueue.main.async { self.isSessionRunning = true }
        }
    }

    func stopSession() {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.session.isRunning {
                self.session.stopRunning()
            }
            DispatchQueue.main.async { self.isSessionRunning = false }
        }
    }

    // MARK: Recording

    func startRecording(to url: URL, completion: @escaping (Result<URL, Error>) -> Void) {
        self.completion = completion
        sessionQueue.async { [weak self] in
            guard let self else { return }
            self.movieOutput.startRecording(to: url, recordingDelegate: self)
        }
        recordingStartDate = Date()
        isRecording = true
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { [weak self] _ in
            guard let self, let start = self.recordingStartDate else { return }
            self.elapsedSeconds = Date().timeIntervalSince(start)
        }
    }

    func stopRecording() {
        sessionQueue.async { [weak self] in
            self?.movieOutput.stopRecording()
        }
        timer?.invalidate()
        timer = nil
    }
}

extension CameraMicRecorder: AVCaptureFileOutputRecordingDelegate {
    func fileOutput(
        _ output: AVCaptureFileOutput,
        didFinishRecordingTo outputFileURL: URL,
        from connections: [AVCaptureConnection],
        error: Error?
    ) {
        DispatchQueue.main.async {
            self.isRecording = false
            self.elapsedSeconds = 0
            if let error {
                self.lastError = error.localizedDescription
                self.completion?(.failure(error))
            } else {
                self.completion?(.success(outputFileURL))
            }
            self.completion = nil
        }
    }
}
