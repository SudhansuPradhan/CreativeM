import AVFoundation
import Combine
import Foundation

enum MicRecorderError: LocalizedError {
    case didNotStart

    var errorDescription: String? {
        switch self {
        case .didNotStart: return "Recording didn't start - check that a microphone is connected."
        }
    }
}

/// Records microphone-only audio to an AAC `.m4a` file via `AVCaptureAudioFileOutput` -
/// the audio-only sibling of `AVCaptureMovieFileOutput` (which `CameraMicRecorder` uses).
/// Same `AVCaptureSession` + serial-queue pattern as `CameraMicRecorder`, just with no
/// camera input and no video connection at all - no camera light, no video file.
///
/// Captured audio is always dry/unprocessed. A chosen `MicVoicePreset` is applied
/// afterward, non-destructively, through the same `AudioEffects` pipeline every other
/// clip uses - see `AppState.startMicRecording`.
final class MicRecorder: NSObject, ObservableObject {
    @Published private(set) var isSessionRunning = false
    @Published private(set) var isRecording = false
    @Published private(set) var elapsedSeconds: TimeInterval = 0
    @Published var lastError: String?
    @Published private(set) var availableMicrophones: [AVCaptureDevice] = []
    @Published var selectedMicrophoneID: String?

    let session = AVCaptureSession()
    private let audioFileOutput = AVCaptureAudioFileOutput()
    private let sessionQueue = DispatchQueue(label: "com.creativem.studio.micSession")
    private var timer: Timer?
    private var recordingStartDate: Date?
    private var completion: ((Result<URL, Error>) -> Void)?

    override init() {
        super.init()
        refreshDevices()
    }

    // MARK: Devices & permissions

    func refreshDevices() {
        availableMicrophones = AVCaptureDevice.DiscoverySession(deviceTypes: [.microphone], mediaType: .audio, position: .unspecified).devices
        if selectedMicrophoneID == nil { selectedMicrophoneID = availableMicrophones.first?.uniqueID }
    }

    func requestPermissions() async -> Bool {
        await AVCaptureDevice.requestAccess(for: .audio)
    }

    // MARK: Session lifecycle

    func startSession() {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            self.session.beginConfiguration()
            for input in self.session.inputs { self.session.removeInput(input) }
            for output in self.session.outputs { self.session.removeOutput(output) }

            if let micID = self.selectedMicrophoneID,
               let mic = self.availableMicrophones.first(where: { $0.uniqueID == micID }),
               let input = try? AVCaptureDeviceInput(device: mic),
               self.session.canAddInput(input) {
                self.session.addInput(input)
            }
            // Deliberately omits AVSampleRateKey/AVNumberOfChannelsKey (unlike
            // `SystemAudioRecorder`, which taps an already-stereo system mix at a known
            // rate): most mics - including the built-in one - report mono, and forcing
            // a channel-count conversion here is a real runtime failure risk, not just
            // a quality tradeoff. Only the codec is pinned; rate/channels pass through
            // as whatever the selected mic natively provides.
            self.audioFileOutput.audioSettings = [
                AVFormatIDKey: kAudioFormatMPEG4AAC,
                AVEncoderBitRateKey: 128_000,
            ]
            if self.session.canAddOutput(self.audioFileOutput) {
                self.session.addOutput(self.audioFileOutput)
            }
            self.session.commitConfiguration()

            if !self.session.isRunning {
                self.session.startRunning()
            }
            DispatchQueue.main.async { self.isSessionRunning = true }
        }
    }

    func stopSession() {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.session.isRunning {
                self.session.stopRunning()
            }
            DispatchQueue.main.async { self.isSessionRunning = false }
        }
    }

    // MARK: Recording

    func startRecording(to url: URL, completion: @escaping (Result<URL, Error>) -> Void) {
        self.completion = completion
        sessionQueue.async { [weak self] in
            guard let self else { return }
            self.audioFileOutput.startRecording(to: url, outputFileType: .m4a, recordingDelegate: self)
        }
        recordingStartDate = Date()
        isRecording = true
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { [weak self] _ in
            guard let self, let start = self.recordingStartDate else { return }
            self.elapsedSeconds = Date().timeIntervalSince(start)
        }
    }

    func stopRecording() {
        sessionQueue.async { [weak self] in
            guard let self else { return }
            if self.audioFileOutput.isRecording {
                // The delegate's `didFinishRecordingTo` tears down the session once the
                // file is actually finalized - see that method's doc comment.
                self.audioFileOutput.stopRecording()
            } else {
                // Nothing was actually recording (start raced an immediate stop, or
                // `startRecording` never got a chance to begin) - `stopRecording()` on
                // the file output would be a silent no-op and the delegate would never
                // fire, leaving the mic session running AND the UI stuck mid-"recording"
                // (button, timer) with nothing left to ever resolve `completion`. Tear
                // down and resolve everything here instead.
                self.stopSession()
                DispatchQueue.main.async {
                    self.isRecording = false
                    self.elapsedSeconds = 0
                    let error = MicRecorderError.didNotStart
                    self.lastError = error.errorDescription
                    self.completion?(.failure(error))
                    self.completion = nil
                }
            }
        }
        timer?.invalidate()
        timer = nil
    }
}

extension MicRecorder: AVCaptureFileOutputRecordingDelegate {
    func fileOutput(
        _ output: AVCaptureFileOutput,
        didFinishRecordingTo outputFileURL: URL,
        from connections: [AVCaptureConnection],
        error: Error?
    ) {
        // `stopRecording()` only requests a stop - the file isn't actually finalized
        // until this delegate method fires. The session is only ever running while a
        // recording is in flight (see `AppState.startMicRecording`/`stopMicRecording`),
        // so it's safe - and correct - to tear it down here instead of right after the
        // `stopRecording()` call, which would race the tail of the file still flushing.
        stopSession()
        DispatchQueue.main.async {
            self.isRecording = false
            self.elapsedSeconds = 0
            if let error {
                self.lastError = error.localizedDescription
                self.completion?(.failure(error))
            } else {
                self.completion?(.success(outputFileURL))
            }
            self.completion = nil
        }
    }
}
