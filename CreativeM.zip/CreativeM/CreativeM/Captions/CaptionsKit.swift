import AVFoundation
import Foundation
import Speech

/// Everything caption-related lives in this one file behind a small protocol, so the
/// (comparatively less battle-tested) `Speech` framework integration can be swapped
/// out or stubbed without touching the timeline/export code that consumes its output.
protocol SpeechTranscribing {
    func transcribe(assetURL: URL, locale: Locale) async throws -> [CaptionSegment]
}

enum SpeechTranscriptionError: LocalizedError {
    case notAuthorized
    case recognizerUnavailable
    case noResult

    var errorDescription: String? {
        switch self {
        case .notAuthorized:
            return "Speech recognition access wasn't granted. Enable it in System Settings > Privacy & Security > Speech Recognition."
        case .recognizerUnavailable:
            return "Speech recognition isn't available for this language on this Mac right now."
        case .noResult:
            return "Couldn't detect any speech in the audio."
        }
    }
}

/// Transcribes a rendered audio file entirely on-device via `SFSpeechRecognizer`,
/// then groups the word-level results into short caption lines.
final class OnDeviceSpeechTranscriber: SpeechTranscribing {
    func transcribe(assetURL: URL, locale: Locale = Locale(identifier: "en-US")) async throws -> [CaptionSegment] {
        let status = await Self.requestAuthorization()
        guard status == .authorized else { throw SpeechTranscriptionError.notAuthorized }

        guard let recognizer = SFSpeechRecognizer(locale: locale), recognizer.isAvailable else {
            throw SpeechTranscriptionError.recognizerUnavailable
        }

        let request = SFSpeechURLRecognitionRequest(url: assetURL)
        request.shouldReportPartialResults = false
        if recognizer.supportsOnDeviceRecognition {
            request.requiresOnDeviceRecognition = true
        }

        return try await withCheckedThrowingContinuation { continuation in
            var didResume = false
            recognizer.recognitionTask(with: request) { result, error in
                if let error {
                    if !didResume {
                        didResume = true
                        continuation.resume(throwing: error)
                    }
                    return
                }
                guard let result, result.isFinal else { return }
                if didResume { return }
                didResume = true
                let segments = Self.groupIntoCaptionLines(segments: result.bestTranscription.segments)
                if segments.isEmpty {
                    continuation.resume(throwing: SpeechTranscriptionError.noResult)
                } else {
                    continuation.resume(returning: segments)
                }
            }
        }
    }

    private static func requestAuthorization() async -> SFSpeechRecognizerAuthorizationStatus {
        await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { status in
                continuation.resume(returning: status)
            }
        }
    }

    /// Buckets word-level segments into short (~8 word) caption lines, which reads far
    /// better on-screen than one giant line per sentence.
    private static func groupIntoCaptionLines(segments: [SFTranscriptionSegment], wordsPerLine: Int = 8) -> [CaptionSegment] {
        var lines: [CaptionSegment] = []
        var buffer: [SFTranscriptionSegment] = []

        func flush() {
            guard let first = buffer.first, let last = buffer.last else { return }
            let text = buffer.map(\.substring).joined(separator: " ")
            lines.append(CaptionSegment(
                text: text,
                start: CodableTime(seconds: first.timestamp),
                end: CodableTime(seconds: last.timestamp + last.duration)
            ))
            buffer.removeAll()
        }

        for segment in segments {
            buffer.append(segment)
            if buffer.count >= wordsPerLine {
                flush()
            }
        }
        flush()
        return lines
    }
}

/// Renders caption segments as a standard `.srt` subtitle file.
enum SRTExporter {
    static func generate(from segments: [CaptionSegment]) -> String {
        var lines: [String] = []
        for (index, segment) in segments.enumerated() {
            lines.append("\(index + 1)")
            lines.append("\(timestamp(segment.start.seconds)) --> \(timestamp(segment.end.seconds))")
            lines.append(segment.text)
            lines.append("")
        }
        return lines.joined(separator: "\n")
    }

    private static func timestamp(_ seconds: Double) -> String {
        let totalMs = Int((seconds * 1000).rounded())
        let ms = totalMs % 1000
        let totalSeconds = totalMs / 1000
        let s = totalSeconds % 60
        let m = (totalSeconds / 60) % 60
        let h = totalSeconds / 3600
        return String(format: "%02d:%02d:%02d,%03d", h, m, s, ms)
    }
}
