import Foundation

/// One line of an auto-generated (or hand-edited) transcript, timed against the
/// project's timeline. Used both for burned-in captions and `.srt` export.
struct CaptionSegment: Identifiable, Codable, Hashable {
    let id: UUID
    var text: String
    var start: CodableTime
    var end: CodableTime

    init(id: UUID = UUID(), text: String, start: CodableTime, end: CodableTime) {
        self.id = id
        self.text = text
        self.start = start
        self.end = end
    }
}
