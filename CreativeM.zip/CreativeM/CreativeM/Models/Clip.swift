import Foundation
import CoreMedia

/// One clip placed on a track. `Project` is the source of truth; `TimelineEngine`
/// turns the full set of clips into an `AVMutableComposition` for preview/export.
struct Clip: Identifiable, Codable, Hashable {
    var id: UUID
    var trackID: UUID
    var kind: ClipKind
    /// nil for `.title` clips, which have no backing media asset.
    var mediaAssetID: UUID?

    /// Position of this clip's start on the overall project timeline.
    var startTime: CodableTime
    /// In-point within the source media (ignored for `.title` clips).
    var sourceInPoint: CodableTime
    /// Duration of the clip as it appears on the timeline (i.e. after `speed` is applied).
    var timelineDuration: CodableTime

    var speed: Double = 1.0
    var volume: Float = 1.0
    var isMuted: Bool = false
    var fadeIn: CodableTime = .zero
    var fadeOut: CodableTime = .zero
    var transform: ClipTransform = .identity
    /// Cross-dissolve (or cut) with whatever precedes this clip on the same track.
    var transitionIn: TransitionType = .none
    /// Populated only when `kind == .title`.
    var title: TitleStyle?
    /// Premium Audio FX rack settings (EQ/compression/rumble/reverb), applied at export
    /// time only. `nil` (rather than a non-optional `= .none` default) so existing
    /// project files without this key still decode - see `AudioEffects`'s doc comment.
    var audioEffects: AudioEffects?
    /// Premium Video FX rack settings (color/vignette/blur), applied at export time
    /// only. `nil` for the same Codable-compatibility reason as `audioEffects` - see
    /// `VideoEffects`'s doc comment. Ignored for `.title` clips and image clips (see
    /// `TimelineEngine.buildAnimationTool`'s doc comment on why images don't get it yet).
    var videoEffects: VideoEffects?
    var displayName: String

    init(
        id: UUID = UUID(),
        trackID: UUID,
        kind: ClipKind,
        mediaAssetID: UUID? = nil,
        startTime: CodableTime,
        sourceInPoint: CodableTime = .zero,
        timelineDuration: CodableTime,
        speed: Double = 1.0,
        volume: Float = 1.0,
        isMuted: Bool = false,
        fadeIn: CodableTime = .zero,
        fadeOut: CodableTime = .zero,
        transform: ClipTransform = .identity,
        transitionIn: TransitionType = .none,
        title: TitleStyle? = nil,
        audioEffects: AudioEffects? = nil,
        videoEffects: VideoEffects? = nil,
        displayName: String
    ) {
        self.id = id
        self.trackID = trackID
        self.kind = kind
        self.mediaAssetID = mediaAssetID
        self.startTime = startTime
        self.sourceInPoint = sourceInPoint
        self.timelineDuration = timelineDuration
        self.speed = speed
        self.volume = volume
        self.isMuted = isMuted
        self.fadeIn = fadeIn
        self.fadeOut = fadeOut
        self.transform = transform
        self.transitionIn = transitionIn
        self.title = title
        self.audioEffects = audioEffects
        self.videoEffects = videoEffects
        self.displayName = displayName
    }

    var endTime: CodableTime { startTime + timelineDuration }

    /// `audioEffects ?? .none` - convenience so call sites don't repeat the fallback.
    var effectiveAudioEffects: AudioEffects { audioEffects ?? .none }
    /// `videoEffects ?? .none` - convenience so call sites don't repeat the fallback.
    var effectiveVideoEffects: VideoEffects { videoEffects ?? .none }

    /// Duration of source media this clip consumes, before the `speed` factor.
    var sourceDuration: CMTime {
        CMTimeMultiplyByFloat64(timelineDuration.time, multiplier: speed)
    }

    var sourceTimeRange: CMTimeRange {
        CMTimeRange(start: sourceInPoint.time, duration: sourceDuration)
    }

    var timelineRange: CMTimeRange {
        CMTimeRange(start: startTime.time, duration: timelineDuration.time)
    }
}
