import Foundation

struct Track: Identifiable, Codable, Hashable {
    let id: UUID
    var kind: TrackKind
    var name: String
    var isEnabled: Bool = true
    var isLocked: Bool = false
    var volume: Float = 1.0

    /// Marks an audio track as background music/SFX that should automatically duck
    /// under clips on any track flagged `isDuckingTrigger` (e.g. a dialogue track).
    var isDuckingTarget: Bool = false
    /// Marks an audio track (typically dialogue/voice-over) so its clips trigger
    /// ducking on any `isDuckingTarget` track.
    var isDuckingTrigger: Bool = false

    init(
        id: UUID = UUID(),
        kind: TrackKind,
        name: String,
        isEnabled: Bool = true,
        isLocked: Bool = false,
        volume: Float = 1.0,
        isDuckingTarget: Bool = false,
        isDuckingTrigger: Bool = false
    ) {
        self.id = id
        self.kind = kind
        self.name = name
        self.isEnabled = isEnabled
        self.isLocked = isLocked
        self.volume = volume
        self.isDuckingTarget = isDuckingTarget
        self.isDuckingTrigger = isDuckingTrigger
    }
}
