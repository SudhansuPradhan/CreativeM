import Foundation

enum MediaKind: String, Codable {
    case video
    case audio
    case image
}

/// A piece of source media imported into a project's media pool (camera roll / bin).
/// The app is unsandboxed, so `url` is stored as a plain absolute file URL - no
/// security-scoped bookmark bookkeeping is required.
struct MediaAsset: Identifiable, Codable, Hashable {
    let id: UUID
    var url: URL
    var kind: MediaKind
    var displayName: String
    var duration: CodableTime
    var naturalSize: CodableSize?
    var hasAudio: Bool
    /// File name (not full path) of a cached JPEG thumbnail inside the project's `Thumbnails/` folder.
    var thumbnailFileName: String?
    /// File name of a cached JSON waveform-peaks file inside the project's `Waveforms/` folder.
    var waveformFileName: String?
    var addedDate: Date

    init(
        id: UUID = UUID(),
        url: URL,
        kind: MediaKind,
        displayName: String,
        duration: CodableTime,
        naturalSize: CodableSize? = nil,
        hasAudio: Bool = false,
        thumbnailFileName: String? = nil,
        waveformFileName: String? = nil,
        addedDate: Date = Date()
    ) {
        self.id = id
        self.url = url
        self.kind = kind
        self.displayName = displayName
        self.duration = duration
        self.naturalSize = naturalSize
        self.hasAudio = hasAudio
        self.thumbnailFileName = thumbnailFileName
        self.waveformFileName = waveformFileName
        self.addedDate = addedDate
    }
}
