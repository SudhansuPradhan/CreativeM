import CoreMedia
import CoreGraphics
import Foundation

// MARK: - Codable wrappers
//
// CMTime/CGSize aren't guaranteed-stable `Codable` conformances across SDKs,
// so the project format stores these small, explicit wrapper types instead.
// This keeps `.cmproj` project files forward-compatible and easy to read.

/// A `Codable`, `Hashable` stand-in for `CMTime`.
struct CodableTime: Codable, Hashable, Comparable {
    var value: Int64
    var timescale: Int32

    init(_ time: CMTime) {
        if time.timescale == 0 {
            value = 0
            timescale = 600
        } else {
            value = time.value
            timescale = time.timescale
        }
    }

    init(seconds: Double, preferredTimescale: Int32 = 600) {
        self.init(CMTime(seconds: seconds, preferredTimescale: preferredTimescale))
    }

    static let zero = CodableTime(.zero)

    var time: CMTime { CMTime(value: value, timescale: timescale) }
    var seconds: Double { time.seconds }

    // `<` and `==` are both defined explicitly (rather than relying on the
    // memberwise-synthesized `Equatable`) so that two `CodableTime` values built with
    // different timescales but representing the same instant compare as `==`,
    // consistent with `<`. `hash(into:)` follows suit so equal values hash equally.
    static func < (lhs: CodableTime, rhs: CodableTime) -> Bool { lhs.time < rhs.time }
    static func == (lhs: CodableTime, rhs: CodableTime) -> Bool { lhs.time == rhs.time }
    func hash(into hasher: inout Hasher) { hasher.combine(seconds) }

    static func + (lhs: CodableTime, rhs: CodableTime) -> CodableTime { CodableTime(lhs.time + rhs.time) }
    static func - (lhs: CodableTime, rhs: CodableTime) -> CodableTime { CodableTime(lhs.time - rhs.time) }
}

/// A `Codable`, `Hashable` stand-in for `CGSize`.
struct CodableSize: Codable, Hashable {
    var width: Double
    var height: Double

    init(_ size: CGSize) {
        width = Double(size.width)
        height = Double(size.height)
    }

    init(width: Double, height: Double) {
        self.width = width
        self.height = height
    }

    var size: CGSize { CGSize(width: width, height: height) }
    var aspectRatio: Double { height == 0 ? 1 : width / height }
}

// MARK: - Track & clip kinds

enum TrackKind: String, Codable, CaseIterable {
    case video
    case title
    case audio
}

enum ClipKind: String, Codable {
    case video
    case audio
    case title
}

// MARK: - Per-clip transform (position / scale / rotation for the video track)

struct ClipTransform: Codable, Hashable {
    var scale: Double = 1.0
    /// Normalized offset from center, -1...1 across half the render width/height.
    var offsetX: Double = 0.0
    var offsetY: Double = 0.0
    var rotationDegrees: Double = 0.0

    static let identity = ClipTransform()
    var isIdentity: Bool { self == .identity }
}

// MARK: - Transitions

enum TransitionType: String, Codable, CaseIterable, Identifiable {
    case none
    case crossDissolve

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .none: return "Cut"
        case .crossDissolve: return "Cross Dissolve"
        }
    }

    /// Duration the transition overlaps the previous clip by.
    var duration: CMTime {
        switch self {
        case .none: return .zero
        case .crossDissolve: return CMTime(seconds: 0.75, preferredTimescale: 600)
        }
    }
}

// MARK: - Titles

enum TitlePosition: String, Codable, CaseIterable, Identifiable {
    case top, center, bottom
    var id: String { rawValue }
}

struct TitleStyle: Codable, Hashable {
    var text: String = "Title"
    var fontName: String = "HelveticaNeue-Bold"
    var fontSize: Double = 72
    var colorHex: String = "#FFFFFF"
    var backgroundOpacity: Double = 0.0
    var position: TitlePosition = .bottom
    var fadeDuration: CodableTime = CodableTime(seconds: 0.4)
}

// MARK: - Audio effects (premium "Audio FX" rack)
//
// Applied only at export time via `AudioEffectsProcessor` (an offline `AVAudioEngine`
// render using stock Apple AudioUnits) - never on the live-preview path, matching the
// "preview ≠ export" precedent already established for title/image burn-in. Preview
// catches up in the background once a clip's effects settings are rendered and cached
// (see `AppState.scheduleAudioEffectsPrewarm`).
//
// Deliberately `Optional` on `Clip` (not a non-optional field with a default) - verified
// empirically that Swift's synthesized `Decodable` uses `decode`, not `decodeIfPresent`,
// for non-optional properties even when they declare a default value, so a non-optional
// field here would fail to open every project file saved before this feature existed.
struct AudioEffects: Codable, Hashable {
    /// Low shelf @ 120Hz, -24...24 dB.
    var eqLowGainDB: Double = 0
    /// Parametric peak @ 1kHz (Q=1), -24...24 dB.
    var eqMidGainDB: Double = 0
    /// High shelf @ 8kHz, -24...24 dB.
    var eqHighGainDB: Double = 0
    /// 0 (off) ... 1 (heavy). Maps to the compressor's threshold + a touch of makeup gain.
    var compressionAmount: Double = 0
    /// 0 (off) ... 1 (aggressive). A highpass filter + a downward expander/gate - an
    /// honest heuristic, not spectral denoising (Apple ships no stock AudioUnit that
    /// does real spectral noise reduction).
    var reduceRumbleAmount: Double = 0
    /// 0 (dry) ... 1 (fully wet).
    var reverbAmount: Double = 0
    var reverbPreset: ReverbPresetOption = .mediumHall

    static let none = AudioEffects()
    var isIdentity: Bool { self == .none }
}

enum ReverbPresetOption: String, Codable, CaseIterable, Identifiable {
    case smallRoom, mediumRoom, largeRoom, mediumHall, largeHall, plate, cathedral

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .smallRoom: return "Small Room"
        case .mediumRoom: return "Medium Room"
        case .largeRoom: return "Large Room"
        case .mediumHall: return "Medium Hall"
        case .largeHall: return "Large Hall"
        case .plate: return "Plate"
        case .cathedral: return "Cathedral"
        }
    }
}

/// One-tap voice presets for mic recording - pure UI sugar over `AudioEffects`' own
/// sliders (sets several at once to a curated combination), not a separate rendering
/// mechanism or a live/real-time monitor effect - same pattern as `VideoLookPreset`.
/// Applied non-destructively to the clip the moment a mic recording finishes (see
/// `AppState.startMicRecording`), tweakable afterward in the Inspector's Audio FX
/// section, or reset to Clean at any time.
///
/// No pitch-shift-based presets (e.g. "Chipmunk"/"Robot") - `AudioEffects` has no pitch
/// parameter, and faking one with EQ alone would misrepresent what's actually happening,
/// same honesty bar as `reduceRumbleAmount` not claiming to be real spectral denoising.
enum MicVoicePreset: String, CaseIterable, Identifiable {
    case clean, podcast, warm, radio, bigRoom, telephone

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .clean: return "Clean"
        case .podcast: return "Podcast"
        case .warm: return "Warm"
        case .radio: return "Radio"
        case .bigRoom: return "Big Room"
        case .telephone: return "Telephone"
        }
    }

    var effects: AudioEffects {
        switch self {
        case .clean:
            return .none
        case .podcast:
            // Tight, present, controlled - a de-essed/gated broadcast voice chain.
            return AudioEffects(eqLowGainDB: -3, eqMidGainDB: 3, eqHighGainDB: 2, compressionAmount: 0.6, reduceRumbleAmount: 0.5, reverbAmount: 0, reverbPreset: .mediumRoom)
        case .warm:
            return AudioEffects(eqLowGainDB: 4, eqMidGainDB: 0, eqHighGainDB: -2, compressionAmount: 0.3, reduceRumbleAmount: 0.2, reverbAmount: 0.08, reverbPreset: .smallRoom)
        case .radio:
            // Narrow, mid-forward, heavily squashed - classic AM/talk-radio coloration.
            return AudioEffects(eqLowGainDB: -8, eqMidGainDB: 6, eqHighGainDB: -6, compressionAmount: 0.8, reduceRumbleAmount: 0.6, reverbAmount: 0, reverbPreset: .smallRoom)
        case .bigRoom:
            return AudioEffects(eqLowGainDB: 1, eqMidGainDB: 0, eqHighGainDB: 1, compressionAmount: 0.2, reduceRumbleAmount: 0.2, reverbAmount: 0.4, reverbPreset: .largeHall)
        case .telephone:
            // Band-limited, harsh mids - the EQ-only approximation of a telephone
            // earpiece this model can honestly produce (no pitch/bitcrush stage exists).
            return AudioEffects(eqLowGainDB: -24, eqMidGainDB: 8, eqHighGainDB: -24, compressionAmount: 0.7, reduceRumbleAmount: 0.8, reverbAmount: 0, reverbPreset: .smallRoom)
        }
    }
}

// MARK: - Video effects (premium "Video FX" rack)
//
// Applied only at export time, via a CALayer CIFilter chain (CIColorControls ->
// CIVignette -> CIGaussianBlur) attached to the single shared video layer that
// `TimelineEngine.buildAnimationTool` already builds for
// `AVVideoCompositionCoreAnimationTool` - never a custom `AVVideoCompositing` class, and
// never on the live-preview path (`AVVideoCompositionCoreAnimationTool` crashes if it's
// ever attached to an `AVPlayerItem.videoComposition` - see `TimelineEngine.build`'s
// `forPreview` doc comment). This mirrors the "preview != export" precedent already
// established for titles/images/captions AND for `AudioEffects` - except video effects
// need no separate render-and-cache step at all: they're applied inline as part of the
// same composition build export already does every time, via a keyframe-animated named
// filter per parameter (one shared layer, one CAKeyframeAnimation per parameter, holding
// each clip's own value for its own time range - see `TimelineEngine.videoEffectsSetup`).
// Verified empirically (standalone AVFoundation harness, not just "builds in Xcode")
// before shipping: CALayer.filters DOES apply through `postProcessingAsVideoLayer` during
// offline export, per-clip-varying values via a discrete-step keyframe animation on a
// named filter's input key works, and the three stock filter key names used below are
// all valid and chain correctly.
//
// Deliberately `Optional` on `Clip` (not a non-optional field with a default) - same
// reasoning as `AudioEffects`: Swift's synthesized `Decodable` uses `decode`, not
// `decodeIfPresent`, for non-optional properties even with a default value, so a
// non-optional field here would fail to open every project file saved before this
// feature existed.
struct VideoEffects: Codable, Hashable {
    /// -1 (darker) ... 1 (brighter). CIColorControls inputBrightness.
    var brightness: Double = 0
    /// 0 ... 2 (1 = unchanged). CIColorControls inputContrast.
    var contrast: Double = 1
    /// 0 (grayscale) ... 2 (vivid). CIColorControls inputSaturation.
    var saturation: Double = 1
    /// 0 (off) ... 1 (strong). CIVignette inputIntensity (inputRadius is a fixed 1.5 -
    /// not user-adjustable, to keep the control surface focused).
    var vignetteAmount: Double = 0
    /// 0 (off) ... 20 (soft/dreamy). CIGaussianBlur inputRadius.
    var blurRadius: Double = 0

    static let none = VideoEffects()
    var isIdentity: Bool { self == .none }
}

/// One-tap "looks" - pure UI sugar over `VideoEffects`' own sliders (sets several at
/// once to a curated combination), not a separate rendering mechanism. Deliberately NOT
/// built from discrete stock `CIPhotoEffect*` filters: those are fixed one-shot style
/// transforms that can't be keyframed to a per-clip-varying numeric value the way
/// `TimelineEngine.videoEffectsSetup` needs (a *type* of filter can't be interpolated/
/// held per time range the way a filter's own input *parameter* can - see that doc
/// comment) - so every "look" here is really just a preset point in the same 5-slider
/// space every clip already has, kept exactly as easy to verify/preview-caveat as any
/// other `VideoEffects` value.
enum VideoLookPreset: String, CaseIterable, Identifiable {
    case original, cinematic, noir, vintage, vivid, dreamy

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .original: return "Original"
        case .cinematic: return "Cinematic"
        case .noir: return "Noir"
        case .vintage: return "Vintage"
        case .vivid: return "Vivid"
        case .dreamy: return "Dreamy"
        }
    }

    var effects: VideoEffects {
        switch self {
        case .original:
            return .none
        case .cinematic:
            return VideoEffects(brightness: -0.02, contrast: 1.15, saturation: 0.85, vignetteAmount: 0.35, blurRadius: 0)
        case .noir:
            return VideoEffects(brightness: 0.0, contrast: 1.3, saturation: 0.0, vignetteAmount: 0.5, blurRadius: 0)
        case .vintage:
            return VideoEffects(brightness: 0.05, contrast: 0.9, saturation: 0.6, vignetteAmount: 0.3, blurRadius: 0)
        case .vivid:
            return VideoEffects(brightness: 0.03, contrast: 1.2, saturation: 1.5, vignetteAmount: 0.1, blurRadius: 0)
        case .dreamy:
            return VideoEffects(brightness: 0.05, contrast: 0.95, saturation: 0.9, vignetteAmount: 0.15, blurRadius: 3)
        }
    }
}

// MARK: - Markers

struct Marker: Identifiable, Codable, Hashable {
    let id: UUID
    var time: CodableTime
    var label: String

    init(id: UUID = UUID(), time: CodableTime, label: String = "Marker") {
        self.id = id
        self.time = time
        self.label = label
    }
}
