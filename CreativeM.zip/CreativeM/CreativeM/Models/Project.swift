import Foundation
import CoreMedia

/// The full state of one CreativeM project - everything needed to reconstruct the
/// timeline, media pool, and preview/export composition. Saved as `project.json`
/// inside a `.cmproj` folder by `ProjectDocument`.
struct Project: Identifiable, Codable {
    let id: UUID
    var name: String
    var createdDate: Date
    var modifiedDate: Date
    var frameRate: Double = 30
    var renderSize: CodableSize = CodableSize(width: 1920, height: 1080)

    var mediaAssets: [MediaAsset] = []
    var tracks: [Track] = []
    var clips: [Clip] = []
    var captionSegments: [CaptionSegment] = []
    var markers: [Marker] = []

    /// When true, `captionSegments` are burned into the video (preview + export)
    /// in addition to being exportable as a standalone `.srt` file.
    var burnInCaptions: Bool = false
    var exportPresetID: String = "hd1080"

    init(id: UUID = UUID(), name: String) {
        self.id = id
        self.name = name
        self.createdDate = Date()
        self.modifiedDate = Date()
        self.tracks = Project.defaultTracks()
    }

    static func defaultTracks() -> [Track] {
        [
            Track(kind: .video, name: "Video"),
            Track(kind: .title, name: "Titles"),
            Track(kind: .audio, name: "Dialogue", isDuckingTrigger: true),
            Track(kind: .audio, name: "Music", isDuckingTarget: true),
        ]
    }

    var videoTrack: Track? { tracks.first { $0.kind == .video } }
    var titleTrack: Track? { tracks.first { $0.kind == .title } }
    var audioTracks: [Track] { tracks.filter { $0.kind == .audio } }

    func clips(on trackID: UUID) -> [Clip] {
        clips.filter { $0.trackID == trackID }.sorted { $0.startTime < $1.startTime }
    }

    var duration: CMTime {
        // `CMTime` doesn't reliably conform to `Comparable`/`max()` across SDKs, so
        // reduce over `CodableTime` (which does) instead.
        (clips.map(\.endTime).max() ?? .zero).time
    }

    func mediaAsset(_ id: UUID?) -> MediaAsset? {
        guard let id else { return nil }
        return mediaAssets.first { $0.id == id }
    }

    mutating func touch() {
        modifiedDate = Date()
    }
}
