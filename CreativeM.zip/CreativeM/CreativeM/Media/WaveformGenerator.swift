import AVFoundation
import Foundation

/// Extracts a downsampled peak-amplitude waveform from an audio (or video-with-audio)
/// file using `AVAssetReader`, for display in the timeline and inspector.
enum WaveformGenerator {
    static func generatePeaks(for url: URL, targetSampleCount: Int = 400) async throws -> [Float] {
        let asset = AVURLAsset(url: url)
        guard let track = try await asset.loadTracks(withMediaType: .audio).first else {
            return []
        }

        return try await withCheckedThrowingContinuation { continuation in
            do {
                let reader = try AVAssetReader(asset: asset)
                let settings: [String: Any] = [
                    AVFormatIDKey: kAudioFormatLinearPCM,
                    AVLinearPCMIsFloatKey: true,
                    AVLinearPCMBitDepthKey: 32,
                    AVLinearPCMIsNonInterleaved: false,
                    AVLinearPCMIsBigEndianKey: false,
                ]
                let output = AVAssetReaderTrackOutput(track: track, outputSettings: settings)
                guard reader.canAdd(output) else {
                    continuation.resume(returning: [])
                    return
                }
                reader.add(output)
                reader.startReading()

                var allSamples: [Float] = []
                allSamples.reserveCapacity(targetSampleCount * 64)

                while reader.status == .reading, let buffer = output.copyNextSampleBuffer() {
                    if let block = CMSampleBufferGetDataBuffer(buffer) {
                        let length = CMBlockBufferGetDataLength(block)
                        var data = [UInt8](repeating: 0, count: length)
                        CMBlockBufferCopyDataBytes(block, atOffset: 0, dataLength: length, destination: &data)
                        data.withUnsafeBytes { raw in
                            let floatPointer = raw.bindMemory(to: Float.self)
                            allSamples.append(contentsOf: floatPointer)
                        }
                    }
                }

                if reader.status == .failed {
                    continuation.resume(throwing: reader.error ?? NSError(domain: "CreativeM", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to read audio samples."]))
                    return
                }

                continuation.resume(returning: Self.downsample(allSamples, to: targetSampleCount))
            } catch {
                continuation.resume(throwing: error)
            }
        }
    }

    private static func downsample(_ samples: [Float], to targetCount: Int) -> [Float] {
        guard !samples.isEmpty, targetCount > 0 else { return [] }
        let bucketSize = max(1, samples.count / targetCount)
        var peaks: [Float] = []
        peaks.reserveCapacity(targetCount)
        var index = 0
        while index < samples.count {
            let end = min(index + bucketSize, samples.count)
            var peak: Float = 0
            for i in index..<end {
                peak = max(peak, abs(samples[i]))
            }
            peaks.append(peak)
            index = end
        }
        return peaks
    }

    /// Persists peaks as a small JSON file inside the project's Waveforms/ folder, returning the file name.
    static func savePeaks(_ peaks: [Float], assetID: UUID, into directory: URL) throws -> String {
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let fileName = "\(assetID.uuidString).json"
        let data = try JSONEncoder().encode(peaks)
        try data.write(to: directory.appendingPathComponent(fileName))
        return fileName
    }

    static func loadPeaks(fileName: String, from directory: URL) -> [Float] {
        let url = directory.appendingPathComponent(fileName)
        guard let data = try? Data(contentsOf: url) else { return [] }
        return (try? JSONDecoder().decode([Float].self, from: data)) ?? []
    }
}
