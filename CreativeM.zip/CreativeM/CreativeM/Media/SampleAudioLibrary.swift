import AVFoundation
import Foundation

enum SampleAudioError: LocalizedError {
    case bufferAllocationFailed
    var errorDescription: String? { "Couldn't allocate an audio buffer for sample generation." }
}

/// Procedurally-synthesized placeholder audio clips ("Sample Library") so the app ships
/// with something usable to drag onto the timeline out of the box: tonal beds (ambient
/// pad, cinematic drone, click track, soft riser, noise bed) plus a "premium cinematics"
/// set of trailer-style sound-design beds (braam hit, impact boom, tension riser, war
/// drums, dark horror drone, uplifting swell, suspense pulse, whoosh transition).
///
/// These are generated locally from simple oscillators and a deterministic noise hash
/// (see `whiteNoise(_:)`) - they are NOT licensed stock music, and nothing in this app
/// can source or clear real stock audio. Every UI call site that surfaces these labels
/// them as generated/placeholder content (see `MediaLibraryView`'s "Add Sample Audio"
/// button and the `"Sample - "` name prefix below) rather than implying they're cleared
/// for real use.
enum SampleAudioLibrary {
    struct Sample {
        let fileName: String
        let displayName: String
        let duration: Double
        /// Mono signal generator, roughly in [-1, 1]; called once per channel per frame
        /// (the right channel is evaluated at a slightly offset time for stereo width).
        let generator: (_ time: Double, _ duration: Double) -> Double
    }

    /// Shared by `generate(_:to:)` (actual render) and `lowRumble(_:)` (its sample-spacing
    /// for a stateless moving-average low-pass) so there's exactly one place that knows
    /// the render sample rate, rather than the same literal duplicated across call sites.
    private static let sampleRate = 44_100.0

    static let samples: [Sample] = [
        Sample(fileName: "sample-ambient-pad.m4a", displayName: "Sample - Ambient Pad", duration: 20, generator: ambientPad),
        Sample(fileName: "sample-cinematic-drone.m4a", displayName: "Sample - Cinematic Drone", duration: 16, generator: cinematicDrone),
        Sample(fileName: "sample-click-track-120bpm.m4a", displayName: "Sample - Click Track (120 BPM)", duration: 10, generator: clickTrack),
        Sample(fileName: "sample-soft-riser.m4a", displayName: "Sample - Soft Riser", duration: 4, generator: softRiser),
        Sample(fileName: "sample-noise-bed.m4a", displayName: "Sample - Ambient Noise Bed", duration: 15, generator: noiseBed),
        // Premium cinematics: trailer-style hits, builds, and beds.
        Sample(fileName: "sample-trailer-braam.m4a", displayName: "Sample - Trailer Braam", duration: 6, generator: trailerBraam),
        Sample(fileName: "sample-impact-boom.m4a", displayName: "Sample - Impact Boom", duration: 4, generator: impactBoom),
        Sample(fileName: "sample-tension-riser.m4a", displayName: "Sample - Tension Riser", duration: 10, generator: tensionRiser),
        Sample(fileName: "sample-war-drums.m4a", displayName: "Sample - War Drums", duration: 8, generator: warDrums),
        Sample(fileName: "sample-dark-horror-drone.m4a", displayName: "Sample - Dark Horror Drone", duration: 18, generator: darkHorrorDrone),
        Sample(fileName: "sample-uplifting-swell.m4a", displayName: "Sample - Uplifting Swell", duration: 12, generator: upliftingSwell),
        Sample(fileName: "sample-suspense-pulse.m4a", displayName: "Sample - Suspense Pulse", duration: 10, generator: suspensePulse),
        Sample(fileName: "sample-whoosh-transition.m4a", displayName: "Sample - Whoosh Transition", duration: 1.5, generator: whooshTransition),
    ]

    /// Generates any samples not already cached on disk, returning every sample's URL
    /// (pre-existing or newly-written). Idempotent - safe to call every time the user
    /// clicks "Add Sample Audio".
    static func ensureGenerated() async throws -> [URL] {
        var urls: [URL] = []
        for sample in samples {
            let url = AppPaths.sampleAudioDirectory.appendingPathComponent(sample.fileName)
            if !FileManager.default.fileExists(atPath: url.path) {
                try generate(sample, to: url)
            }
            urls.append(url)
        }
        return urls
    }

    private static func generate(_ sample: Sample, to url: URL) throws {
        let frameCount = AVAudioFrameCount(sampleRate * sample.duration)
        guard let format = AVAudioFormat(standardFormatWithSampleRate: sampleRate, channels: 2),
              let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: frameCount) else {
            throw SampleAudioError.bufferAllocationFailed
        }
        buffer.frameLength = frameCount
        let left = buffer.floatChannelData![0]
        let right = buffer.floatChannelData![1]
        for i in 0..<Int(frameCount) {
            let t = Double(i) / sampleRate
            left[i] = Float(max(-1, min(1, sample.generator(t, sample.duration))))
            right[i] = Float(max(-1, min(1, sample.generator(t + 0.0017, sample.duration))))
        }

        let aacSettings: [String: Any] = [
            AVFormatIDKey: kAudioFormatMPEG4AAC,
            AVSampleRateKey: sampleRate,
            AVNumberOfChannelsKey: 2,
            AVEncoderBitRateKey: 128_000
        ]
        try write(buffer: buffer, to: url, settings: aacSettings)
    }

    /// Scoped so the writing `AVAudioFile` deallocates (finalizing the AAC container)
    /// before anything else tries to read `url` back - verified empirically (this
    /// session, `AudioEffectsProcessor`'s cache render) that an in-progress AAC writer
    /// leaves the file unreadable until its `AVAudioFile` goes out of scope.
    private static func write(buffer: AVAudioPCMBuffer, to url: URL, settings: [String: Any]) throws {
        let file = try AVAudioFile(forWriting: url, settings: settings, commonFormat: .pcmFormatFloat32, interleaved: false)
        try file.write(from: buffer)
    }

    // MARK: - Generators

    /// Slow three-note chord (A3 minor-ish triad) with gentle vibrato and a full fade in/out.
    private static func ambientPad(_ t: Double, _ duration: Double) -> Double {
        let freqs = [220.0, 277.18, 329.63]
        let vibrato = sin(2.0 * .pi * 0.15 * t) * 1.5
        var sample = 0.0
        for f in freqs { sample += sin(2.0 * .pi * (f + vibrato) * t) }
        sample /= Double(freqs.count)
        return sample * 0.3 * envelope(t, duration, fade: 2.0)
    }

    /// Low drone (55Hz + octave) with a slow amplitude swell.
    private static func cinematicDrone(_ t: Double, _ duration: Double) -> Double {
        let base = sin(2.0 * .pi * 55.0 * t) + 0.5 * sin(2.0 * .pi * 110.0 * t)
        let swell = 0.5 + 0.5 * sin(2.0 * .pi * 0.08 * t)
        return base * 0.25 * swell * envelope(t, duration, fade: 2.5)
    }

    /// 120 BPM quarter-note clicks: short decaying blips, classic reference-track feel.
    private static func clickTrack(_ t: Double, _ duration: Double) -> Double {
        let beatDuration = 60.0 / 120.0
        let phase = t.truncatingRemainder(dividingBy: beatDuration)
        let clickLength = 0.03
        guard phase < clickLength else { return 0 }
        let decay = exp(-phase * 80)
        return sin(2.0 * .pi * 1000.0 * phase) * decay * 0.6
    }

    /// Summed detuned-ish high partials ramping 0 -> 1 - a soft whoosh/riser for transitions.
    private static func softRiser(_ t: Double, _ duration: Double) -> Double {
        let progress = min(1, t / duration)
        let partials = [300.0, 450.0, 630.0, 810.0, 970.0]
        var sample = 0.0
        for (i, f) in partials.enumerated() {
            sample += sin(2.0 * .pi * f * t * (1 + progress) + Double(i))
        }
        sample /= Double(partials.count)
        return sample * 0.35 * progress * progress
    }

    /// Quiet low-frequency texture (two detuned low tones + slow jitter) for ambient beds.
    private static func noiseBed(_ t: Double, _ duration: Double) -> Double {
        let jitter = sin(2.0 * .pi * 37.0 * t) * sin(2.0 * .pi * 0.6 * t)
        let body = sin(2.0 * .pi * 80.0 * t) + 0.6 * sin(2.0 * .pi * 160.3 * t) + 0.4 * jitter
        return body * 0.12 * envelope(t, duration, fade: 1.5)
    }

    /// Linear fade in/out envelope, `fade` seconds on each end (clamped to half the duration).
    private static func envelope(_ t: Double, _ duration: Double, fade: Double) -> Double {
        let f = min(fade, duration * 0.49)
        guard f > 0 else { return 1 }
        if t < f { return t / f }
        if t > duration - f { return max(0, (duration - t) / f) }
        return 1
    }

    /// Fade-out only (no fade-in) over the last `fade` seconds - for one-shot hits/stabs
    /// that should start instantly but still end cleanly instead of stopping on a hard
    /// discontinuity (an audible click/pop at the file's last sample).
    private static func fadeOut(_ t: Double, _ duration: Double, fade: Double) -> Double {
        let f = min(fade, duration * 0.9)
        guard f > 0, t > duration - f else { return 1 }
        return max(0, (duration - t) / f)
    }

    /// Fade-in only (no fade-out) over the first `fade` seconds. `whiteNoise(0)` always
    /// hashes to exactly -1 (verified: SplitMix64's finalizer maps an all-zero input to
    /// an all-zero output, and `unit*2-1` turns that into -1) - so any one-shot generator
    /// that feeds `t == 0` straight into `whiteNoise`/`lowRumble` with no envelope jumps
    /// instantly from true silence to a non-trivial amplitude, an audible click exactly
    /// like the one `fadeOut` already prevents at the tail. A few milliseconds is enough
    /// to kill the click without perceptibly softening the hit.
    private static func fadeIn(_ t: Double, _ duration: Double, fade: Double) -> Double {
        let f = min(fade, duration * 0.9)
        guard f > 0, t < f else { return 1 }
        return t / f
    }

    // MARK: - Noise helpers

    /// Deterministic "white noise" in [-1, 1] - not a true RNG, a fixed hash (SplitMix64's
    /// finalizer) of `t`'s raw IEEE-754 bit pattern, so it's a pure, stateless function of
    /// time like every other generator here (no history to carry between calls, no shared
    /// mutable state to worry about across the left/right channel calls).
    ///
    /// Hashing the bit pattern directly - rather than deriving an integer sample index via
    /// `t * sampleRate` - matters because `generate(_:to:)` calls this with `t + 0.0017`
    /// for the right channel, which does NOT land on an exact multiple of the sample
    /// period. Rounding that to a "frame index" would make several adjacent right-channel
    /// frames collide on the same rounded index, duplicating samples and producing an
    /// audible periodic buzz instead of noise (caught before shipping; verified empirically
    /// that this bit-pattern version has no such collisions and no dependency on knowing
    /// the sample rate at all).
    private static func whiteNoise(_ t: Double) -> Double {
        var x = t.bitPattern &* 0x9E37_79B9_7F4A_7C15
        x ^= x >> 30
        x = x &* 0xBF58_476D_1CE4_E5B9
        x ^= x >> 27
        x = x &* 0x94D0_49BB_1331_11EB
        x ^= x >> 31
        let unit = Double(x >> 11) / Double(1 << 53) // [0, 1)
        return unit * 2 - 1
    }

    /// A crude, stateless 4-tap moving-average low-pass over `whiteNoise`, sampled at the
    /// actual render sample spacing (`1 / sampleRate`) - just enough to turn hissy white
    /// noise into a darker "rumble" texture for sub-bass/thriller beds, without needing a
    /// real (stateful) filter that would break the "pure function of time" shape every
    /// other generator here relies on.
    private static func lowRumble(_ t: Double) -> Double {
        let dt = 1.0 / sampleRate
        return (whiteNoise(t) + whiteNoise(t - dt) + whiteNoise(t - 2 * dt) + whiteNoise(t - 3 * dt)) / 4
    }

    // MARK: - Premium cinematics (trailer-style sound design)

    /// Dissonant stacked-brass "BRAAM" hit (trailer cliche): a tight, intentionally
    /// dissonant low cluster (minor 2nd + octave) with a fast swell-in and a long,
    /// slowly-decaying tail. Gains tuned (and empirically peak-checked) to stay well
    /// clear of the `generate(_:to:)` clamp even with all four tones' harmonics aligned.
    private static func trailerBraam(_ t: Double, _ duration: Double) -> Double {
        let freqs = [55.0, 58.27, 61.74, 110.0] // A1-ish cluster: close minor 2nds + octave
        var sample = 0.0
        for f in freqs {
            sample += sin(2.0 * .pi * f * t) + 0.3 * sin(2.0 * .pi * f * 2 * t)
        }
        sample /= Double(freqs.count)
        let attack = min(1, t / 0.6)
        let decay = exp(-max(0, t - 0.6) * 0.35)
        return sample * 0.4 * attack * decay * fadeOut(t, duration, fade: 0.3)
    }

    /// A single percussive "boom": a short noise click (the transient) over a long-ringing
    /// sub-bass tone - the other half of the classic trailer-hit pair, usually layered
    /// right under a braam.
    private static func impactBoom(_ t: Double, _ duration: Double) -> Double {
        let click = whiteNoise(t) * exp(-t * 90) * 0.3
        let sub = sin(2.0 * .pi * 48.0 * t) * exp(-t * 2.2) * 0.55
        // 3ms fade-in: `click` is noise-driven, so it's already nonzero at t=0 (see
        // `fadeIn`'s doc comment) - without this the file would open with an audible
        // click instead of the intended punchy-but-clean hit.
        return (click + sub) * fadeIn(t, duration, fade: 0.003) * fadeOut(t, duration, fade: 0.3)
    }

    /// A dark, rumbling upward riser: thickening low rumble plus an accelerating upward
    /// tone sweep, both building toward the edit's cut point - deliberately darker/lower
    /// than the existing airy `softRiser`.
    private static func tensionRiser(_ t: Double, _ duration: Double) -> Double {
        let progress = min(1, t / duration)
        // `* progress` on the rumble (not just its own coefficient) so the clip starts at
        // exactly 0 - `lowRumble(0)` is already nonzero (built on `whiteNoise`, which
        // hashes t=0 to -1; see `fadeIn`'s doc comment) and without this it would open on
        // a small but real click instead of silence.
        let rumble = lowRumble(t) * progress * (0.15 + 0.35 * progress)
        let sweepFreq = 80.0 + 900.0 * progress * progress
        let tone = sin(2.0 * .pi * sweepFreq * t) * progress * 0.3
        return rumble + tone
    }

    /// Looping low tom hits in a steady trailer-drum pattern (~100 BPM): each hit is a
    /// short pitch-dropping thump (tone) plus a brief mallet-strike noise transient.
    /// `phase` (time since the start of the CURRENT beat) drives each hit's own decay
    /// shape; `t` (absolute time) drives the noise hash, so successive hits get genuinely
    /// different-sounding transients instead of audibly repeating the same noise burst.
    private static func warDrums(_ t: Double, _ duration: Double) -> Double {
        let bpm = 100.0
        let beatDuration = 60.0 / bpm
        let phase = t.truncatingRemainder(dividingBy: beatDuration)
        let hitLength = 0.35
        guard phase < hitLength else { return 0 }
        let pitchDrop = 95.0 * exp(-phase * 18) + 45.0 // starts ~140Hz, settles to 45Hz
        let tone = sin(2.0 * .pi * pitchDrop * phase) * 0.6
        let click = whiteNoise(t) * exp(-phase * 220) * 0.3
        let decay = exp(-phase * 6)
        return (tone + click) * decay * envelope(t, duration, fade: 0.4)
    }

    /// Two closely-detuned low tones slowly beating against each other, plus a thin
    /// dissonant high overtone - a sustained horror/suspense dread bed, distinct from the
    /// warmer, swelling `cinematicDrone`.
    private static func darkHorrorDrone(_ t: Double, _ duration: Double) -> Double {
        let low1 = sin(2.0 * .pi * 41.0 * t)
        let low2 = sin(2.0 * .pi * 41.8 * t) // ~0.8Hz beat frequency against low1
        let dissonantHigh = sin(2.0 * .pi * 466.0 * t) * 0.06
        let rumble = lowRumble(t) * 0.12
        let body = (low1 + low2) * 0.3 + dissonantHigh + rumble
        return body * envelope(t, duration, fade: 2.0)
    }

    /// A major triad swelling in slowly with gentle vibrato - a "hope returns" trailer
    /// swell, as a brighter counterpart to the moodier pads/drones above.
    private static func upliftingSwell(_ t: Double, _ duration: Double) -> Double {
        let freqs = [146.83, 185.0, 220.0, 293.66] // D3 major triad + octave (D3 F#3 A3 D4)
        let vibrato = sin(2.0 * .pi * 0.2 * t) * 1.2
        var sample = 0.0
        for f in freqs { sample += sin(2.0 * .pi * (f + vibrato) * t) }
        sample /= Double(freqs.count)
        let swell = min(1, t / (duration * 0.6))
        return sample * 0.35 * swell * envelope(t, duration, fade: 2.0)
    }

    /// A steady low pulsing sub-bass (like a tense heartbeat) with a faint ticking accent
    /// on each beat - a thriller "something's about to happen" bed.
    private static func suspensePulse(_ t: Double, _ duration: Double) -> Double {
        let bpm = 80.0
        let beatDuration = 60.0 / bpm
        let phase = t.truncatingRemainder(dividingBy: beatDuration)
        let pulse = sin(2.0 * .pi * 60.0 * t) * exp(-phase * 5) * 0.65
        let tick = phase < 0.02 ? whiteNoise(t) * 0.15 : 0.0
        return (pulse + tick) * envelope(t, duration, fade: 0.5)
    }

    /// A fast rising-then-falling filtered-noise sweep - a quick whoosh for cut
    /// transitions, much shorter than `tensionRiser` (which builds over many seconds).
    private static func whooshTransition(_ t: Double, _ duration: Double) -> Double {
        let progress = t / duration
        let shape = sin(.pi * min(1, max(0, progress))) // rises then falls back to 0 across the clip
        let brightness = lowRumble(t) * (0.2 + 0.4 * shape) + whiteNoise(t) * 0.15 * shape
        return brightness * shape
    }
}
