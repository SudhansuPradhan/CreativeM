import Foundation

enum URLAudioImportError: LocalizedError {
    case unsupportedHost(String)
    case downloadFailed(Int?)
    case notMedia(contentType: String?)

    var errorDescription: String? {
        switch self {
        case .unsupportedHost(let host):
            return "\(host) isn't supported for direct import."
        case .downloadFailed(let code):
            if let code { return "The server returned an error (HTTP \(code))." }
            return "The download failed."
        case .notMedia(let contentType):
            if let contentType { return "That link didn't point to an audio or video file (got \"\(contentType)\")." }
            return "That link didn't point to an audio or video file."
        }
    }
}

/// Downloads a direct link to an audio/video file, validating it before import.
///
/// Deliberately does NOT support pulling audio from YouTube (or similar
/// streaming-site) URLs. Doing that for real means reverse-engineering the
/// site's player to extract a stream URL (what tools like yt-dlp do) -  that's
/// a different, much riskier thing than fetching a file a server is directly
/// offering at a URL, and it runs against YouTube's Terms of Service (clients
/// must access content only through the mechanisms YouTube itself provides).
/// We'd rather tell the user clearly than ship a feature that quietly violates
/// a platform's ToS on their behalf. `AppState.startSystemAudioRecording()` is
/// the ToS-safe alternative: it records whatever's actually playing, the same
/// way a hardware capture device would.
enum URLAudioImporter {
    static let blockedHosts: Set<String> = [
        "youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com", "youtu.be",
    ]

    static func isBlockedHost(_ url: URL) -> Bool {
        guard let host = url.host?.lowercased() else { return false }
        return blockedHosts.contains(host) || blockedHosts.contains { host.hasSuffix(".\($0)") }
    }

    /// Downloads `url` into `AppPaths.recordingsDirectory` (the same "landing zone"
    /// live recordings use). Rejects anything whose response isn't recognizably
    /// audio/video - a streaming-site *page* URL, for instance, returns a 200
    /// `text/html` response, which would otherwise silently become a broken
    /// "imported" asset that only fails later when `AVURLAsset` tries to read it.
    static func download(from url: URL) async throws -> URL {
        if isBlockedHost(url) { throw URLAudioImportError.unsupportedHost(url.host ?? "this site") }

        let (tempURL, response) = try await URLSession.shared.download(from: url)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw URLAudioImportError.downloadFailed((response as? HTTPURLResponse)?.statusCode)
        }

        guard let ext = resolvedExtension(url: url, response: http) else {
            throw URLAudioImportError.notMedia(contentType: http.mimeType)
        }

        let destination = AppPaths.recordingsDirectory.appendingPathComponent(suggestedFileName(url: url, ext: ext))
        try? FileManager.default.removeItem(at: destination)
        try FileManager.default.moveItem(at: tempURL, to: destination)
        return destination
    }

    /// Prefers the URL's own file extension when it's one we recognize; falls
    /// back to the response's `Content-Type` for links that don't end in a
    /// file name (e.g. a CDN URL with a query-string path). Returns `nil` -
    /// meaning "reject" - for anything that isn't recognizably audio/video,
    /// most importantly `text/html`.
    private static func resolvedExtension(url: URL, response: HTTPURLResponse) -> String? {
        let urlExt = url.pathExtension.lowercased()
        if MediaImporter.audioExtensions.contains(urlExt) || MediaImporter.videoExtensions.contains(urlExt) {
            return urlExt
        }
        switch response.mimeType?.lowercased() {
        case "audio/mpeg": return "mp3"
        case "audio/mp4", "audio/x-m4a", "audio/aac": return "m4a"
        case "audio/wav", "audio/x-wav", "audio/wave": return "wav"
        case "audio/aiff", "audio/x-aiff": return "aiff"
        case "video/mp4": return "mp4"
        case "video/quicktime": return "mov"
        default: return nil
        }
    }

    private static func suggestedFileName(url: URL, ext: String) -> String {
        // `lastPathComponent` of a root path ("https://example.com/") is "/" itself,
        // not empty - left unguarded, that becomes a literal "/" inside the file
        // name and `appendingPathComponent` reads it as a (nonexistent) subdirectory,
        // so `moveItem` throws. Scrub any stray slash out defensively too.
        let base = url.deletingPathExtension().lastPathComponent.replacingOccurrences(of: "/", with: "-")
        let safeBase = base.isEmpty || base == "-" ? "Downloaded Audio" : base
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd 'at' HH.mm.ss"
        return "\(safeBase) \(formatter.string(from: Date())).\(ext)"
    }
}
