import AVFoundation
import AppKit
import Foundation

enum MediaImportError: LocalizedError {
    case unsupportedFile
    case couldNotReadTrack

    var errorDescription: String? {
        switch self {
        case .unsupportedFile: return "This file type isn't supported."
        case .couldNotReadTrack: return "Couldn't read a video or audio track from this file."
        }
    }
}

/// Turns a file on disk into a `MediaAsset`, and renders its cached thumbnail.
/// The app is unsandboxed, so imported media is referenced by absolute URL rather
/// than copied into the project by default.
enum MediaImporter {
    static let videoExtensions: Set<String> = ["mov", "mp4", "m4v", "avi"]
    static let audioExtensions: Set<String> = ["mp3", "m4a", "wav", "aiff", "aif", "caf"]
    static let imageExtensions: Set<String> = ["jpg", "jpeg", "png", "heic", "tiff", "gif"]

    static var allSupportedExtensions: Set<String> {
        videoExtensions.union(audioExtensions).union(imageExtensions)
    }

    static func kind(for url: URL) -> MediaKind? {
        let ext = url.pathExtension.lowercased()
        if videoExtensions.contains(ext) { return .video }
        if audioExtensions.contains(ext) { return .audio }
        if imageExtensions.contains(ext) { return .image }
        return nil
    }

    /// Reads metadata for `url` and builds a `MediaAsset`. Does not touch the disk
    /// thumbnail/waveform cache - call `generateThumbnail` / `WaveformGenerator.generatePeaks`
    /// afterwards once the asset has a home in a project.
    static func importAsset(from url: URL) async throws -> MediaAsset {
        guard let kind = kind(for: url) else { throw MediaImportError.unsupportedFile }
        let displayName = url.deletingPathExtension().lastPathComponent

        switch kind {
        case .image:
            var size: CodableSize?
            if let image = NSImage(contentsOf: url), let rep = image.representations.first {
                size = CodableSize(width: Double(rep.pixelsWide), height: Double(rep.pixelsHigh))
            }
            return MediaAsset(
                url: url,
                kind: .image,
                displayName: displayName,
                duration: CodableTime(seconds: 5),
                naturalSize: size,
                hasAudio: false
            )

        case .video, .audio:
            let asset = AVURLAsset(url: url)
            let duration = try await asset.load(.duration)
            let videoTracks = try await asset.loadTracks(withMediaType: .video)
            let audioTracks = try await asset.loadTracks(withMediaType: .audio)

            guard !videoTracks.isEmpty || !audioTracks.isEmpty else {
                throw MediaImportError.couldNotReadTrack
            }

            var naturalSize: CodableSize?
            if let track = videoTracks.first {
                let size = try await track.load(.naturalSize)
                let transform = try await track.load(.preferredTransform)
                let oriented = size.applying(transform)
                naturalSize = CodableSize(width: abs(oriented.width), height: abs(oriented.height))
            }

            return MediaAsset(
                url: url,
                kind: videoTracks.isEmpty ? .audio : .video,
                displayName: displayName,
                duration: CodableTime(duration),
                naturalSize: naturalSize,
                hasAudio: !audioTracks.isEmpty
            )
        }
    }

    /// Renders a JPEG thumbnail into `directory`, returning the file name written (not full path).
    /// Synchronous and disk-bound - call from a background task.
    @discardableResult
    static func generateThumbnail(for asset: MediaAsset, into directory: URL) throws -> String? {
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let fileName = "\(asset.id.uuidString).jpg"
        let destination = directory.appendingPathComponent(fileName)

        switch asset.kind {
        case .video:
            let avAsset = AVURLAsset(url: asset.url)
            let generator = AVAssetImageGenerator(asset: avAsset)
            generator.appliesPreferredTrackTransform = true
            let midpoint = CMTimeMultiplyByFloat64(asset.duration.time, multiplier: 0.1)
            let cgImage = try generator.copyCGImage(at: midpoint, actualTime: nil)
            try writeJPEG(cgImage: cgImage, to: destination)
            return fileName

        case .image:
            guard let image = NSImage(contentsOf: asset.url),
                  let cgImage = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else {
                return nil
            }
            try writeJPEG(cgImage: cgImage, to: destination)
            return fileName

        case .audio:
            return nil
        }
    }

    private static func writeJPEG(cgImage: CGImage, to url: URL) throws {
        let rep = NSBitmapImageRep(cgImage: cgImage)
        guard let data = rep.representation(using: .jpeg, properties: [.compressionFactor: 0.8]) else {
            throw MediaImportError.couldNotReadTrack
        }
        try data.write(to: url)
    }
}
