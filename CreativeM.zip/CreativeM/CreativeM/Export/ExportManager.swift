import AVFoundation
import Combine
import Foundation

struct ExportPreset: Identifiable, Hashable {
    let id: String
    var name: String
    /// nil for audio-only presets, where render size is meaningless.
    var renderSize: CGSize?
    var avPresetName: String
    var fileType: AVFileType
    /// Plain extension (no dot) for save-panel default filenames. Kept as an explicit
    /// field rather than derived from `fileType`/UTI to avoid depending on
    /// UniformTypeIdentifiers APIs we haven't verified here.
    var fileExtension: String
    var isAudioOnly: Bool = false
}

extension ExportPreset {
    static let hd1080 = ExportPreset(
        id: "hd1080", name: "1080p H.264 - YouTube / General",
        renderSize: CGSize(width: 1920, height: 1080),
        avPresetName: AVAssetExportPresetHighestQuality, fileType: .mp4, fileExtension: "mp4"
    )
    static let uhd4k = ExportPreset(
        id: "uhd4k", name: "4K H.264",
        renderSize: CGSize(width: 3840, height: 2160),
        avPresetName: AVAssetExportPresetHighestQuality, fileType: .mp4, fileExtension: "mp4"
    )
    static let vertical = ExportPreset(
        id: "vertical", name: "Vertical 9:16 - Reels / TikTok / Shorts",
        renderSize: CGSize(width: 1080, height: 1920),
        avPresetName: AVAssetExportPresetHighestQuality, fileType: .mp4, fileExtension: "mp4"
    )
    static let square = ExportPreset(
        id: "square", name: "Square 1:1 - Instagram Feed",
        renderSize: CGSize(width: 1080, height: 1080),
        avPresetName: AVAssetExportPresetHighestQuality, fileType: .mp4, fileExtension: "mp4"
    )
    static let proRes = ExportPreset(
        id: "prores", name: "ProRes 422 - Editing Master",
        renderSize: CGSize(width: 1920, height: 1080),
        avPresetName: AVAssetExportPresetAppleProRes422LPCM, fileType: .mov, fileExtension: "mov"
    )
    static let audioOnly = ExportPreset(
        id: "audio", name: "Audio Only - M4A",
        renderSize: nil,
        avPresetName: AVAssetExportPresetAppleM4A, fileType: .m4a, fileExtension: "m4a", isAudioOnly: true
    )

    static let all: [ExportPreset] = [.hd1080, .uhd4k, .vertical, .square, .proRes, .audioOnly]

    static func byID(_ id: String) -> ExportPreset {
        all.first { $0.id == id } ?? .hd1080
    }
}

enum ExportError: LocalizedError {
    case cannotCreateSession
    case cancelled
    case unknown

    var errorDescription: String? {
        switch self {
        case .cannotCreateSession: return "Couldn't create an export session for this project."
        case .cancelled: return "Export was cancelled."
        case .unknown: return "Export failed for an unknown reason."
        }
    }
}

@MainActor
final class ExportManager: ObservableObject {
    @Published private(set) var isExporting = false
    @Published private(set) var progress: Double = 0

    private var currentSession: AVAssetExportSession?
    private var progressTask: Task<Void, Never>?

    /// Renders `project` through `TimelineEngine` and writes it to `outputURL` using
    /// `preset`. Audio-only presets rely on `AVFileType.m4a` naturally dropping video
    /// tracks rather than building a second, separately-tracked composition - that
    /// keeps the (already-built) `audioMix`'s track references valid.
    func export(project: Project, preset: ExportPreset, to outputURL: URL) async throws {
        if FileManager.default.fileExists(atPath: outputURL.path) {
            try? FileManager.default.removeItem(at: outputURL)
        }

        try await prewarmAudioEffectsCache(for: project)
        let result = try await TimelineEngine.build(project: project, renderSizeOverride: preset.renderSize)

        guard let session = AVAssetExportSession(asset: result.composition, presetName: preset.avPresetName) else {
            throw ExportError.cannotCreateSession
        }
        session.outputURL = outputURL
        session.outputFileType = preset.fileType
        session.shouldOptimizeForNetworkUse = true
        session.audioMix = result.audioMix
        if !preset.isAudioOnly {
            session.videoComposition = result.videoComposition
        }

        currentSession = session
        isExporting = true
        progress = 0

        progressTask = Task { [weak self] in
            while let self, !Task.isCancelled {
                self.progress = Double(session.progress)
                if session.status != .waiting && session.status != .exporting {
                    break
                }
                try? await Task.sleep(nanoseconds: 200_000_000)
            }
        }

        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            session.exportAsynchronously {
                continuation.resume()
            }
        }

        progressTask?.cancel()
        progressTask = nil
        isExporting = false

        switch session.status {
        case .completed:
            progress = 1.0
        case .cancelled:
            throw ExportError.cancelled
        default:
            throw session.error ?? ExportError.unknown
        }
    }

    func cancel() {
        currentSession?.cancelExport()
    }

    /// Unlike live preview, export always renders every effected clip's Audio FX
    /// up front (awaited, so it's guaranteed to reflect current settings even if the
    /// background preview pre-render in `AppState` never got to it) before
    /// `TimelineEngine.build` consumes the resulting cache.
    ///
    /// Cache cleanup runs ONCE, after every clip has already been (re-)rendered - not
    /// per-clip - specifically so clip 2's cleanup can never delete clip 1's
    /// just-rendered file when two clips share a `mediaAssetID` with different effects
    /// (see `AudioEffectsProcessor.garbageCollect(liveKeys:)`'s doc comment).
    private func prewarmAudioEffectsCache(for project: Project) async throws {
        for clip in project.clips {
            let effects = clip.effectiveAudioEffects
            guard !effects.isIdentity, let mediaAsset = project.mediaAsset(clip.mediaAssetID) else { continue }
            _ = try await AudioEffectsProcessor.process(sourceURL: mediaAsset.url, mediaAssetID: mediaAsset.id, effects: effects)
        }
        AudioEffectsProcessor.garbageCollect(liveKeys: AudioEffectsProcessor.liveKeys(for: project))
    }
}
