import AppKit
import Foundation
import SwiftUI

/// Well-known on-disk locations. The app is unsandboxed, so these live under the
/// user's own `Application Support` folder rather than a sandbox container.
enum AppPaths {
    static var applicationSupportDirectory: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        let dir = base.appendingPathComponent("CreativeM Studio", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    static var recordingsDirectory: URL {
        let dir = applicationSupportDirectory.appendingPathComponent("Recordings", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    static var autosaveDirectory: URL {
        let dir = applicationSupportDirectory.appendingPathComponent("Autosave", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    static func newRecordingURL(prefix: String, ext: String = "mov") -> URL {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd 'at' HH.mm.ss"
        let name = "\(prefix) \(formatter.string(from: Date())).\(ext)"
        return recordingsDirectory.appendingPathComponent(name)
    }

    static var cacheDirectory: URL {
        let dir = applicationSupportDirectory.appendingPathComponent("Cache", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    /// A tiny, fixed-size real video file generated once (see `TimelineEngine`) and
    /// reused forever - it exists only to give a composition track genuine, non-zero
    /// `AVComposition` duration for time ranges with no real clip of their own (e.g. a
    /// title-only or image-only project). Its pixel content never reaches the screen,
    /// so it's never regenerated per render size or per project.
    static var blankVideoURL: URL {
        cacheDirectory.appendingPathComponent("blank-pad.mov")
    }

    /// Rendered `AudioEffects` output, one AAC file per (media asset, effects settings)
    /// combination - see `AudioEffectsProcessor`.
    static var audioEffectsCacheDirectory: URL {
        let dir = cacheDirectory.appendingPathComponent("AudioFX", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    /// Synthesized placeholder sample audio ("Sample Library") - see `SampleAudioLibrary`.
    static var sampleAudioDirectory: URL {
        let dir = applicationSupportDirectory.appendingPathComponent("Sample Audio", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }
}

enum TimeFormatting {
    /// Formats seconds as HH:MM:SS (or MM:SS under an hour) for transport/timeline display.
    static func timecode(_ seconds: Double) -> String {
        guard seconds.isFinite, seconds >= 0 else { return "00:00" }
        let total = Int(seconds.rounded())
        let s = total % 60
        let m = (total / 60) % 60
        let h = total / 3600
        if h > 0 {
            return String(format: "%02d:%02d:%02d", h, m, s)
        }
        return String(format: "%02d:%02d", m, s)
    }
}

/// Shared `#RRGGBB` / `#RRGGBBAA` hex parsing used by both the SwiftUI `Color` and
/// AppKit `NSColor` conveniences below.
private func hexRGBA(_ hex: String) -> (Double, Double, Double, Double) {
    let cleaned = hex.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: "#", with: "")
    let value = UInt64(cleaned, radix: 16) ?? 0xFFFFFF
    switch cleaned.count {
    case 8:
        let r = Double((value & 0xFF00_0000) >> 24) / 255
        let g = Double((value & 0x00FF_0000) >> 16) / 255
        let b = Double((value & 0x0000_FF00) >> 8) / 255
        let a = Double(value & 0x0000_00FF) / 255
        return (r, g, b, a)
    default:
        let r = Double((value & 0xFF0000) >> 16) / 255
        let g = Double((value & 0x00FF00) >> 8) / 255
        let b = Double(value & 0x0000FF) / 255
        return (r, g, b, 1.0)
    }
}

extension Color {
    init(hex: String) {
        let (r, g, b, a) = hexRGBA(hex)
        self.init(.sRGB, red: r, green: g, blue: b, opacity: a)
    }

    /// Round-trips back to `#RRGGBB` for storage in `TitleStyle.colorHex`.
    func toHex() -> String {
        guard let components = NSColor(self).usingColorSpace(.deviceRGB) else { return "#FFFFFF" }
        let r = Int((components.redComponent * 255).rounded())
        let g = Int((components.greenComponent * 255).rounded())
        let b = Int((components.blueComponent * 255).rounded())
        return String(format: "#%02X%02X%02X", r, g, b)
    }
}

extension NSColor {
    convenience init(hex: String) {
        let (r, g, b, a) = hexRGBA(hex)
        self.init(srgbRed: r, green: g, blue: b, alpha: a)
    }
}

/// Monitors local key-down events for app-wide transport/editing shortcuts (space,
/// J/K/L, S, delete) so they work regardless of which subview currently has focus.
/// Return `true` from `handler` to consume the event.
final class KeyEventMonitor {
    private var monitor: Any?

    func start(handler: @escaping (NSEvent) -> Bool) {
        stop()
        monitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { event in
            handler(event) ? nil : event
        }
    }

    func stop() {
        if let monitor {
            NSEvent.removeMonitor(monitor)
        }
        monitor = nil
    }

    deinit {
        stop()
    }
}
