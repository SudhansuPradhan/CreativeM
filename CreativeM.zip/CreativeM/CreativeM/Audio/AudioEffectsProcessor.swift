import AVFoundation
import AudioToolbox
import CryptoKit
import Foundation

enum AudioEffectsError: LocalizedError {
    case noAudioTrack
    case renderFailed

    var errorDescription: String? {
        switch self {
        case .noAudioTrack: return "This clip's source has no audio to process."
        case .renderFailed: return "Audio effects rendering failed."
        }
    }
}

/// Renders a clip's "Audio FX" settings (EQ, compression, rumble/gate, reverb) into a
/// cached file using stock Apple AudioUnits, offline, via `AVAudioEngine`'s manual
/// rendering mode. This is intentionally export-only machinery: `TimelineEngine.build`
/// only ever calls `cachedURL` (a fast disk check), never `process` - rendering is
/// triggered explicitly by `ExportManager` (always, awaited, before building the
/// composition) and by `AppState` (best-effort, debounced, so live preview catches up
/// in the background). See `AudioEffects`'s doc comment for why this mirrors the
/// existing title/image "preview \u{2260} export" split.
///
/// "Reduce Rumble" is an honest heuristic - a highpass filter plus a downward
/// expander/gate on the compressor - not spectral noise reduction. Apple ships no stock
/// AudioUnit that does real spectral denoising, so this deliberately doesn't claim to.
///
/// Renders the FULL source file once per (media asset, effects) combination, not just a
/// clip's trimmed range: it's simpler, it lets every clip/trim that shares the same
/// source + settings reuse one cached file, and a reverb tail actually sounds *better*
/// with real pre-roll context than it would processing an isolated trimmed segment.
enum AudioEffectsProcessor {

    // MARK: - Cache

    /// Verified empirically that plain `JSONEncoder().encode(_:)` does NOT reliably
    /// reproduce the same byte output for an identical `Codable` struct value across
    /// separate calls (its keyed container's key order can differ run to run - the
    /// first encode of a process differed from every subsequent one in testing), which
    /// would silently defeat this cache (a fresh "is this cached?" check could compute a
    /// different hash than the render that just wrote it). `.sortedKeys` output
    /// formatting fixes this - verified deterministic across both repeated in-process
    /// calls and separate process launches.
    private static func cacheKey(mediaAssetID: UUID, effects: AudioEffects) throws -> String {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        let data = try encoder.encode(effects)
        let digest = SHA256.hash(data: data)
        let hex = digest.map { String(format: "%02x", $0) }.joined()
        return "\(mediaAssetID.uuidString)-\(hex)"
    }

    private static func cacheURL(key: String) -> URL {
        AppPaths.audioEffectsCacheDirectory.appendingPathComponent("\(key).m4a")
    }

    /// Fast, non-blocking lookup - returns nil (never renders) if nothing is cached yet
    /// for this exact (media asset, effects) combination, or if `effects` is identity.
    static func cachedURL(mediaAssetID: UUID, effects: AudioEffects) -> URL? {
        guard !effects.isIdentity, let key = try? cacheKey(mediaAssetID: mediaAssetID, effects: effects) else { return nil }
        let url = cacheURL(key: key)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    // MARK: - Render

    /// Renders (or returns the already-cached result for) `effects` applied to
    /// `sourceURL`'s audio. `sourceURL` may be a bare audio file or a movie container
    /// (`AVAudioFile(forReading:)` transparently demuxes either - verified empirically).
    @discardableResult
    static func process(sourceURL: URL, mediaAssetID: UUID, effects: AudioEffects) async throws -> URL {
        let key = try cacheKey(mediaAssetID: mediaAssetID, effects: effects)
        let outputURL = cacheURL(key: key)
        if FileManager.default.fileExists(atPath: outputURL.path) { return outputURL }

        // Two callers can legitimately race for the SAME (mediaAssetID, effects): the
        // debounced background preview prewarm and `ExportManager`'s own prewarm, or two
        // clips that share a `mediaAssetID` (e.g. a duplicated clip) both getting tweaked
        // around the same time. Sharing one in-flight render per exact key avoids wasted
        // duplicate renders (reproduced and fixed before shipping; see `InFlightRenders`
        // below). Note this function no longer deletes anything on the way in - cache
        // eviction is a separate, explicit, whole-project-aware pass (see
        // `garbageCollect(liveKeys:)`), precisely because deleting "stale" variants
        // per-render is NOT safe when two different clips share a `mediaAssetID` with
        // different effects: a naive "delete anything for this asset that isn't my key"
        // pass deletes the OTHER clip's still-needed cached file, deterministically,
        // every time - reproduced empirically (no concurrency needed - a plain
        // sequential two-clip export loop triggers it every time).
        //
        // The check-for-existing-task and register-a-new-one steps MUST happen as one
        // atomic actor call, not two separate `await`s: a two-call version has a TOCTOU
        // gap where two concurrent callers can both observe "nothing registered yet" and
        // each start their own redundant render for the identical key - reproduced
        // empirically, it crashes later with a `moveItem` "File exists" error when both
        // finish around the same moment and race on the same destination path.
        let task = await InFlightRenders.shared.task(for: key) {
            Task<URL, Error> {
                try await Self.render(sourceURL: sourceURL, mediaAssetID: mediaAssetID, effects: effects, key: key, outputURL: outputURL)
            }
        }
        defer { Task { await InFlightRenders.shared.clear(key) } }
        return try await task.value
    }

    private static func render(sourceURL: URL, mediaAssetID: UUID, effects: AudioEffects, key: String, outputURL: URL) async throws -> URL {
        let sourceFile = try AVAudioFile(forReading: sourceURL)
        guard sourceFile.length > 0 else { throw AudioEffectsError.noAudioTrack }
        let readFormat = sourceFile.processingFormat
        let stereoFormat = AVAudioFormat(standardFormatWithSampleRate: readFormat.sampleRate, channels: 2) ?? readFormat

        let engine = AVAudioEngine()
        let player = AVAudioPlayerNode()
        let eq = AVAudioUnitEQ(numberOfBands: 4)
        configureEQ(eq, effects: effects)

        let compDesc = AudioComponentDescription(
            componentType: kAudioUnitType_Effect,
            componentSubType: kAudioUnitSubType_DynamicsProcessor,
            componentManufacturer: kAudioUnitManufacturer_Apple,
            componentFlags: 0,
            componentFlagsMask: 0
        )
        let compressor = AVAudioUnitEffect(audioComponentDescription: compDesc)

        let reverb = AVAudioUnitReverb()
        reverb.loadFactoryPreset(effects.reverbPreset.avPreset)
        reverb.wetDryMix = Float(max(0, min(1, effects.reverbAmount))) * 100

        engine.attach(player)
        engine.attach(eq)
        engine.attach(compressor)
        engine.attach(reverb)
        engine.connect(player, to: eq, format: readFormat)
        engine.connect(eq, to: compressor, format: readFormat)
        engine.connect(compressor, to: reverb, format: readFormat)
        // AVAudioUnitReverb's OUTPUT bus is hardwired stereo no matter what feeds it -
        // verified empirically (t8b-e): forcing anything else here throws an uncaught
        // NSException (NSOSStatusErrorDomain -10868) that aborts the process outright;
        // Swift try/catch cannot catch it.
        engine.connect(reverb, to: engine.mainMixerNode, format: stereoFormat)

        try engine.enableManualRenderingMode(.offline, format: stereoFormat, maximumFrameCount: 4096)
        // Must configure AU parameters AFTER the node is attached/connected and the
        // engine's graph is set up, matching how `compressor.auAudioUnit` was exercised
        // in verification (t8) - its parameterTree is populated at that point.
        configureCompressor(compressor, effects: effects)
        try engine.start()

        // Deliberately the explicit completion-handler overload, not `await
        // player.scheduleFile(sourceFile, at: nil)`: verified empirically that in a
        // compiled (non-interpreted) build, the async overload Xcode resolves this to
        // hangs indefinitely here under manual rendering mode - this file's own render
        // loop below is what's supposed to drive playback forward, so there's nothing
        // left to service whatever the async overload is actually waiting on. The
        // explicit form is fire-and-forget like the old completion-handler API always
        // was, which is all this needs: `renderOffline` below pulls data through
        // regardless of when (or whether) this closure ever runs.
        player.scheduleFile(sourceFile, at: nil, completionCallbackType: .dataRendered) { _ in }
        player.play()

        let tailSeconds = 2.0 // headroom for the reverb tail to ring out
        let totalFrames = sourceFile.length + AVAudioFramePosition(readFormat.sampleRate * tailSeconds)

        // Written to a temp file first, then moved into place, so a mid-render
        // failure/kill never leaves a half-written file masquerading as a cache hit.
        let tempURL = AppPaths.audioEffectsCacheDirectory.appendingPathComponent("\(key)-\(UUID().uuidString).tmp.m4a")
        do {
            try renderOffline(engine: engine, totalFrames: totalFrames, outputURL: tempURL, sampleRate: stereoFormat.sampleRate)
        } catch {
            try? FileManager.default.removeItem(at: tempURL)
            throw error
        }

        try? FileManager.default.removeItem(at: outputURL)
        try FileManager.default.moveItem(at: tempURL, to: outputURL)
        return outputURL
    }

    /// Scoped so the writing `AVAudioFile` deallocates (finalizing the AAC container)
    /// before any caller tries to read `outputURL` back - verified empirically (t9) that
    /// an AAC file opened for writing is unreadable until its `AVAudioFile` goes out of
    /// scope.
    private static func renderOffline(engine: AVAudioEngine, totalFrames: AVAudioFramePosition, outputURL: URL, sampleRate: Double) throws {
        let aacSettings: [String: Any] = [
            AVFormatIDKey: kAudioFormatMPEG4AAC,
            AVSampleRateKey: sampleRate,
            AVNumberOfChannelsKey: 2,
            AVEncoderBitRateKey: 128_000
        ]
        let outputFile = try AVAudioFile(forWriting: outputURL, settings: aacSettings, commonFormat: .pcmFormatFloat32, interleaved: false)
        guard let buffer = AVAudioPCMBuffer(pcmFormat: engine.manualRenderingFormat, frameCapacity: engine.manualRenderingMaximumFrameCount) else {
            throw AudioEffectsError.renderFailed
        }
        var rendered: AVAudioFramePosition = 0
        while rendered < totalFrames {
            let framesToRender = min(buffer.frameCapacity, AVAudioFrameCount(totalFrames - rendered))
            let status = try engine.renderOffline(framesToRender, to: buffer)
            switch status {
            case .success:
                try outputFile.write(from: buffer)
                rendered += AVAudioFramePosition(buffer.frameLength)
            case .insufficientDataFromInputNode:
                rendered = totalFrames
            case .cannotDoInCurrentContext:
                continue
            case .error:
                throw AudioEffectsError.renderFailed
            @unknown default:
                throw AudioEffectsError.renderFailed
            }
        }
    }

    // MARK: - Cache cleanup

    /// Every distinct effects tweak leaves its own ~1MB/min AAC file in the cache
    /// directory forever unless something cleans it up (flagged in review: unbounded
    /// cache growth from repeated slider drags). Cleanup is deliberately NOT done inside
    /// `render` on a per-call, single-key basis - an earlier version did exactly that
    /// (`removeStaleVariants(mediaAssetID:keeping:)`, deleting anything for the same
    /// asset other than the one key just rendered) and it was wrong: when two clips in
    /// the same project share a `mediaAssetID` but have different effects (e.g. a split
    /// or duplicated clip with one half tweaked differently), rendering clip 2 would
    /// delete clip 1's just-rendered, still-needed cache file - deterministically, no
    /// concurrency required, reproduced via a plain sequential two-clip export.
    ///
    /// Instead, call `garbageCollect(liveKeys:)` at a safe point - after every clip that
    /// needs rendering has already been (re-)rendered - with the FULL set of keys every
    /// clip in the project currently needs (`liveKeys(for:)`), so cleanup only ever
    /// removes files nothing in the project depends on anymore.
    static func liveKeys(for project: Project) -> Set<String> {
        var keys = Set<String>()
        for clip in project.clips {
            let effects = clip.effectiveAudioEffects
            // Resolve through `project.mediaAsset(_:)` (like `ExportManager` does) rather
            // than keying off `clip.mediaAssetID` directly - it's `UUID?` and isn't
            // guaranteed to resolve to a real `MediaAsset` in `project.mediaAssets`.
            guard !effects.isIdentity,
                  let mediaAsset = project.mediaAsset(clip.mediaAssetID),
                  let key = try? cacheKey(mediaAssetID: mediaAsset.id, effects: effects) else { continue }
            keys.insert(key)
        }
        return keys
    }

    /// Deletes every cached Audio FX file whose key isn't in `liveKeys`. Always skips
    /// `.tmp.` entries - those are a different, still-in-flight render's not-yet-moved
    /// output (per-render-unique via a UUID suffix), which must never be touched here
    /// regardless of whether its eventual key turns out to be live or not.
    static func garbageCollect(liveKeys: Set<String>) {
        let dir = AppPaths.audioEffectsCacheDirectory
        guard let entries = try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil) else { return }
        for entry in entries {
            let name = entry.lastPathComponent
            guard !name.contains(".tmp.") else { continue }
            let key = name.hasSuffix(".m4a") ? String(name.dropLast(4)) : name
            if !liveKeys.contains(key) {
                try? FileManager.default.removeItem(at: entry)
            }
        }
    }

    // MARK: - AudioUnit configuration

    private static func configureEQ(_ eq: AVAudioUnitEQ, effects: AudioEffects) {
        eq.bands[0].filterType = .lowShelf
        eq.bands[0].frequency = 120
        eq.bands[0].gain = Float(effects.eqLowGainDB)
        eq.bands[0].bypass = false

        eq.bands[1].filterType = .parametric
        eq.bands[1].frequency = 1000
        eq.bands[1].bandwidth = 1.0
        eq.bands[1].gain = Float(effects.eqMidGainDB)
        eq.bands[1].bypass = false

        eq.bands[2].filterType = .highShelf
        eq.bands[2].frequency = 8000
        eq.bands[2].gain = Float(effects.eqHighGainDB)
        eq.bands[2].bypass = false

        // "Reduce Rumble": a highpass whose corner frequency rises from ~20Hz (off) to
        // ~220Hz (aggressive) with `reduceRumbleAmount`.
        let amount = max(0, min(1, effects.reduceRumbleAmount))
        eq.bands[3].filterType = .highPass
        eq.bands[3].frequency = 20 + Float(amount) * 200
        eq.bands[3].bypass = amount <= 0
    }

    /// Parameter indices verified empirically against the live `AUParameterTree` (not
    /// hardcoded from recalled `kDynamicsProcessorParam_*` constants) to match: 0
    /// threshold (dB), 1 headroom (dB), 2 expansion ratio, 3 expansion threshold (dB),
    /// 4 attack (s), 5 release (s), 6 master gain (dB).
    private static func configureCompressor(_ compressor: AVAudioUnitEffect, effects: AudioEffects) {
        guard let params = compressor.auAudioUnit.parameterTree?.allParameters, params.count >= 7 else { return }

        let compAmount = max(0, min(1, effects.compressionAmount))
        params[0].value = Float(0 - compAmount * 40)   // threshold: 0dB (off) ... -40dB (heavy)
        params[6].value = Float(compAmount * 6)         // master gain: makeup for perceived loudness loss

        let gateAmount = max(0, min(1, effects.reduceRumbleAmount))
        params[2].value = Float(1 + gateAmount * 7)         // expansion ratio: 1 (off) ... 8
        params[3].value = Float(-100 + gateAmount * 50)     // expansion threshold: -100dB (off) ... -50dB
    }
}

/// Tracks one in-flight render `Task` per exact cache key so concurrent callers for the
/// identical (media asset, effects) combination share a single render instead of each
/// starting a redundant, wasteful one. Keyed by the full cache key (not just
/// `mediaAssetID`) so unrelated effects settings on the same asset still render
/// independently - safe because `garbageCollect(liveKeys:)` only ever runs after
/// rendering finishes (not per-render) and always skips `.tmp.` entries.
private actor InFlightRenders {
    static let shared = InFlightRenders()
    private var tasks: [String: Task<URL, Error>] = [:]

    /// Atomically returns the already-running task for `key`, or creates one via `make`,
    /// registers it, and returns that - as a single actor-isolated operation so there's
    /// no gap between "check" and "register" for a second caller to slip through. See
    /// the call site in `process(sourceURL:mediaAssetID:effects:)` for why a two-call
    /// (check, then separately register) version is unsafe.
    func task(for key: String, make: () -> Task<URL, Error>) -> Task<URL, Error> {
        if let existing = tasks[key] { return existing }
        let task = make()
        tasks[key] = task
        return task
    }

    func clear(_ key: String) { tasks[key] = nil }
}

private extension ReverbPresetOption {
    var avPreset: AVAudioUnitReverbPreset {
        switch self {
        case .smallRoom: return .smallRoom
        case .mediumRoom: return .mediumRoom
        case .largeRoom: return .largeRoom
        case .mediumHall: return .mediumHall
        case .largeHall: return .largeHall
        case .plate: return .plate
        case .cathedral: return .cathedral
        }
    }
}
