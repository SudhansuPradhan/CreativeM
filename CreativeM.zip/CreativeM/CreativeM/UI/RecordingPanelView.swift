import AVFoundation
import SwiftUI

/// Which tab `RecordingPanelView` opens on. Lives at module scope (not nested in
/// the view) so `AppState.recordingPanelMode` can be the single source of truth -
/// the Record menu commands set it before presenting the sheet, so "Record Screen..."
/// actually opens on the Screen tab instead of always landing on Camera + Mic.
enum RecordingMode: String, CaseIterable, Identifiable {
    case camera = "Camera + Mic"
    case screen = "Screen"
    case systemAudio = "System Audio"
    case microphone = "Microphone"
    var id: String { rawValue }
}

/// `cameraMicRecorder`/`screenRecorder` are passed in explicitly (rather than reached
/// via `appState.cameraMicRecorder`) and held as `@ObservedObject` here, because a
/// nested object's `@Published` changes don't propagate through `AppState`'s own
/// `ObservableObject` conformance - this view needs to observe them directly to
/// update live (recording timer, button state) while a recording is running.
struct RecordingPanelView: View {
    @EnvironmentObject var appState: AppState
    @ObservedObject var cameraMicRecorder: CameraMicRecorder
    @ObservedObject var screenRecorder: ScreenRecorder
    @ObservedObject var systemAudioRecorder: SystemAudioRecorder
    @ObservedObject var micRecorder: MicRecorder
    @Environment(\.dismiss) private var dismiss

    init(cameraMicRecorder: CameraMicRecorder, screenRecorder: ScreenRecorder, systemAudioRecorder: SystemAudioRecorder, micRecorder: MicRecorder) {
        self.cameraMicRecorder = cameraMicRecorder
        self.screenRecorder = screenRecorder
        self.systemAudioRecorder = systemAudioRecorder
        self.micRecorder = micRecorder
    }

    var body: some View {
        VStack(spacing: 16) {
            Text("Record").font(.title2.bold())

            Picker("", selection: $appState.recordingPanelMode) {
                ForEach(RecordingMode.allCases) { m in
                    Text(m.rawValue).tag(m)
                }
            }
            .pickerStyle(.segmented)
            .labelsHidden()

            switch appState.recordingPanelMode {
            case .camera: cameraSection
            case .screen: screenSection
            case .systemAudio: systemAudioSection
            case .microphone: microphoneSection
            }

            Divider()

            HStack {
                Button("Close") { closePanel() }
                Spacer()
            }
        }
        .padding(20)
        .frame(width: 440)
        .task {
            await screenRecorder.refreshDisplays()
            cameraMicRecorder.refreshDevices()
            micRecorder.refreshDevices()
        }
    }

    private func closePanel() {
        if cameraMicRecorder.isRecording { appState.stopCameraRecording() }
        if screenRecorder.isRunning { appState.stopScreenRecording() }
        if systemAudioRecorder.isRunning { appState.stopSystemAudioRecording() }
        if micRecorder.isRecording || micRecorder.isSessionRunning { appState.stopMicRecording() }
        dismiss()
    }

    private var cameraSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Picker("Camera", selection: Binding(
                get: { cameraMicRecorder.selectedCameraID ?? "" },
                set: { cameraMicRecorder.selectedCameraID = $0 }
            )) {
                ForEach(cameraMicRecorder.availableCameras, id: \.uniqueID) { device in
                    Text(device.localizedName).tag(device.uniqueID)
                }
            }

            Picker("Microphone", selection: Binding(
                get: { cameraMicRecorder.selectedMicrophoneID ?? "" },
                set: { cameraMicRecorder.selectedMicrophoneID = $0 }
            )) {
                ForEach(cameraMicRecorder.availableMicrophones, id: \.uniqueID) { device in
                    Text(device.localizedName).tag(device.uniqueID)
                }
            }

            if cameraMicRecorder.isRecording {
                Text(TimeFormatting.timecode(cameraMicRecorder.elapsedSeconds))
                    .font(.system(.title, design: .monospaced))
                    .foregroundStyle(.red)
            }

            Button {
                if cameraMicRecorder.isRecording {
                    appState.stopCameraRecording()
                } else {
                    appState.startCameraRecording()
                }
            } label: {
                Label(
                    cameraMicRecorder.isRecording ? "Stop Recording" : "Start Recording",
                    systemImage: cameraMicRecorder.isRecording ? "stop.circle.fill" : "record.circle"
                )
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .tint(cameraMicRecorder.isRecording ? .red : .accentColor)

            if let error = cameraMicRecorder.lastError {
                Text(error).font(.caption).foregroundStyle(.red)
            }
        }
    }

    private var screenSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            if screenRecorder.availableDisplays.isEmpty {
                Text("No displays found yet - this may prompt for Screen Recording permission.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                Picker("Display", selection: Binding(
                    get: { screenRecorder.selectedDisplayID ?? screenRecorder.availableDisplays[0].displayID },
                    set: { screenRecorder.selectedDisplayID = $0 }
                )) {
                    ForEach(screenRecorder.availableDisplays, id: \.displayID) { display in
                        Text("Display \(display.displayID)").tag(display.displayID)
                    }
                }
            }

            Toggle("Include System Audio", isOn: $screenRecorder.includeSystemAudio)

            if screenRecorder.isRunning {
                Text(TimeFormatting.timecode(screenRecorder.elapsedSeconds))
                    .font(.system(.title, design: .monospaced))
                    .foregroundStyle(.red)
            }

            Button {
                if screenRecorder.isRunning {
                    appState.stopScreenRecording()
                } else {
                    appState.startScreenRecording()
                }
            } label: {
                Label(
                    screenRecorder.isRunning ? "Stop Recording" : "Start Recording",
                    systemImage: screenRecorder.isRunning ? "stop.circle.fill" : "record.circle"
                )
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .tint(screenRecorder.isRunning ? .red : .accentColor)

            Text("The first time you record your screen, macOS will ask you to enable Screen Recording for CreativeM in System Settings > Privacy & Security - you may need to quit and reopen the app afterwards.")
                .font(.caption)
                .foregroundStyle(.secondary)

            if let error = screenRecorder.lastError {
                Text(error).font(.caption).foregroundStyle(.red)
            }
        }
    }

    private var systemAudioSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Captures whatever's currently playing on your Mac - a YouTube tab, Music, Zoom, anything - as an audio-only clip. This is the way to pull audio out of a video you don't have a file for, including YouTube: play it, then hit Start.")
                .font(.caption)
                .foregroundStyle(.secondary)

            if systemAudioRecorder.isRunning {
                Text(TimeFormatting.timecode(systemAudioRecorder.elapsedSeconds))
                    .font(.system(.title, design: .monospaced))
                    .foregroundStyle(.red)
            }

            Button {
                if systemAudioRecorder.isRunning {
                    appState.stopSystemAudioRecording()
                } else {
                    appState.startSystemAudioRecording()
                }
            } label: {
                Label(
                    systemAudioRecorder.isRunning ? "Stop Recording" : "Start Recording",
                    systemImage: systemAudioRecorder.isRunning ? "stop.circle.fill" : "record.circle"
                )
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .tint(systemAudioRecorder.isRunning ? .red : .accentColor)

            Text("The first time you record system audio, macOS will ask you to enable Screen Recording for CreativeM in System Settings > Privacy & Security - the same permission screen recording uses - you may need to quit and reopen the app afterwards.")
                .font(.caption)
                .foregroundStyle(.secondary)

            if let error = systemAudioRecorder.lastError {
                Text(error).font(.caption).foregroundStyle(.red)
            }
        }
    }

    private var microphoneSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Picker("Microphone", selection: Binding(
                get: { micRecorder.selectedMicrophoneID ?? "" },
                set: { micRecorder.selectedMicrophoneID = $0 }
            )) {
                ForEach(micRecorder.availableMicrophones, id: \.uniqueID) { device in
                    Text(device.localizedName).tag(device.uniqueID)
                }
            }

            Picker("Voice Effect", selection: $appState.micVoicePreset) {
                ForEach(MicVoicePreset.allCases) { preset in
                    Text(preset.displayName).tag(preset)
                }
            }
            .disabled(micRecorder.isRecording)

            Text("Recording is always clean; the effect is applied right after you stop, non-destructively - tweak it further anytime in the Inspector's Audio FX section.")
                .font(.caption2)
                .foregroundStyle(.secondary)

            if micRecorder.isRecording {
                Text(TimeFormatting.timecode(micRecorder.elapsedSeconds))
                    .font(.system(.title, design: .monospaced))
                    .foregroundStyle(.red)
            }

            Button {
                if micRecorder.isRecording {
                    appState.stopMicRecording()
                } else {
                    appState.startMicRecording()
                }
            } label: {
                Label(
                    micRecorder.isRecording ? "Stop Recording" : "Start Recording",
                    systemImage: micRecorder.isRecording ? "stop.circle.fill" : "record.circle"
                )
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .tint(micRecorder.isRecording ? .red : .accentColor)

            if let error = micRecorder.lastError {
                Text(error).font(.caption).foregroundStyle(.red)
            }
        }
    }
}
