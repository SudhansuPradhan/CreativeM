import AppKit
import SwiftUI

struct ContentView: View {
    @EnvironmentObject var appState: AppState
    @State private var keyMonitor = KeyEventMonitor()

    var body: some View {
        VStack(spacing: 0) {
            toolbar
            Divider()

            VSplitView {
                HSplitView {
                    MediaLibraryView()
                        .frame(minWidth: 220, idealWidth: 260, maxWidth: 420)
                    PreviewPlayerView()
                        .frame(minWidth: 420, minHeight: 260)
                    InspectorView()
                        .frame(minWidth: 260, idealWidth: 300, maxWidth: 420)
                }
                .layoutPriority(1)

                TimelineView()
                    .frame(minHeight: 220, idealHeight: 300)
            }

            Divider()
            statusBar
        }
        .sheet(isPresented: $appState.showRecordingPanel) {
            RecordingPanelView(cameraMicRecorder: appState.cameraMicRecorder, screenRecorder: appState.screenRecorder, systemAudioRecorder: appState.systemAudioRecorder, micRecorder: appState.micRecorder)
                .environmentObject(appState)
        }
        .sheet(isPresented: $appState.showExportSheet) {
            ExportSheetView(exportManager: appState.exportManager)
                .environmentObject(appState)
        }
        .sheet(isPresented: $appState.showCaptionsPanel) {
            CaptionsPanelView().environmentObject(appState)
        }
        .onAppear { startKeyMonitor() }
        .onDisappear { keyMonitor.stop() }
    }

    // MARK: Toolbar

    private var toolbar: some View {
        HStack(spacing: 10) {
            Button { appState.showRecordingPanel = true } label: {
                Label("Record", systemImage: "record.circle")
            }
            Button { importMedia() } label: {
                Label("Import Media", systemImage: "square.and.arrow.down")
            }

            Divider().frame(height: 18)

            Button { appState.addTitleClip(atSeconds: appState.playheadSeconds) } label: {
                Label("Add Title", systemImage: "textformat")
            }
            Button { appState.addAudioTrack() } label: {
                Label("Add Audio Track", systemImage: "waveform")
            }

            Spacer()

            if appState.isBusy {
                ProgressView(appState.busyMessage)
                    .controlSize(.small)
                    .frame(maxWidth: 260)
            }

            Button { appState.showCaptionsPanel = true } label: {
                Label("Captions", systemImage: "captions.bubble")
            }
            Button { appState.showExportSheet = true } label: {
                Label("Export", systemImage: "square.and.arrow.up")
            }
        }
        .buttonStyle(.bordered)
        .labelStyle(.titleAndIcon)
        .padding(10)
        .background(Color(nsColor: .windowBackgroundColor))
    }

    // MARK: Status bar

    private var statusBar: some View {
        HStack {
            Text(appState.project.name)
                .font(.caption)
                .foregroundStyle(.secondary)
            if appState.isDirty {
                Text("- Edited")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if let message = appState.statusMessage {
                Text(message)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 4)
    }

    // MARK: Actions

    private func importMedia() {
        let panel = NSOpenPanel()
        panel.title = "Import Media"
        panel.canChooseFiles = true
        panel.canChooseDirectories = false
        panel.allowsMultipleSelection = true
        panel.begin { response in
            guard response == .OK else { return }
            let urls = panel.urls
            Task { await appState.importMedia(urls: urls) }
        }
    }

    /// Bare-letter transport shortcuts (space/S/delete), matching NLE convention.
    /// Cmd-based shortcuts live in `CreativeMApp`'s menu commands instead; these
    /// deliberately check for text-field focus first so typing a title/clip name
    /// doesn't accidentally trigger split/delete/play.
    private func startKeyMonitor() {
        keyMonitor.start { event in
            if let responder = NSApp.keyWindow?.firstResponder, responder is NSTextView {
                return false
            }
            if event.keyCode == 51 || event.keyCode == 117 { // delete / forward-delete
                appState.deleteSelectedClip()
                return true
            }
            switch event.charactersIgnoringModifiers?.lowercased() {
            case " ":
                appState.togglePlayback()
                return true
            case "s":
                appState.splitAtPlayhead()
                return true
            default:
                return false
            }
        }
    }
}
