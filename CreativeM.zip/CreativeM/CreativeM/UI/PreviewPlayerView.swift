import AVKit
import SwiftUI

struct PreviewPlayerView: View {
    @EnvironmentObject var appState: AppState
    @State private var imageCache = ImageOverlayCache()

    var body: some View {
        VStack(spacing: 8) {
            ZStack {
                PlayerContainerView(player: appState.player)
                overlayContent
                    .allowsHitTesting(false)
            }
            .background(Color.black)
            .cornerRadius(6)
            .padding([.horizontal, .top], 10)
            .onChange(of: activeImageClipIDs, initial: true) { _, newIDs in
                imageCache.loadMissing(newIDs, project: appState.project)
            }

            controls
                .padding(.horizontal, 10)
                .padding(.bottom, 8)
        }
    }

    // MARK: Title/image overlay
    //
    // `TimelineEngine` can't burn titles/images into the *live* player item (the
    // CoreAnimation tool it uses for that is export-only - see `TimelineEngine.build`'s
    // `forPreview` flag), so this renders the same content a second way: plain SwiftUI,
    // gated by `playheadSeconds`, drawn as a sibling over the player view.
    //
    // This is a visual approximation, not a WYSIWYG match for what export actually
    // burns in - font metrics and exactly where the fitted video box sits may not line
    // up pixel-for-pixel with `TimelineEngine.buildAnimationTool`'s CALayer version.
    // Burn-in captions have the same live-preview gap but aren't covered here; this is
    // scoped to what was reported (titles + images).

    private var renderSize: CGSize {
        let size = appState.project.renderSize.size
        return (size.width > 0 && size.height > 0) ? size : CGSize(width: 1920, height: 1080)
    }

    @ViewBuilder
    private var overlayContent: some View {
        ZStack {
            ForEach(activeImageClips) { clip in
                if let assetID = clip.mediaAssetID, let image = imageCache.store[assetID] {
                    Image(nsImage: image)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .opacity(overlayOpacity(for: clip, fade: 0.3))
                }
            }
            ForEach(activeTitleClips) { clip in
                if let style = clip.title {
                    titleText(style)
                        .opacity(overlayOpacity(for: clip, fade: style.fadeDuration.seconds))
                }
            }
        }
        .aspectRatio(renderSize, contentMode: .fit)
    }

    private func titleText(_ style: TitleStyle) -> some View {
        VStack {
            if style.position != .top { Spacer() }
            Text(style.text)
                .font(.custom(style.fontName, size: CGFloat(style.fontSize) * 0.4))
                .foregroundColor(Color(hex: style.colorHex))
                .multilineTextAlignment(.center)
                .padding(8)
                .background(Color.black.opacity(style.backgroundOpacity))
            if style.position != .bottom { Spacer() }
        }
        .padding(20)
    }

    private var activeTitleClips: [Clip] {
        guard let track = appState.project.titleTrack else { return [] }
        let t = appState.playheadSeconds
        return appState.project.clips(on: track.id).filter { t >= $0.startTime.seconds && t <= $0.endTime.seconds }
    }

    /// Clips on the video track whose backing asset is a still image - filtered by the
    /// *asset's* kind, not `clip.kind` (an image dropped on the video track still reports
    /// `ClipKind.video`; see `InspectorView.isImageClip`).
    private var activeImageClips: [Clip] {
        guard let track = appState.project.videoTrack else { return [] }
        let t = appState.playheadSeconds
        return appState.project.clips(on: track.id).filter { clip in
            guard t >= clip.startTime.seconds, t <= clip.endTime.seconds else { return false }
            return appState.project.mediaAsset(clip.mediaAssetID)?.kind == .image
        }
    }

    private var activeImageClipIDs: Set<UUID> {
        Set(activeImageClips.compactMap(\.mediaAssetID))
    }

    private func overlayOpacity(for clip: Clip, fade: Double) -> Double {
        let start = clip.startTime.seconds
        let end = clip.endTime.seconds
        let t = appState.playheadSeconds
        guard t >= start, t <= end, end > start else { return 0 }
        let clampedFade = max(0.001, min(fade, (end - start) * 0.49))
        if t < start + clampedFade { return (t - start) / clampedFade }
        if t > end - clampedFade { return (end - t) / clampedFade }
        return 1
    }

    private var controls: some View {
        HStack(spacing: 12) {
            Text(TimeFormatting.timecode(appState.playheadSeconds))
                .font(.system(.caption, design: .monospaced))
                .frame(width: 60, alignment: .leading)

            Slider(
                value: Binding(
                    get: { appState.playheadSeconds },
                    set: { newValue in appState.seek(toSeconds: newValue) }
                ),
                in: 0...max(appState.project.duration.seconds, 0.1),
                onEditingChanged: { editing in appState.isScrubbing = editing }
            )

            Text(TimeFormatting.timecode(appState.project.duration.seconds))
                .font(.system(.caption, design: .monospaced))
                .frame(width: 60, alignment: .trailing)

            Button {
                appState.togglePlayback()
            } label: {
                Image(systemName: appState.isPlaying ? "pause.fill" : "play.fill")
                    .frame(width: 16)
            }
            .buttonStyle(.borderedProminent)
        }
    }
}

/// Thin `NSViewRepresentable` wrapper around `AVPlayerView` with its own chrome
/// disabled - `PreviewPlayerView` draws the transport controls itself so they can
/// stay in sync with the timeline's playhead/selection state.
struct PlayerContainerView: NSViewRepresentable {
    let player: AVPlayer

    func makeNSView(context: Context) -> AVPlayerView {
        let view = AVPlayerView()
        view.player = player
        view.controlsStyle = .none
        view.showsFullScreenToggleButton = false
        return view
    }

    func updateNSView(_ nsView: AVPlayerView, context: Context) {
        if nsView.player !== player {
            nsView.player = player
        }
    }
}

/// Lazily loads and caches full-resolution `NSImage`s for image clips currently active
/// in the preview overlay, keyed by `MediaAsset.id`.
///
/// Deliberately a plain reference type, not `ObservableObject` - held in `@State` so
/// `PreviewPlayerView`'s struct value keeps the same instance across re-renders, but
/// writes to `store` don't themselves trigger a SwiftUI update. Population happens from
/// `.onChange` of the active-clip-ID set (not inline during `body` evaluation, which
/// risks a re-render loop); the next natural re-render - the next playhead tick, at most
/// ~1/30s later - picks up whatever was just cached.
final class ImageOverlayCache {
    private(set) var store: [UUID: NSImage] = [:]

    func loadMissing(_ ids: Set<UUID>, project: Project) {
        for id in ids where store[id] == nil {
            guard let asset = project.mediaAssets.first(where: { $0.id == id }),
                  let image = NSImage(contentsOf: asset.url) else { continue }
            store[id] = image
        }
    }
}
