import AppKit
import SwiftUI

struct MediaLibraryView: View {
    @EnvironmentObject var appState: AppState
    @State private var showURLImporter = false
    @State private var urlString = ""
    @State private var urlImportError: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Text("Media Pool")
                    .font(.headline)
                Spacer()
                Button {
                    urlImportError = nil
                    showURLImporter = true
                } label: {
                    Label("Import from URL", systemImage: "link.badge.plus")
                        .font(.caption)
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
                .help("Downloads a direct link to an audio or video file. YouTube links aren't supported - use Record > Record System Audio to capture a YouTube video's audio as it plays instead.")
                .popover(isPresented: $showURLImporter) {
                    urlImporterPopover
                }
                Button {
                    appState.addSampleAudioToLibrary()
                } label: {
                    Label("Add Sample Audio", systemImage: "waveform.badge.plus")
                        .font(.caption)
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
                .help("Adds \(SampleAudioLibrary.samples.count) generated placeholder audio clips - ambient pads, cinematic drones/risers, trailer hits, and rhythmic beds - synthesized locally, not licensed stock music.")
            }
            .padding(.horizontal, 12)
            .padding(.top, 10)
            .padding(.bottom, 6)

            if appState.project.mediaAssets.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "tray")
                        .font(.system(size: 28))
                        .foregroundStyle(.secondary)
                    Text("No media yet")
                        .foregroundStyle(.secondary)
                    Text("Import files or record to get started.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding()
            } else {
                Text("Double-click, or use the + button, to add a clip to the timeline.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal, 12)
                    .padding(.bottom, 4)
                List {
                    ForEach(appState.project.mediaAssets) { asset in
                        MediaAssetRow(asset: asset, onAdd: { addToTimeline(asset) })
                            .contentShape(Rectangle())
                            .onTapGesture(count: 2) { addToTimeline(asset) }
                            .contextMenu {
                                Button("Add to End of Timeline") { addToTimeline(asset) }
                                Button("Add at Playhead") { addAtPlayhead(asset) }
                            }
                    }
                }
                .listStyle(.inset)
            }
        }
    }

    private func addToTimeline(_ asset: MediaAsset) {
        let trackKind: TrackKind = asset.kind == .audio ? .audio : .video
        guard let track = appState.project.tracks.first(where: { $0.kind == trackKind }) else { return }
        appState.appendClipToEnd(of: track.id, mediaAsset: asset)
    }

    private func addAtPlayhead(_ asset: MediaAsset) {
        let trackKind: TrackKind = asset.kind == .audio ? .audio : .video
        guard let track = appState.project.tracks.first(where: { $0.kind == trackKind }) else { return }
        appState.insertClip(mediaAsset: asset, trackID: track.id, atSeconds: appState.playheadSeconds)
    }

    private var urlImporterPopover: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Import from URL").font(.headline)
            Text("Paste a direct link to an audio or video file you have rights to use.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .frame(width: 260, alignment: .leading)

            TextField("https://example.com/track.mp3", text: $urlString)
                .textFieldStyle(.roundedBorder)
                .frame(width: 260)
                .onSubmit(submitURLImport)
                .onChange(of: urlString) { _, _ in urlImportError = nil }

            // Shown inline (not via `appState.statusMessage`, which the main window
            // renders as a single truncated line) because the YouTube-decline
            // message is long and is the whole point of this control - if it got
            // cut off the popover would just close on an unexplained no-op.
            if let urlImportError {
                Text(urlImportError)
                    .font(.caption2)
                    .foregroundStyle(.red)
                    .frame(width: 260, alignment: .leading)
            } else {
                Text("YouTube links aren't supported - YouTube's Terms of Service don't allow downloading its media outside the YouTube player. Use Record > Record System Audio to capture a video's audio as it plays instead.")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .frame(width: 260, alignment: .leading)
            }

            HStack {
                Spacer()
                Button("Cancel") { showURLImporter = false }
                Button("Import") { submitURLImport() }
                    .buttonStyle(.borderedProminent)
                    .disabled(urlString.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
        }
        .padding(16)
    }

    /// Validates locally and keeps the popover open with an inline explanation for
    /// anything we already know won't work (bad URL, blocked host) - only handed
    /// off to `appState.importAudio` (which closes this popover immediately and
    /// continues the download in the background) once those checks pass.
    private func submitURLImport() {
        let trimmed = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        guard let url = URL(string: trimmed), url.host != nil, url.scheme == "http" || url.scheme == "https" else {
            urlImportError = "That doesn't look like a valid URL."
            return
        }
        if URLAudioImporter.isBlockedHost(url) {
            urlImportError = "YouTube links can't be imported directly - YouTube's Terms of Service don't allow downloading its media outside the YouTube player. Close this, then use Record > Record System Audio to capture the video's audio as it plays instead."
            return
        }
        urlImportError = nil
        appState.importAudio(fromURLString: urlString)
        urlString = ""
        showURLImporter = false
    }
}

private struct MediaAssetRow: View {
    let asset: MediaAsset
    var onAdd: () -> Void
    @EnvironmentObject var appState: AppState

    var body: some View {
        HStack(spacing: 8) {
            thumbnail
                .frame(width: 56, height: 32)
                .background(Color.black.opacity(0.2))
                .cornerRadius(4)

            VStack(alignment: .leading, spacing: 2) {
                Text(asset.displayName)
                    .font(.system(size: 12, weight: .medium))
                    .lineLimit(1)
                Text(TimeFormatting.timecode(asset.duration.seconds))
                    .font(.system(size: 10))
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Image(systemName: iconName)
                .foregroundStyle(.secondary)

            Button(action: onAdd) {
                Image(systemName: "plus.circle.fill")
            }
            .buttonStyle(.plain)
            .foregroundStyle(.secondary)
            .help("Add to end of timeline")
        }
        .padding(.vertical, 3)
    }

    private var iconName: String {
        switch asset.kind {
        case .video: return "video"
        case .audio: return "waveform"
        case .image: return "photo"
        }
    }

    @ViewBuilder
    private var thumbnail: some View {
        if let fileName = asset.thumbnailFileName,
           let nsImage = NSImage(contentsOf: appState.thumbnailsDirectory.appendingPathComponent(fileName)) {
            Image(nsImage: nsImage)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .clipped()
        } else {
            Image(systemName: iconName)
                .foregroundStyle(.secondary)
        }
    }
}
