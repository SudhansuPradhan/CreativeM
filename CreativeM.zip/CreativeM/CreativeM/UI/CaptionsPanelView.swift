import AppKit
import SwiftUI

/// Captions live directly on `appState.project` (not inside a nested `ObservableObject`),
/// so - unlike `RecordingPanelView`/`ExportSheetView` - a plain `@EnvironmentObject` is
/// enough here for the view to update reactively.
struct CaptionsPanelView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss

    private var sortedSegments: [CaptionSegment] {
        appState.project.captionSegments.sorted { $0.start < $1.start }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            header

            if appState.isBusy {
                HStack(spacing: 8) {
                    ProgressView().controlSize(.small)
                    Text(appState.busyMessage).font(.caption).foregroundStyle(.secondary)
                }
            }

            if sortedSegments.isEmpty {
                emptyState
            } else {
                List {
                    ForEach(sortedSegments) { segment in
                        CaptionRow(segment: segment)
                    }
                }
                .listStyle(.inset)
            }

            Divider()
            footer
        }
        .padding(20)
        .frame(width: 520, height: 480)
    }

    private var header: some View {
        HStack {
            Text("Captions").font(.title2.bold())
            Spacer()
            Toggle("Burn into video", isOn: Binding(
                get: { appState.project.burnInCaptions },
                set: { appState.setBurnInCaptions($0) }
            ))
            .toggleStyle(.checkbox)
        }
    }

    private var emptyState: some View {
        VStack(spacing: 8) {
            Image(systemName: "captions.bubble")
                .font(.system(size: 28))
                .foregroundStyle(.secondary)
            Text("No captions yet")
                .foregroundStyle(.secondary)
            Text("Generate them automatically from the timeline's audio, entirely on-device.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var footer: some View {
        HStack {
            Button("Close") { dismiss() }
            Spacer()
            Button("Add Line") { appState.addCaptionSegment(atSeconds: appState.playheadSeconds) }
            Button("Export .srt...") { exportSRT() }
                .disabled(sortedSegments.isEmpty)
            Button {
                appState.generateCaptions()
            } label: {
                Label("Generate Captions", systemImage: "waveform.badge.mic")
            }
            .buttonStyle(.borderedProminent)
            .disabled(appState.isBusy || appState.project.duration.seconds <= 0)
        }
    }

    private func exportSRT() {
        let panel = NSSavePanel()
        panel.title = "Export Captions"
        panel.nameFieldStringValue = "\(appState.project.name).srt"
        panel.begin { response in
            guard response == .OK, let url = panel.url else { return }
            appState.exportSRT(to: url)
        }
    }
}

/// One editable caption line. Start/end are bound straight to the model (a `Stepper`
/// click is already a discrete, debounced edit) so they can never go stale relative to
/// external changes like undo. Free-text typing is mirrored into local `@State` first
/// (so we don't register an undo step per keystroke) and only committed on Enter/blur,
/// but is re-synced from the model via `onChange` so an undo while this panel is open
/// still shows the right text.
private struct CaptionRow: View {
    let segment: CaptionSegment
    @EnvironmentObject var appState: AppState
    @State private var text: String = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 8) {
                Text(TimeFormatting.timecode(segment.start.seconds))
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundStyle(.secondary)
                Stepper("", value: startBinding, in: 0...max(segment.end.seconds - 0.1, 0), step: 0.1)
                    .labelsHidden()
                    .help("Adjust start time")

                Text("\u{2192}")
                    .font(.caption2)
                    .foregroundStyle(.secondary)

                Text(TimeFormatting.timecode(segment.end.seconds))
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundStyle(.secondary)
                Stepper("", value: endBinding, in: (segment.start.seconds + 0.1)...100_000, step: 0.1)
                    .labelsHidden()
                    .help("Adjust end time")

                Spacer()
                Button {
                    appState.deleteCaptionSegment(segment.id)
                } label: {
                    Image(systemName: "trash")
                }
                .buttonStyle(.plain)
            }

            TextField("Caption text", text: $text, onCommit: commitText)
                .textFieldStyle(.roundedBorder)
        }
        .padding(.vertical, 4)
        .onAppear { text = segment.text }
        .onChange(of: segment.text) { _, newValue in text = newValue }
    }

    private var startBinding: Binding<Double> {
        Binding(
            get: { segment.start.seconds },
            set: { appState.updateCaptionSegment(segment.id, text: text, startSeconds: $0, endSeconds: segment.end.seconds) }
        )
    }

    private var endBinding: Binding<Double> {
        Binding(
            get: { segment.end.seconds },
            set: { appState.updateCaptionSegment(segment.id, text: text, startSeconds: segment.start.seconds, endSeconds: $0) }
        )
    }

    private func commitText() {
        appState.updateCaptionSegment(segment.id, text: text, startSeconds: segment.start.seconds, endSeconds: segment.end.seconds)
    }
}
