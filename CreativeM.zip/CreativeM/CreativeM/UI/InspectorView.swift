import SwiftUI

struct InspectorView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("Inspector")
                .font(.headline)
                .padding(.horizontal, 12)
                .padding(.top, 10)
                .padding(.bottom, 6)

            if let clip = appState.selectedClip {
                ScrollView {
                    VStack(alignment: .leading, spacing: 14) {
                        clipHeader(clip)
                        Divider()

                        switch clip.kind {
                        case .title:
                            titleSection(clip)
                        case .video where isImageClip(clip):
                            // Images are composited full-frame via a CALayer (see
                            // `TimelineEngine.buildAnimationTool`), which doesn't yet read
                            // `transform`/`speed` - showing those controls here would look
                            // like they work while doing nothing, so they're hidden instead.
                            imageLimitationNote
                        case .video:
                            transformSection(clip)
                            Divider()
                            speedSection(clip)
                            Divider()
                            audioSection(clip)
                            Divider()
                            audioEffectsSection(clip)
                            Divider()
                            videoEffectsSection(clip)
                        case .audio:
                            audioSection(clip)
                            Divider()
                            audioEffectsSection(clip)
                        }
                    }
                    .padding(12)
                }
            } else {
                VStack(spacing: 8) {
                    Image(systemName: "sidebar.right")
                        .font(.system(size: 28))
                        .foregroundStyle(.secondary)
                    Text("No clip selected")
                        .foregroundStyle(.secondary)
                    Text("Select a clip on the timeline to edit it.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding()
            }
        }
    }

    // MARK: Sections

    private func isImageClip(_ clip: Clip) -> Bool {
        appState.project.mediaAsset(clip.mediaAssetID)?.kind == .image
    }

    private var imageLimitationNote: some View {
        Text("Image clips play full-frame on the timeline. Transform, speed, audio, and Video FX controls don't apply to images yet.")
            .font(.caption)
            .foregroundStyle(.secondary)
    }

    private func clipHeader(_ clip: Clip) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            TextField("Name", text: Binding(
                get: { clip.displayName },
                set: { appState.renameClip(clip.id, name: $0) }
            ))
            .textFieldStyle(.roundedBorder)

            Text("\(TimeFormatting.timecode(clip.startTime.seconds)) \u{2192} \(TimeFormatting.timecode(clip.endTime.seconds))")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }

    private func transformSection(_ clip: Clip) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Transform").font(.subheadline.bold())

            labeledSlider("Scale", value: clip.transform.scale, range: 0.2...3.0) { newValue in
                var t = clip.transform
                t.scale = newValue
                appState.setClipTransform(clip.id, transform: t)
            }
            labeledSlider("Position X", value: clip.transform.offsetX, range: -1...1) { newValue in
                var t = clip.transform
                t.offsetX = newValue
                appState.setClipTransform(clip.id, transform: t)
            }
            labeledSlider("Position Y", value: clip.transform.offsetY, range: -1...1) { newValue in
                var t = clip.transform
                t.offsetY = newValue
                appState.setClipTransform(clip.id, transform: t)
            }
            labeledSlider("Rotation", value: clip.transform.rotationDegrees, range: -180...180) { newValue in
                var t = clip.transform
                t.rotationDegrees = newValue
                appState.setClipTransform(clip.id, transform: t)
            }
            if clip.transform != .identity {
                Button("Reset Transform") {
                    appState.setClipTransform(clip.id, transform: .identity)
                }
                .font(.caption)
            }
        }
    }

    private func speedSection(_ clip: Clip) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Speed").font(.subheadline.bold())
            labeledSlider("Speed (\u{00D7})", value: clip.speed, range: 0.25...4.0) { newValue in
                appState.setClipSpeed(clip.id, speed: newValue)
            }
        }
    }

    private func audioSection(_ clip: Clip) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Audio").font(.subheadline.bold())

            Toggle("Muted", isOn: Binding(
                get: { clip.isMuted },
                set: { appState.setClipMuted(clip.id, isMuted: $0) }
            ))

            labeledSlider("Volume", value: Double(clip.volume), range: 0...2) { newValue in
                appState.setClipVolume(clip.id, volume: Float(newValue))
            }
            labeledSlider("Fade In (s)", value: clip.fadeIn.seconds, range: 0...5) { newValue in
                appState.setClipFades(clip.id, fadeInSeconds: newValue, fadeOutSeconds: clip.fadeOut.seconds)
            }
            labeledSlider("Fade Out (s)", value: clip.fadeOut.seconds, range: 0...5) { newValue in
                appState.setClipFades(clip.id, fadeInSeconds: clip.fadeIn.seconds, fadeOutSeconds: newValue)
            }
        }
    }

    /// Premium "Audio FX" rack - EQ, compression, a rumble/gate heuristic, and reverb,
    /// rendered offline via `AudioEffectsProcessor` at export time. Deliberately named
    /// "Reduce Rumble" rather than "Noise Reduction": it's a highpass filter plus a
    /// downward expander/gate, not spectral denoising, and Apple ships no stock
    /// AudioUnit that does the latter - this UI shouldn't claim otherwise.
    private func audioEffectsSection(_ clip: Clip) -> some View {
        let effects = clip.effectiveAudioEffects
        func update(_ mutate: (inout AudioEffects) -> Void) {
            var e = effects
            mutate(&e)
            appState.setClipAudioEffects(clip.id, effects: e)
        }

        return VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Audio FX").font(.subheadline.bold())
                Spacer()
                Text("PRO").font(.caption2.bold()).foregroundStyle(.white)
                    .padding(.horizontal, 5).padding(.vertical, 1)
                    .background(Color.accentColor).cornerRadius(3)
                if !effects.isIdentity {
                    Button("Reset") { appState.setClipAudioEffects(clip.id, effects: .none) }
                        .font(.caption)
                }
            }

            Text("EQ").font(.caption).foregroundStyle(.secondary)
            labeledSlider("Low (120Hz)", value: effects.eqLowGainDB, range: -24...24) { newValue in
                update { $0.eqLowGainDB = newValue }
            }
            labeledSlider("Mid (1kHz)", value: effects.eqMidGainDB, range: -24...24) { newValue in
                update { $0.eqMidGainDB = newValue }
            }
            labeledSlider("High (8kHz)", value: effects.eqHighGainDB, range: -24...24) { newValue in
                update { $0.eqHighGainDB = newValue }
            }

            labeledSlider("Compression", value: effects.compressionAmount, range: 0...1) { newValue in
                update { $0.compressionAmount = newValue }
            }
            labeledSlider("Reduce Rumble", value: effects.reduceRumbleAmount, range: 0...1) { newValue in
                update { $0.reduceRumbleAmount = newValue }
            }

            Picker("Reverb", selection: Binding(
                get: { effects.reverbPreset },
                set: { newValue in update { $0.reverbPreset = newValue } }
            )) {
                ForEach(ReverbPresetOption.allCases) { preset in
                    Text(preset.displayName).tag(preset)
                }
            }
            labeledSlider("Reverb Amount", value: effects.reverbAmount, range: 0...1) { newValue in
                update { $0.reverbAmount = newValue }
            }

            Text("Renders on export. Live preview catches up shortly after you stop adjusting.")
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
    }

    /// Premium "Video FX" rack - color (brightness/contrast/saturation), vignette, and
    /// blur, applied via a CALayer CIFilter chain at export time only (see
    /// `TimelineEngine.applyVideoEffects`'s doc comment for why there's no live-preview
    /// path - unlike Audio FX, there's also no background render to "catch up": preview
    /// simply shows the unfiltered clip until you export).
    private func videoEffectsSection(_ clip: Clip) -> some View {
        let effects = clip.effectiveVideoEffects
        func update(_ mutate: (inout VideoEffects) -> Void) {
            var e = effects
            mutate(&e)
            appState.setClipVideoEffects(clip.id, effects: e)
        }

        return VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Video FX").font(.subheadline.bold())
                Spacer()
                Text("PRO").font(.caption2.bold()).foregroundStyle(.white)
                    .padding(.horizontal, 5).padding(.vertical, 1)
                    .background(Color.accentColor).cornerRadius(3)
                if !effects.isIdentity {
                    Button("Reset") { appState.setClipVideoEffects(clip.id, effects: .none) }
                        .font(.caption)
                }
            }

            Text("Look").font(.caption).foregroundStyle(.secondary)
            HStack(spacing: 6) {
                ForEach(VideoLookPreset.allCases) { preset in
                    Button(preset.displayName) { appState.setClipVideoEffects(clip.id, effects: preset.effects) }
                        .font(.caption)
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                }
            }

            Text("Color").font(.caption).foregroundStyle(.secondary)
            labeledSlider("Brightness", value: effects.brightness, range: -1...1) { newValue in
                update { $0.brightness = newValue }
            }
            labeledSlider("Contrast", value: effects.contrast, range: 0...2) { newValue in
                update { $0.contrast = newValue }
            }
            labeledSlider("Saturation", value: effects.saturation, range: 0...2) { newValue in
                update { $0.saturation = newValue }
            }

            labeledSlider("Vignette", value: effects.vignetteAmount, range: 0...1) { newValue in
                update { $0.vignetteAmount = newValue }
            }
            labeledSlider("Blur", value: effects.blurRadius, range: 0...20) { newValue in
                update { $0.blurRadius = newValue }
            }

            Text("Renders on export. Live preview always shows the unfiltered clip.")
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
    }

    private func titleSection(_ clip: Clip) -> some View {
        let style = clip.title ?? TitleStyle()
        return VStack(alignment: .leading, spacing: 10) {
            Text("Title").font(.subheadline.bold())

            TextEditor(text: Binding(
                get: { style.text },
                set: { newText in
                    var s = style
                    s.text = newText
                    appState.updateTitleStyle(clip.id, style: s)
                }
            ))
            .frame(height: 60)
            .font(.system(size: 13))
            .overlay(RoundedRectangle(cornerRadius: 4).stroke(Color.secondary.opacity(0.3)))

            Picker("Position", selection: Binding(
                get: { style.position },
                set: { newValue in
                    var s = style
                    s.position = newValue
                    appState.updateTitleStyle(clip.id, style: s)
                }
            )) {
                ForEach(TitlePosition.allCases) { pos in
                    Text(pos.rawValue.capitalized).tag(pos)
                }
            }
            .pickerStyle(.segmented)

            labeledSlider("Font Size", value: style.fontSize, range: 24...160) { newValue in
                var s = style
                s.fontSize = newValue
                appState.updateTitleStyle(clip.id, style: s)
            }

            HStack {
                Text("Color").font(.caption)
                Spacer()
                ColorPicker("", selection: Binding(
                    get: { Color(hex: style.colorHex) },
                    set: { newColor in
                        var s = style
                        s.colorHex = newColor.toHex()
                        appState.updateTitleStyle(clip.id, style: s)
                    }
                ))
                .labelsHidden()
            }

            labeledSlider("Background Opacity", value: style.backgroundOpacity, range: 0...1) { newValue in
                var s = style
                s.backgroundOpacity = newValue
                appState.updateTitleStyle(clip.id, style: s)
            }
        }
    }

    // MARK: Helpers

    private func labeledSlider(
        _ label: String,
        value: Double,
        range: ClosedRange<Double>,
        onChange: @escaping (Double) -> Void
    ) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack {
                Text(label).font(.caption)
                Spacer()
                Text(String(format: "%.2f", value)).font(.caption).foregroundStyle(.secondary)
            }
            Slider(value: Binding(get: { value }, set: onChange), in: range)
        }
    }
}
