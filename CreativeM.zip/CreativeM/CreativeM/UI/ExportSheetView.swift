import AVFoundation
import SwiftUI

/// `exportManager` is passed in explicitly (rather than reached via
/// `appState.exportManager`) and held as `@ObservedObject` here, for the same reason
/// documented on `RecordingPanelView`: a nested object's `@Published` changes
/// (`isExporting`, `progress`) don't propagate through `AppState`'s own
/// `ObservableObject` conformance, so this view needs to observe it directly.
struct ExportSheetView: View {
    @EnvironmentObject var appState: AppState
    @ObservedObject var exportManager: ExportManager
    @Environment(\.dismiss) private var dismiss

    @State private var selectedPresetID: String = ExportPreset.hd1080.id
    @State private var alsoExportSRT = true
    @State private var errorMessage: String?
    @State private var didSucceed = false

    init(exportManager: ExportManager) {
        self.exportManager = exportManager
    }

    private var selectedPreset: ExportPreset { ExportPreset.byID(selectedPresetID) }
    private var hasCaptions: Bool { !appState.project.captionSegments.isEmpty }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Export").font(.title2.bold())

            Picker("Preset", selection: $selectedPresetID) {
                ForEach(ExportPreset.all) { preset in
                    Text(preset.name).tag(preset.id)
                }
            }

            VStack(alignment: .leading, spacing: 4) {
                Text("Duration: \(TimeFormatting.timecode(appState.project.duration.seconds))")
                if let size = selectedPreset.renderSize {
                    Text("Output size: \(Int(size.width)) \u{00D7} \(Int(size.height))")
                }
            }
            .font(.caption)
            .foregroundStyle(.secondary)

            if hasCaptions {
                Toggle("Also save .srt captions alongside the export", isOn: $alsoExportSRT)
                    .font(.callout)
                if !appState.project.burnInCaptions {
                    Text("Tip: turn on \"Burn in captions\" in the Captions panel if you want subtitles visible inside the video itself.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            if exportManager.isExporting {
                VStack(alignment: .leading, spacing: 4) {
                    ProgressView(value: exportManager.progress)
                    Text("Exporting... \(Int(exportManager.progress * 100))%")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            if let errorMessage {
                Text(errorMessage).font(.caption).foregroundStyle(.red)
            }
            if didSucceed {
                Text("Export complete.").font(.caption).foregroundStyle(.green)
            }

            Divider()

            HStack {
                Button("Close") { dismiss() }
                Spacer()
                if exportManager.isExporting {
                    Button("Cancel", role: .destructive) { exportManager.cancel() }
                } else {
                    Button("Export...") { chooseDestinationAndExport() }
                        .buttonStyle(.borderedProminent)
                        .disabled(appState.project.duration.seconds <= 0)
                }
            }
        }
        .padding(20)
        .frame(width: 440)
        .onAppear { selectedPresetID = appState.project.exportPresetID }
        .onChange(of: selectedPresetID) { _, newValue in appState.setExportPresetID(newValue) }
    }

    private func chooseDestinationAndExport() {
        errorMessage = nil
        didSucceed = false
        let preset = selectedPreset

        let panel = NSSavePanel()
        panel.title = "Export Video"
        panel.nameFieldStringValue = "\(appState.project.name).\(preset.fileExtension)"
        panel.begin { response in
            guard response == .OK, let url = panel.url else { return }
            Task {
                do {
                    try await exportManager.export(project: appState.project, preset: preset, to: url)
                    didSucceed = true
                    if alsoExportSRT, hasCaptions {
                        let srtURL = url.deletingPathExtension().appendingPathExtension("srt")
                        appState.exportSRT(to: srtURL)
                    }
                } catch {
                    errorMessage = error.localizedDescription
                }
            }
        }
    }
}
