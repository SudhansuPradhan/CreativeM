import AppKit
import SwiftUI

extension Track {
    var timelineRowHeight: CGFloat { kind == .video ? 64 : 40 }
}

struct TimelineView: View {
    @EnvironmentObject var appState: AppState
    private let headerWidth: CGFloat = 160
    private let rulerHeight: CGFloat = 26

    var body: some View {
        VStack(spacing: 0) {
            timelineToolbar
            Divider()
            ScrollView(.vertical, showsIndicators: true) {
                HStack(alignment: .top, spacing: 0) {
                    headerColumn
                    scrollableContent
                }
            }
        }
    }

    // MARK: Toolbar

    private var timelineToolbar: some View {
        HStack(spacing: 10) {
            Button { appState.splitAtPlayhead() } label: { Image(systemName: "scissors") }
                .help("Split at Playhead (S)")

            Button { appState.deleteSelectedClip() } label: { Image(systemName: "trash") }
                .help("Delete Selected Clip")
                .disabled(appState.selectedClipID == nil)

            Divider().frame(height: 16)

            if let selected = appState.selectedClip, selected.kind == .video {
                Menu {
                    ForEach(TransitionType.allCases) { transition in
                        Button(transition.displayName) {
                            appState.setTransitionIn(selected.id, transition: transition)
                        }
                    }
                } label: {
                    Label("Transition", systemImage: "rectangle.on.rectangle")
                }
                .frame(width: 140)
            }

            Spacer()

            Text("\(Int(appState.pixelsPerSecond))px/s")
                .font(.caption2)
                .foregroundStyle(.secondary)
            Button { appState.zoomOut() } label: { Image(systemName: "minus.magnifyingglass") }
            Button { appState.zoomIn() } label: { Image(systemName: "plus.magnifyingglass") }
        }
        .buttonStyle(.borderless)
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
    }

    // MARK: Header column (fixed, scrolls only vertically)

    private var headerColumn: some View {
        VStack(spacing: 1) {
            Color.clear.frame(height: rulerHeight)
            ForEach(appState.project.tracks) { track in
                TrackHeaderView(track: track)
                    .frame(height: track.timelineRowHeight)
            }
        }
        .frame(width: headerWidth)
    }

    // MARK: Scrollable ruler + lanes

    private var scrollableContent: some View {
        ScrollView(.horizontal, showsIndicators: true) {
            ZStack(alignment: .topLeading) {
                VStack(spacing: 1) {
                    RulerView(durationSeconds: max(appState.project.duration.seconds, 30), pixelsPerSecond: appState.pixelsPerSecond)
                        .frame(height: rulerHeight)
                        .contentShape(Rectangle())
                        .gesture(scrubGesture)

                    ForEach(appState.project.tracks) { track in
                        TrackLaneView(track: track)
                            .frame(height: track.timelineRowHeight)
                    }
                }

                PlayheadLine()
                    .frame(height: contentHeight)
                    .offset(x: CGFloat(appState.playheadSeconds) * appState.pixelsPerSecond)
                    .allowsHitTesting(false)
            }
            .frame(width: contentWidth, alignment: .topLeading)
        }
    }

    private var contentWidth: CGFloat {
        max(CGFloat(appState.project.duration.seconds + 30) * appState.pixelsPerSecond, 800)
    }

    private var contentHeight: CGFloat {
        rulerHeight + appState.project.tracks.reduce(0) { $0 + $1.timelineRowHeight + 1 }
    }

    private var scrubGesture: some Gesture {
        DragGesture(minimumDistance: 0, coordinateSpace: .local)
            .onChanged { value in
                appState.seek(toSeconds: max(0, value.location.x / appState.pixelsPerSecond))
            }
    }
}

// MARK: - Ruler

private struct RulerView: View {
    let durationSeconds: Double
    let pixelsPerSecond: Double

    private var interval: Double {
        if pixelsPerSecond > 150 { return 1 }
        if pixelsPerSecond > 60 { return 5 }
        if pixelsPerSecond > 20 { return 10 }
        return 30
    }

    private var tickCount: Int {
        max(Int((durationSeconds / interval).rounded(.up)) + 5, 5)
    }

    var body: some View {
        ZStack(alignment: .topLeading) {
            ForEach(0..<tickCount, id: \.self) { i in
                let t = Double(i) * interval
                VStack(alignment: .leading, spacing: 1) {
                    Text(TimeFormatting.timecode(t))
                        .font(.system(size: 9))
                        .foregroundStyle(.secondary)
                        .fixedSize()
                    Rectangle()
                        .fill(Color.secondary.opacity(0.5))
                        .frame(width: 1, height: 6)
                }
                .offset(x: CGFloat(t) * pixelsPerSecond)
            }
        }
        .frame(width: CGFloat(Double(tickCount) * interval) * pixelsPerSecond + 100, alignment: .topLeading)
    }
}

// MARK: - Playhead

private struct PlayheadLine: View {
    var body: some View {
        Rectangle()
            .fill(Color.red)
            .frame(width: 1.5)
    }
}

// MARK: - Track header (name, visibility, ducking)

private struct TrackHeaderView: View {
    let track: Track
    @EnvironmentObject var appState: AppState

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 4) {
                Image(systemName: iconName).font(.caption2)
                Text(track.name)
                    .font(.system(size: 11, weight: .semibold))
                    .lineLimit(1)
                Spacer()
                Button {
                    appState.setTrackEnabled(track.id, isEnabled: !track.isEnabled)
                } label: {
                    Image(systemName: track.isEnabled ? "eye" : "eye.slash")
                        .font(.caption2)
                }
                .buttonStyle(.plain)
            }

            if track.kind == .audio {
                HStack(spacing: 8) {
                    Toggle(isOn: Binding(
                        get: { track.isDuckingTarget },
                        set: { _ in appState.toggleDuckingTarget(track.id) }
                    )) {
                        Text("Duck").font(.system(size: 9))
                    }
                    .toggleStyle(.checkbox)

                    Toggle(isOn: Binding(
                        get: { track.isDuckingTrigger },
                        set: { _ in appState.toggleDuckingTrigger(track.id) }
                    )) {
                        Text("Voice").font(.system(size: 9))
                    }
                    .toggleStyle(.checkbox)
                }
            }
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 6)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var iconName: String {
        switch track.kind {
        case .video: return "video.fill"
        case .audio: return "waveform"
        case .title: return "textformat"
        }
    }
}

// MARK: - Track lane (clip container)

private struct TrackLaneView: View {
    let track: Track
    @EnvironmentObject var appState: AppState

    var body: some View {
        ZStack(alignment: .topLeading) {
            Rectangle().fill(Color.black.opacity(0.12))
            ForEach(appState.project.clips(on: track.id)) { clip in
                ClipBoxView(clip: clip)
                    .frame(height: track.timelineRowHeight - 6)
                    .offset(x: CGFloat(clip.startTime.seconds) * appState.pixelsPerSecond, y: 3)
            }
        }
    }
}

// MARK: - Clip box (select / move / trim)

private struct ClipBoxView: View {
    let clip: Clip
    @EnvironmentObject var appState: AppState
    @State private var dragTranslation: CGFloat = 0
    @State private var leadingTrimTranslation: CGFloat = 0
    @State private var trailingTrimTranslation: CGFloat = 0

    private var baseWidth: CGFloat {
        max(CGFloat(clip.timelineDuration.seconds) * appState.pixelsPerSecond, 6)
    }
    private var isSelected: Bool { appState.selectedClipID == clip.id }

    var body: some View {
        ZStack(alignment: .leading) {
            RoundedRectangle(cornerRadius: 4).fill(fillColor)
            RoundedRectangle(cornerRadius: 4)
                .strokeBorder(isSelected ? Color.accentColor : Color.clear, lineWidth: 2)

            Text(clip.displayName)
                .font(.system(size: 10, weight: .medium))
                .foregroundStyle(.white)
                .lineLimit(1)
                .padding(.leading, 6)
                .frame(maxWidth: .infinity, alignment: .leading)

            HStack(spacing: 0) {
                trimHandle(isLeading: true)
                Spacer(minLength: 0)
                trimHandle(isLeading: false)
            }
        }
        .frame(width: max(baseWidth + trailingTrimTranslation - leadingTrimTranslation, 6))
        .offset(x: dragTranslation + leadingTrimTranslation)
        .contentShape(Rectangle())
        .onTapGesture { appState.selectedClipID = clip.id }
        // `.simultaneousGesture` (not `.gesture`) so this drag recognizer doesn't claim
        // the touch/click exclusively and starve `.onTapGesture` above - with two
        // `.gesture`-style recognizers on one view, SwiftUI picks one winner per
        // interaction, which made plain clicks intermittently fail to select a clip.
        .simultaneousGesture(moveGesture)
    }

    private var fillColor: Color {
        switch clip.kind {
        case .video: return .blue.opacity(0.75)
        case .audio: return .green.opacity(0.75)
        case .title: return .purple.opacity(0.75)
        }
    }

    private var moveGesture: some Gesture {
        DragGesture(minimumDistance: 3, coordinateSpace: .local)
            .onChanged { value in
                appState.selectedClipID = clip.id
                dragTranslation = value.translation.width
            }
            .onEnded { value in
                let deltaSeconds = value.translation.width / appState.pixelsPerSecond
                dragTranslation = 0
                appState.moveClip(clip.id, toStartSeconds: max(0, clip.startTime.seconds + deltaSeconds))
            }
    }

    private func trimHandle(isLeading: Bool) -> some View {
        Rectangle()
            .fill(Color.white.opacity(0.0001))
            .frame(width: 8)
            .gesture(
                DragGesture(minimumDistance: 1, coordinateSpace: .local)
                    .onChanged { value in
                        if isLeading {
                            leadingTrimTranslation = value.translation.width
                        } else {
                            trailingTrimTranslation = value.translation.width
                        }
                    }
                    .onEnded { value in
                        let deltaSeconds = value.translation.width / appState.pixelsPerSecond
                        if isLeading {
                            leadingTrimTranslation = 0
                            appState.trimClipStart(clip.id, toSeconds: clip.startTime.seconds + deltaSeconds)
                        } else {
                            trailingTrimTranslation = 0
                            appState.trimClipEnd(clip.id, toSeconds: clip.endTime.seconds + deltaSeconds)
                        }
                    }
            )
    }
}
