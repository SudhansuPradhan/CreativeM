import AppKit
import Foundation

/// Save/open/autosave for the `.cmproj` project format: a plain folder (not a
/// registered Finder package/UTI, to avoid an Info.plist misconfiguration risk)
/// containing `project.json` plus cached `Thumbnails/` and `Waveforms/`. Source
/// media itself is referenced by absolute path, not copied, since the app is
/// unsandboxed.
extension AppState {
    static let projectFileName = "project.json"

    func newProject() {
        project = Project(name: "Untitled Project")
        currentProjectURL = nil
        isDirty = false
        selectedClipID = nil
        undoManager.removeAllActions()
        rebuildPreview()
    }

    func saveProject() {
        if let url = currentProjectURL {
            save(to: url)
        } else {
            presentSavePanel()
        }
    }

    func saveProjectAs() {
        presentSavePanel()
    }

    private func presentSavePanel() {
        let panel = NSSavePanel()
        panel.title = "Save CreativeM Project"
        panel.nameFieldStringValue = project.name.isEmpty ? "Untitled Project" : project.name
        panel.canCreateDirectories = true
        panel.begin { [weak self] response in
            guard let self, response == .OK, let url = panel.url else { return }
            let folderURL = url.pathExtension == "cmproj" ? url : url.appendingPathExtension("cmproj")
            self.save(to: folderURL)
        }
    }

    private func save(to folderURL: URL) {
        do {
            try FileManager.default.createDirectory(at: folderURL, withIntermediateDirectories: true)
            migrateCachesIfNeeded(to: folderURL)

            var projectToSave = project
            projectToSave.name = folderURL.deletingPathExtension().lastPathComponent
            let data = try JSONEncoder.creativeM.encode(projectToSave)
            try data.write(to: folderURL.appendingPathComponent(Self.projectFileName), options: .atomic)

            project.name = projectToSave.name
            currentProjectURL = folderURL
            isDirty = false
            statusMessage = "Saved \(folderURL.lastPathComponent)."
            NSDocumentController.shared.noteNewRecentDocumentURL(folderURL)
        } catch {
            statusMessage = "Couldn't save project: \(error.localizedDescription)"
        }
    }

    /// If this was a not-yet-saved project, its thumbnail/waveform caches were written
    /// to the scratch autosave location - copy them alongside the project now that it
    /// has a real home, so they aren't silently orphaned.
    private func migrateCachesIfNeeded(to folderURL: URL) {
        guard currentProjectURL == nil else { return }
        let fm = FileManager.default
        for sub in ["Thumbnails", "Waveforms"] {
            let source = AppPaths.autosaveDirectory.appendingPathComponent(sub, isDirectory: true)
            let destination = folderURL.appendingPathComponent(sub, isDirectory: true)
            guard fm.fileExists(atPath: source.path) else { continue }
            try? fm.createDirectory(at: destination, withIntermediateDirectories: true)
            if let items = try? fm.contentsOfDirectory(at: source, includingPropertiesForKeys: nil) {
                for item in items {
                    let dest = destination.appendingPathComponent(item.lastPathComponent)
                    if !fm.fileExists(atPath: dest.path) {
                        try? fm.copyItem(at: item, to: dest)
                    }
                }
            }
        }
    }

    func openProjectPanel() {
        let panel = NSOpenPanel()
        panel.title = "Open CreativeM Project"
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.allowsMultipleSelection = false
        panel.begin { [weak self] response in
            guard let self, response == .OK, let url = panel.url else { return }
            self.open(from: url)
        }
    }

    func open(from folderURL: URL) {
        let fileURL = folderURL.appendingPathComponent(Self.projectFileName)
        do {
            let data = try Data(contentsOf: fileURL)
            let loaded = try JSONDecoder.creativeM.decode(Project.self, from: data)
            project = loaded
            currentProjectURL = folderURL
            isDirty = false
            selectedClipID = nil
            undoManager.removeAllActions()
            rebuildPreview()
            NSDocumentController.shared.noteNewRecentDocumentURL(folderURL)
        } catch {
            statusMessage = "Couldn't open \(folderURL.lastPathComponent): \(error.localizedDescription)"
        }
    }
}

extension JSONEncoder {
    static let creativeM: JSONEncoder = {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        return encoder
    }()
}

extension JSONDecoder {
    static let creativeM: JSONDecoder = {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }()
}

// MARK: - Autosave

/// Periodically writes a background snapshot of the current project to a scratch
/// location (not the user's chosen save location) so a crash doesn't lose work.
/// This is best-effort: failures are silent rather than interrupting the user.
final class AutosaveManager {
    private weak var appState: AppState?
    private var timer: Timer?

    init(appState: AppState) {
        self.appState = appState
    }

    func start(intervalSeconds: TimeInterval = 60) {
        stop()
        timer = Timer.scheduledTimer(withTimeInterval: intervalSeconds, repeats: true) { [weak self] _ in
            Task { @MainActor in
                self?.autosaveIfNeeded()
            }
        }
    }

    func stop() {
        timer?.invalidate()
        timer = nil
    }

    @MainActor
    private func autosaveIfNeeded() {
        guard let appState, appState.isDirty else { return }
        let folder = AppPaths.autosaveDirectory
            .appendingPathComponent("\(appState.project.id.uuidString).cmproj-autosave", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let data = try JSONEncoder.creativeM.encode(appState.project)
            try data.write(to: folder.appendingPathComponent(AppState.projectFileName), options: .atomic)
        } catch {
            // Best-effort; nothing actionable to show the user for a background autosave failure.
        }
    }
}
