import SwiftUI

@main
struct CreativeMApp: App {
    @StateObject private var appState = AppState()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(appState)
                .frame(minWidth: 1100, minHeight: 700)
        }
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("New Project") { appState.newProject() }
                    .keyboardShortcut("n", modifiers: .command)
                Button("Open Project...") { appState.openProjectPanel() }
                    .keyboardShortcut("o", modifiers: .command)
            }
            CommandGroup(after: .saveItem) {
                Button("Save Project") { appState.saveProject() }
                    .keyboardShortcut("s", modifiers: .command)
                Button("Save Project As...") { appState.saveProjectAs() }
                    .keyboardShortcut("s", modifiers: [.command, .shift])
                Divider()
                Button("Export...") { appState.showExportSheet = true }
                    .keyboardShortcut("e", modifiers: .command)
            }
            CommandGroup(replacing: .undoRedo) {
                Button("Undo") { appState.undo() }
                    .keyboardShortcut("z", modifiers: .command)
                    .disabled(!appState.canUndo)
                Button("Redo") { appState.redo() }
                    .keyboardShortcut("z", modifiers: [.command, .shift])
                    .disabled(!appState.canRedo)
            }
            CommandMenu("Clip") {
                Button("Split at Playhead") { appState.splitAtPlayhead() }
                    .keyboardShortcut("k", modifiers: .command)
                Button("Delete Clip") { appState.deleteSelectedClip() }
                    .keyboardShortcut(.deleteForward, modifiers: .command)
                Divider()
                Button("Add Title") { appState.addTitleClip(atSeconds: appState.playheadSeconds) }
                    .keyboardShortcut("t", modifiers: .command)
                Divider()
                Button("Generate Captions") { appState.generateCaptions() }
                    .keyboardShortcut("g", modifiers: [.command, .shift])
            }
            CommandMenu("Record") {
                Button("Record Camera + Mic...") {
                    appState.recordingPanelMode = .camera
                    appState.showRecordingPanel = true
                }
                .keyboardShortcut("r", modifiers: .command)
                Button("Record Screen...") {
                    appState.recordingPanelMode = .screen
                    appState.showRecordingPanel = true
                }
                .keyboardShortcut("r", modifiers: [.command, .shift])
                Button("Record System Audio...") {
                    appState.recordingPanelMode = .systemAudio
                    appState.showRecordingPanel = true
                }
                .keyboardShortcut("r", modifiers: [.command, .option])
                Button("Record Microphone...") {
                    appState.recordingPanelMode = .microphone
                    appState.showRecordingPanel = true
                }
                .keyboardShortcut("r", modifiers: [.command, .control])
            }
        }
    }
}
