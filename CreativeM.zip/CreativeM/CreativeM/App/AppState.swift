import AVFoundation
import Combine
import Foundation

/// Single source of truth for the open project plus all transient UI/editing state
/// (selection, playhead, zoom) and the app's long-lived service objects (recorders,
/// exporter, speech transcriber, undo manager, preview player).
///
/// Editing operations live in `extension AppState` blocks in `TimelineViewModel.swift`
/// (clip editing) and `ProjectDocument.swift` (save/open/autosave) to keep this file
/// focused on state + app-level orchestration (recording, importing, captions).
@MainActor
final class AppState: ObservableObject {
    @Published var project: Project
    @Published var currentProjectURL: URL?
    @Published var isDirty: Bool = false

    // Timeline / selection UI state
    @Published var selectedClipID: UUID?
    @Published var playheadSeconds: Double = 0
    @Published var pixelsPerSecond: Double = 60
    @Published var isPlaying: Bool = false
    @Published var isScrubbing: Bool = false

    // Transient UI feedback
    @Published var statusMessage: String?
    @Published var isBusy: Bool = false
    @Published var busyMessage: String = ""

    // Sheet/panel presentation (shared so both the toolbar and menu commands can toggle them)
    @Published var showRecordingPanel: Bool = false
    @Published var recordingPanelMode: RecordingMode = .camera
    /// Voice preset applied (non-destructively) to the clip a mic recording produces -
    /// see `startMicRecording`. Chosen before hitting Start; `.clean` records dry.
    @Published var micVoicePreset: MicVoicePreset = .clean
    @Published var showExportSheet: Bool = false
    @Published var showCaptionsPanel: Bool = false

    let undoManager = UndoManager()
    let player = AVPlayer()
    let cameraMicRecorder = CameraMicRecorder()
    let screenRecorder = ScreenRecorder()
    let systemAudioRecorder = SystemAudioRecorder()
    let micRecorder = MicRecorder()
    let exportManager = ExportManager()
    let speechTranscriber: SpeechTranscribing = OnDeviceSpeechTranscriber()

    private var timeObserver: Any?
    private var autosaveManager: AutosaveManager?
    /// One pending best-effort background render per clip, debounced so a slider being
    /// dragged doesn't kick off a render per tick - see `scheduleAudioEffectsPrewarm`.
    private var audioEffectsPrewarmTasks: [UUID: Task<Void, Never>] = [:]

    init(project: Project = Project(name: "Untitled Project")) {
        self.project = project
        let interval = CMTime(value: 1, timescale: 30)
        timeObserver = player.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            guard let self, !self.isScrubbing else { return }
            self.playheadSeconds = time.seconds
        }
        let autosave = AutosaveManager(appState: self)
        autosave.start()
        autosaveManager = autosave
    }

    deinit {
        if let timeObserver {
            player.removeTimeObserver(timeObserver)
        }
    }

    var selectedClip: Clip? {
        guard let id = selectedClipID else { return nil }
        return project.clips.first { $0.id == id }
    }

    var canUndo: Bool { undoManager.canUndo }
    var canRedo: Bool { undoManager.canRedo }
    // `setProject` (see TimelineViewModel.swift) already rebuilds the preview whenever
    // the undo/redo closures it registers run, so these just forward to `UndoManager`.
    func undo() { undoManager.undo() }
    func redo() { undoManager.redo() }

    func markDirty() {
        isDirty = true
        project.touch()
    }

    /// Persists the last-used export preset choice. Deliberately not routed through
    /// `performEdit`/undo - like `pixelsPerSecond`, this is a preference, not a creative
    /// timeline edit worth cluttering the undo stack with.
    func setExportPresetID(_ id: String) {
        guard project.exportPresetID != id else { return }
        project.exportPresetID = id
        markDirty()
    }

    // MARK: Preview

    /// Recompiles the `AVMutableComposition` from the current project state and swaps
    /// it into the shared player. Called after any structural edit; deliberately not
    /// called on every intermediate drag frame (see `TimelineViewModel`).
    func rebuildPreview() {
        Task {
            do {
                let result = try await TimelineEngine.build(project: project, forPreview: true)
                let item = AVPlayerItem(asset: result.composition)
                item.videoComposition = result.videoComposition
                item.audioMix = result.audioMix

                let wasPlaying = isPlaying
                let resumeSeconds = playheadSeconds
                player.pause()
                player.replaceCurrentItem(with: item)
                let resumeTime = CMTime(seconds: resumeSeconds, preferredTimescale: 600)
                await player.seek(to: resumeTime, toleranceBefore: .zero, toleranceAfter: .zero)
                if wasPlaying {
                    player.play()
                }
            } catch {
                statusMessage = "Preview error: \(error.localizedDescription)"
            }
        }
    }

    /// Best-effort, debounced: waits for edits to settle, then renders the clip's
    /// current Audio FX settings in the background and rebuilds the preview so it picks
    /// up the result from cache. `TimelineEngine.build` never renders inline (see
    /// `AudioEffectsProcessor`'s doc comment), so without this, preview would only ever
    /// hear processed audio after the next *unrelated* edit happened to rebuild it.
    func scheduleAudioEffectsPrewarm(_ clipID: UUID) {
        audioEffectsPrewarmTasks[clipID]?.cancel()
        audioEffectsPrewarmTasks[clipID] = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 600_000_000)
            guard let self, !Task.isCancelled else { return }
            guard let clip = self.project.clips.first(where: { $0.id == clipID }),
                  let mediaAsset = self.project.mediaAsset(clip.mediaAssetID) else { return }
            let effects = clip.effectiveAudioEffects

            // Runs on EVERY settled edit, including resetting effects back to identity -
            // not just after a successful render. Otherwise resetting a clip's (only)
            // effects orphans its old cache file with nothing left to ever trigger its
            // cleanup (this clip no longer renders, so it never reaches a GC call) until
            // some UNRELATED clip happens to render and sweep it. See
            // `AudioEffectsProcessor.garbageCollect(liveKeys:)`'s doc comment.
            //
            // Skipped while an export is running: export's own prewarm already runs its
            // own (project-snapshot-consistent) GC pass once, after its render loop
            // finishes - see `ExportManager.prewarmAudioEffectsCache`. Without this guard,
            // an edit made while an export is mid-flight could sweep away a cache file
            // `AVAssetExportSession` is still actively reading (this uses the live,
            // possibly-newer project state, not the frozen snapshot the export is working
            // from).
            defer {
                if !self.exportManager.isExporting {
                    AudioEffectsProcessor.garbageCollect(liveKeys: AudioEffectsProcessor.liveKeys(for: self.project))
                }
            }

            guard !effects.isIdentity else { return }
            do {
                try await AudioEffectsProcessor.process(sourceURL: mediaAsset.url, mediaAssetID: mediaAsset.id, effects: effects)
                guard !Task.isCancelled else { return }
                self.rebuildPreview()
            } catch {
                // Preview just stays on unprocessed audio until a later attempt
                // succeeds; export renders synchronously and surfaces real errors there.
            }
        }
    }

    func togglePlayback() {
        if isPlaying {
            player.pause()
        } else {
            if project.duration.seconds > 0, playheadSeconds >= project.duration.seconds - 0.05 {
                seek(toSeconds: 0)
            }
            player.play()
        }
        isPlaying.toggle()
    }

    func seek(toSeconds seconds: Double) {
        playheadSeconds = max(0, seconds)
        let time = CMTime(seconds: playheadSeconds, preferredTimescale: 600)
        // `seek(toSeconds:)` is called synchronously from drag/slider UI code, so this
        // stays non-async and fires the (now async-only, in this SDK) player seek off
        // as fire-and-forget rather than propagating `async` up through every caller.
        let player = self.player
        Task { @MainActor in
            await player.seek(to: time, toleranceBefore: .zero, toleranceAfter: .zero)
        }
    }

    // MARK: Media import

    var thumbnailsDirectory: URL {
        (currentProjectURL ?? AppPaths.autosaveDirectory).appendingPathComponent("Thumbnails", isDirectory: true)
    }

    var waveformsDirectory: URL {
        (currentProjectURL ?? AppPaths.autosaveDirectory).appendingPathComponent("Waveforms", isDirectory: true)
    }

    /// `audioEffects`, when non-nil, is baked into the new clip's creation (see
    /// `appendClipToEnd`'s `initialAudioEffects`) and its render is kicked off right
    /// away - used by `startMicRecording` to apply a chosen `MicVoicePreset` to a
    /// freshly-recorded clip. Ignored when `addToTimelineTrackKind` is nil (nothing
    /// gets added to the timeline to attach effects to).
    func importMedia(urls: [URL], addToTimelineTrackKind: TrackKind? = nil, audioEffects: AudioEffects? = nil) async {
        isBusy = true
        busyMessage = urls.count > 1 ? "Importing \(urls.count) files..." : "Importing media..."
        defer { isBusy = false }

        for url in urls {
            do {
                var asset = try await MediaImporter.importAsset(from: url)

                if let thumbName = try? MediaImporter.generateThumbnail(for: asset, into: thumbnailsDirectory) {
                    asset.thumbnailFileName = thumbName
                }
                if asset.kind != .image,
                   let peaks = try? await WaveformGenerator.generatePeaks(for: asset.url),
                   !peaks.isEmpty,
                   let waveName = try? WaveformGenerator.savePeaks(peaks, assetID: asset.id, into: waveformsDirectory) {
                    asset.waveformFileName = waveName
                }

                project.mediaAssets.append(asset)

                if let trackKind = addToTimelineTrackKind, let track = project.tracks.first(where: { $0.kind == trackKind }) {
                    let clipID = appendClipToEnd(of: track.id, mediaAsset: asset, initialAudioEffects: audioEffects)
                    if audioEffects != nil {
                        scheduleAudioEffectsPrewarm(clipID)
                    }
                }
            } catch {
                statusMessage = "Couldn't import \(url.lastPathComponent): \(error.localizedDescription)"
            }
        }

        markDirty()
        rebuildPreview()
    }

    /// Generates (if needed) and imports the procedurally-synthesized "Sample Library"
    /// clips (see `SampleAudioLibrary`) via the normal `importMedia` pipeline, so they
    /// get the same thumbnail/waveform treatment as any other imported media. These are
    /// synthesized placeholder tones/beds, not licensed stock music.
    func addSampleAudioToLibrary() {
        Task {
            isBusy = true
            busyMessage = "Preparing sample audio..."
            do {
                let urls = try await SampleAudioLibrary.ensureGenerated()
                let existingFileNames = Set(project.mediaAssets.map { $0.url.lastPathComponent })
                let newURLs = urls.filter { !existingFileNames.contains($0.lastPathComponent) }
                if newURLs.isEmpty {
                    statusMessage = "Sample audio is already in your Media Pool."
                } else {
                    await importMedia(urls: newURLs)
                    statusMessage = "Added \(newURLs.count) sample audio clip\(newURLs.count == 1 ? "" : "s")."
                }
            } catch {
                statusMessage = "Couldn't prepare sample audio: \(error.localizedDescription)"
            }
            isBusy = false
        }
    }

    // MARK: Recording orchestration

    func startCameraRecording() {
        Task {
            let granted = await cameraMicRecorder.requestPermissions()
            guard granted else {
                statusMessage = "Camera/Microphone access was denied. Enable it in System Settings > Privacy & Security."
                return
            }
            cameraMicRecorder.startSession()
            let url = AppPaths.newRecordingURL(prefix: "Camera Recording")
            cameraMicRecorder.startRecording(to: url) { [weak self] result in
                Task { @MainActor in
                    guard let self else { return }
                    switch result {
                    case .success(let fileURL):
                        await self.importMedia(urls: [fileURL], addToTimelineTrackKind: .video)
                    case .failure(let error):
                        self.statusMessage = "Recording failed: \(error.localizedDescription)"
                    }
                }
            }
        }
    }

    func stopCameraRecording() {
        cameraMicRecorder.stopRecording()
        cameraMicRecorder.stopSession()
    }

    func startScreenRecording() {
        Task {
            let url = AppPaths.newRecordingURL(prefix: "Screen Recording")
            do {
                try await screenRecorder.start(outputURL: url)
            } catch {
                statusMessage = "Couldn't start screen recording: \(error.localizedDescription)"
            }
        }
    }

    func stopScreenRecording() {
        Task {
            do {
                let url = try await screenRecorder.stop()
                await importMedia(urls: [url], addToTimelineTrackKind: .video)
            } catch {
                statusMessage = "Couldn't finish screen recording: \(error.localizedDescription)"
            }
        }
    }

    /// Records the Mac's system audio output (whatever's currently playing - a
    /// YouTube tab, Music, Zoom, etc.) to an audio-only clip. This is the
    /// ToS-safe way to "get the audio out of a YouTube video": it captures the
    /// decoded output after playback, the same way a hardware line-in or an app
    /// like Audio Hijack/Loopback would, rather than extracting YouTube's stream
    /// URLs directly (see `URLAudioImporter` for why we don't do the latter).
    func startSystemAudioRecording() {
        Task {
            let url = AppPaths.newRecordingURL(prefix: "System Audio", ext: "m4a")
            do {
                try await systemAudioRecorder.start(outputURL: url)
            } catch {
                statusMessage = "Couldn't start system audio recording: \(error.localizedDescription)"
            }
        }
    }

    func stopSystemAudioRecording() {
        Task {
            do {
                let url = try await systemAudioRecorder.stop()
                await importMedia(urls: [url], addToTimelineTrackKind: .audio)
            } catch {
                statusMessage = "Couldn't finish system audio recording: \(error.localizedDescription)"
            }
        }
    }

    /// Records dry microphone audio, then applies `micVoicePreset` to the resulting
    /// clip non-destructively (same Audio FX pipeline as the Inspector's sliders) -
    /// no live/real-time effect monitoring while recording, consistent with every
    /// other effect in the app being export/preview-rebuild-time only.
    func startMicRecording() {
        Task {
            let granted = await micRecorder.requestPermissions()
            guard granted else {
                statusMessage = "Microphone access was denied. Enable it in System Settings > Privacy & Security."
                return
            }
            micRecorder.startSession()
            let url = AppPaths.newRecordingURL(prefix: "Mic Recording", ext: "m4a")
            micRecorder.startRecording(to: url) { [weak self] result in
                Task { @MainActor in
                    guard let self else { return }
                    switch result {
                    case .success(let fileURL):
                        let preset = self.micVoicePreset.effects
                        await self.importMedia(
                            urls: [fileURL],
                            addToTimelineTrackKind: .audio,
                            audioEffects: preset.isIdentity ? nil : preset
                        )
                    case .failure(let error):
                        self.statusMessage = "Recording failed: \(error.localizedDescription)"
                    }
                }
            }
        }
    }

    func stopMicRecording() {
        // Session teardown happens inside `MicRecorder`'s own recording-finished
        // delegate callback, not here - calling `stopSession()` eagerly would race the
        // tail end of the file still being flushed to disk. See that delegate's doc
        // comment.
        micRecorder.stopRecording()
    }

    /// Downloads a direct link to an audio/video file and imports it like any
    /// other media. Deliberately does NOT attempt to pull audio from a YouTube
    /// (or similar streaming-site) page URL - see `URLAudioImporter` for the
    /// policy reasoning. `startSystemAudioRecording` is the suggested alternative
    /// for "I want the audio from this YouTube video."
    func importAudio(fromURLString string: String) {
        let trimmed = string.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: trimmed), url.host != nil, url.scheme == "http" || url.scheme == "https" else {
            statusMessage = "That doesn't look like a valid URL."
            return
        }
        if URLAudioImporter.isBlockedHost(url) {
            statusMessage = "YouTube links can't be imported directly - YouTube's Terms of Service don't allow downloading media outside its own player, so CreativeM Studio won't do it. Instead: play the video and use Record > Record System Audio to capture what's playing, or paste a direct link to an audio file you already have rights to use."
            return
        }
        Task {
            isBusy = true
            busyMessage = "Downloading audio..."
            do {
                let fileURL = try await URLAudioImporter.download(from: url)
                // Lands in the Media Pool only (no track kind) - the download can
                // turn out to be audio *or* video (see `resolvedExtension`), so we
                // can't safely guess which timeline track to drop it on the way
                // `importMedia` does when the kind is already known.
                await importMedia(urls: [fileURL])
            } catch {
                statusMessage = "Couldn't import from that URL: \(error.localizedDescription)"
            }
            isBusy = false
        }
    }

    // MARK: Captions

    /// Renders a temporary audio-only mixdown of the current timeline, then transcribes
    /// it on-device. Transcribing the mixdown (rather than a single source file) is what
    /// makes captions line up with multi-clip timelines.
    func generateCaptions() {
        guard project.duration.seconds > 0 else {
            statusMessage = "Add some clips to the timeline before generating captions."
            return
        }
        Task {
            isBusy = true
            busyMessage = "Preparing audio for transcription..."
            let tempURL = FileManager.default.temporaryDirectory.appendingPathComponent("\(UUID().uuidString).m4a")
            do {
                try await exportManager.export(project: project, preset: .audioOnly, to: tempURL)
                busyMessage = "Transcribing on-device..."
                let segments = try await speechTranscriber.transcribe(assetURL: tempURL, locale: Locale(identifier: "en-US"))
                project.captionSegments = segments
                markDirty()
                rebuildPreview()
                statusMessage = "Generated \(segments.count) caption line\(segments.count == 1 ? "" : "s")."
            } catch {
                statusMessage = "Couldn't generate captions: \(error.localizedDescription)"
            }
            try? FileManager.default.removeItem(at: tempURL)
            isBusy = false
        }
    }

    func exportSRT(to url: URL) {
        do {
            let content = SRTExporter.generate(from: project.captionSegments)
            try content.write(to: url, atomically: true, encoding: .utf8)
            statusMessage = "Saved captions to \(url.lastPathComponent)."
        } catch {
            statusMessage = "Couldn't save captions: \(error.localizedDescription)"
        }
    }
}
