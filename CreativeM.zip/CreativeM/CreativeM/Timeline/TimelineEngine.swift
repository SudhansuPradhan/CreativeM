import AppKit
import AVFoundation
import CoreImage
import CoreText
import CoreVideo
import Foundation
import QuartzCore

struct CompositionResult {
    let composition: AVMutableComposition
    let videoComposition: AVMutableVideoComposition?
    let audioMix: AVMutableAudioMix?
}

/// Builds the `AVMutableComposition` (+ video composition + audio mix) that both the
/// live preview player and `ExportManager` use, from a `Project`'s clips/tracks.
///
/// Deliberately avoids a custom `AVVideoCompositing` class or CIFilter-based video
/// composition: everything here is expressed with the standard, well-documented
/// `AVMutableVideoCompositionLayerInstruction` (cuts/transitions/transform) and
/// `AVVideoCompositionCoreAnimationTool` (titles/captions) building blocks, so there's
/// no hand-rolled pixel-buffer compositor in the critical path.
///
/// Note on `CMTime`: it is deliberately never used with stdlib `Comparable`-constrained
/// APIs (`sorted()`, `max()`, `Set`) below, since its `Comparable`/`Hashable` conformance
/// isn't something we can verify without a compiler in this environment. Every
/// comparison/sort here uses an explicit `<`/`>`/`==` operator or a `by:` closure instead.
enum TimelineEngine {

    /// - Parameter forPreview: When `true`, skips attaching `AVVideoCompositionCoreAnimationTool`
    ///   (titles/captions/images) to the returned video composition. Apple explicitly restricts
    ///   that tool to offline rendering: assigning a video composition that has it set as
    ///   `AVPlayerItem.videoComposition` throws an uncaught `NSInvalidArgumentException` and
    ///   crashes the process. Live preview must pass `true`; export (where it's legal, and is
    ///   the whole point of this tool) must pass `false` (the default).
    static func build(project: Project, renderSizeOverride: CGSize? = nil, forPreview: Bool = false) async throws -> CompositionResult {
        let renderSize = renderSizeOverride ?? project.renderSize.size
        let composition = AVMutableComposition()
        let totalDuration = project.duration

        var videoSegments: [VideoSegment] = []
        // Clips that actually made it into `videoSegments` (i.e. their source loaded,
        // inserted, and got real composited content) - the precise set `buildAnimationTool`
        // should consider for Video FX keyframing. Deliberately NOT derived as
        // "videoTrackClips minus imageClips" after the fact: a real video clip whose
        // asset/track failed to load partway through the loop below (several `continue`s)
        // never reaches `videoSegments` either, and that time range already renders solid
        // black via `buildVideoInstructions`'s "no active segment" case regardless of
        // Video FX - it shouldn't also get a spurious effects keyframe entry.
        var effectsEligibleClips: [Clip] = []
        var imageClips: [Clip] = []
        var embeddedAudioA: AVMutableCompositionTrack?
        var embeddedAudioB: AVMutableCompositionTrack?
        var embeddedAudioClipsA: [Clip] = []
        var embeddedAudioClipsB: [Clip] = []
        var videoTrackA: AVMutableCompositionTrack?
        var videoTrackB: AVMutableCompositionTrack?

        // Pre-computed up front (rather than down near `videoComposition`) because
        // whether we need trackA/trackB at all depends on titles/captions too, not just
        // on there being real video clips - see the `needsVideoCanvas` check below.
        let videoTrackClips = project.videoTrack.map { project.clips(on: $0.id) } ?? []
        let titleClips = project.titleTrack.map { project.clips(on: $0.id) } ?? []
        let burnInCaptionSegments = project.burnInCaptions ? project.captionSegments : []

        // MARK: Video track -> alternating A/B composition tracks
        //
        // Two composition tracks (rather than one) let adjacent clips overlap during a
        // cross-dissolve without either clip's content clobbering the other's. The same
        // A/B choice is reused for that clip's embedded audio for the same reason -
        // inserting overlapping audio onto a single shared track would ripple-shift
        // whatever was already placed there.
        //
        // `needsVideoCanvas` is true whenever there's *any* visual content - real video
        // clips, images (rendered via the title/caption CALayer path below, since a
        // still image has no `AVAssetTrack` of its own), titles, or burned-in captions.
        // Without this, a project that's titles/images only (no real video clip yet)
        // would never get a video composition at all and the preview would stay blank.
        let needsVideoCanvas = !videoTrackClips.isEmpty || !titleClips.isEmpty || !burnInCaptionSegments.isEmpty

        if needsVideoCanvas,
           let trackA = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid),
           let trackB = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid) {
            videoTrackA = trackA
            videoTrackB = trackB

            // Counts only clips actually inserted into trackA/trackB, so A/B alternation
            // (which exists purely to let cross-dissolves overlap safely) stays correct
            // even when image clips - which never reach `insertTimeRange` - sit between
            // two real video clips in `videoTrackClips`.
            var realVideoIndex = 0

            for clip in videoTrackClips {
                guard let mediaAsset = project.mediaAsset(clip.mediaAssetID) else { continue }

                // Still images have no video track to insert - AVURLAsset would return
                // an empty track list and silently drop the clip. Render them instead as
                // a timed CALayer alongside titles/captions (see `buildAnimationTool`).
                if mediaAsset.kind == .image {
                    imageClips.append(clip)
                    continue
                }

                let asset = AVURLAsset(url: mediaAsset.url)
                guard let videoTracks = try? await asset.loadTracks(withMediaType: .video),
                      let assetVideoTrack = videoTracks.first else { continue }

                let naturalSize = (try? await assetVideoTrack.load(.naturalSize)) ?? mediaAsset.naturalSize?.size ?? renderSize
                let preferredTransform = (try? await assetVideoTrack.load(.preferredTransform)) ?? .identity

                let isA = (realVideoIndex % 2 == 0)
                realVideoIndex += 1
                let target = isA ? trackA : trackB
                let sourceRange = clip.sourceTimeRange
                let timelineStart = clip.startTime.time

                do {
                    try target.insertTimeRange(sourceRange, of: assetVideoTrack, at: timelineStart)
                    if clip.speed != 1.0 {
                        let insertedRange = CMTimeRange(start: timelineStart, duration: sourceRange.duration)
                        target.scaleTimeRange(insertedRange, toDuration: clip.timelineDuration.time)
                    }
                } catch {
                    continue
                }

                if mediaAsset.hasAudio, !clip.isMuted {
                    if isA, embeddedAudioA == nil {
                        embeddedAudioA = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)
                    } else if !isA, embeddedAudioB == nil {
                        embeddedAudioB = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)
                    }
                    let audioTarget = isA ? embeddedAudioA : embeddedAudioB
                    let audioAsset = audioSourceAsset(for: clip, mediaAsset: mediaAsset, fallback: asset)

                    if let audioTracks = try? await audioAsset.loadTracks(withMediaType: .audio),
                       let assetAudioTrack = audioTracks.first,
                       let audioTarget {
                        try? audioTarget.insertTimeRange(sourceRange, of: assetAudioTrack, at: timelineStart)
                        if clip.speed != 1.0 {
                            let insertedRange = CMTimeRange(start: timelineStart, duration: sourceRange.duration)
                            audioTarget.scaleTimeRange(insertedRange, toDuration: clip.timelineDuration.time)
                        }
                        if isA {
                            embeddedAudioClipsA.append(clip)
                        } else {
                            embeddedAudioClipsB.append(clip)
                        }
                    }
                }

                let transform = layerTransform(
                    naturalSize: naturalSize,
                    preferredTransform: preferredTransform,
                    renderSize: renderSize,
                    userTransform: clip.transform
                )

                videoSegments.append(VideoSegment(
                    clipID: clip.id,
                    trackChoice: isA ? .a : .b,
                    timelineRange: clip.timelineRange,
                    transform: transform
                ))
                effectsEligibleClips.append(clip)
            }

            // Real video clips may not reach `totalDuration` on their own - a
            // title-only/image-only project has none at all, and a mixed timeline's
            // last real clip may end before its last title/image does. Either way,
            // without real track content reaching `totalDuration`, `composition.duration`
            // stays short (or zero), so the player can never advance a playhead past
            // that point and export produces nothing beyond it. See `padTrackDuration`.
            await padTrackDuration(trackA, upTo: totalDuration)
        }

        // Resolve image clips to `CGImage`s up front (needs disk I/O via `project.mediaAsset`,
        // which `buildAnimationTool` below deliberately doesn't have access to) so that
        // function can stay a pure layer-building helper like it already is for titles.
        var resolvedImageClips: [(clip: Clip, cgImage: CGImage)] = []
        for clip in imageClips {
            guard let mediaAsset = project.mediaAsset(clip.mediaAssetID),
                  let nsImage = NSImage(contentsOf: mediaAsset.url),
                  let cgImage = nsImage.cgImage(forProposedRect: nil, context: nil, hints: nil) else { continue }
            resolvedImageClips.append((clip, cgImage))
        }

        // MARK: Video composition (instructions + titles/captions)

        var videoComposition: AVMutableVideoComposition?
        if let trackA = videoTrackA, let trackB = videoTrackB {
            let composed = AVMutableVideoComposition()
            composed.renderSize = renderSize
            composed.frameDuration = CMTime(value: 1, timescale: Int32(max(project.frameRate, 1)))
            composed.instructions = buildVideoInstructions(
                segments: videoSegments,
                totalDuration: totalDuration,
                trackA: trackA,
                trackB: trackB
            )

            let hasVideoEffects = effectsEligibleClips.contains { !$0.effectiveVideoEffects.isIdentity }
            if !forPreview, !titleClips.isEmpty || !burnInCaptionSegments.isEmpty || !resolvedImageClips.isEmpty || hasVideoEffects {
                composed.animationTool = buildAnimationTool(
                    renderSize: renderSize,
                    titleClips: titleClips,
                    imageClips: resolvedImageClips,
                    captionSegments: burnInCaptionSegments,
                    videoEffectsClips: effectsEligibleClips,
                    totalDuration: totalDuration
                )
            }

            videoComposition = composed
        }

        // MARK: Audio tracks (dialogue / music / sfx / embedded video audio)

        var audioMixParams: [AVMutableAudioMixInputParameters] = []

        let triggerTrack = project.tracks.first { $0.kind == .audio && $0.isDuckingTrigger }
        let triggerRanges: [CMTimeRange] = triggerTrack.map { project.clips(on: $0.id).map(\.timelineRange) } ?? []

        if let embeddedAudioA, !embeddedAudioClipsA.isEmpty {
            let envelope = VolumeEnvelope.forClips(embeddedAudioClipsA, trackVolume: 1.0, duckTriggerRanges: [])
            audioMixParams.append(envelope.makeParameters(for: embeddedAudioA))
        }
        if let embeddedAudioB, !embeddedAudioClipsB.isEmpty {
            let envelope = VolumeEnvelope.forClips(embeddedAudioClipsB, trackVolume: 1.0, duckTriggerRanges: [])
            audioMixParams.append(envelope.makeParameters(for: embeddedAudioB))
        }

        for track in project.audioTracks where track.isEnabled {
            let clips = project.clips(on: track.id)
            guard !clips.isEmpty,
                  let compTrack = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) else { continue }

            for clip in clips {
                guard let mediaAsset = project.mediaAsset(clip.mediaAssetID) else { continue }
                let asset = AVURLAsset(url: mediaAsset.url)
                let audioAsset = audioSourceAsset(for: clip, mediaAsset: mediaAsset, fallback: asset)
                guard let audioTracks = try? await audioAsset.loadTracks(withMediaType: .audio),
                      let assetAudioTrack = audioTracks.first else { continue }
                let timelineStart = clip.startTime.time
                do {
                    try compTrack.insertTimeRange(clip.sourceTimeRange, of: assetAudioTrack, at: timelineStart)
                    if clip.speed != 1.0 {
                        let insertedRange = CMTimeRange(start: timelineStart, duration: clip.sourceTimeRange.duration)
                        compTrack.scaleTimeRange(insertedRange, toDuration: clip.timelineDuration.time)
                    }
                } catch {
                    continue
                }
            }

            let applicableDuckRanges = track.isDuckingTarget ? triggerRanges : []
            let envelope = VolumeEnvelope.forClips(clips, trackVolume: track.volume, duckTriggerRanges: applicableDuckRanges)
            audioMixParams.append(envelope.makeParameters(for: compTrack))
        }

        var audioMix: AVMutableAudioMix?
        if !audioMixParams.isEmpty {
            let mix = AVMutableAudioMix()
            mix.inputParameters = audioMixParams
            audioMix = mix
        }

        return CompositionResult(composition: composition, videoComposition: videoComposition, audioMix: audioMix)
    }

    // MARK: - Audio FX substitution (export-time only; preview reads the cache as-is)

    /// Returns the cached, effects-processed asset for `clip` when one exists, else
    /// `fallback` (the clip's original source). Deliberately a pure cache *read* - never
    /// renders here, so this stays cheap enough to call from the live-preview build path
    /// too (`rebuildPreview()` runs this on every edit). Rendering is kicked off
    /// elsewhere: `ExportManager` awaits it before building, `AppState` schedules a
    /// best-effort background render so preview catches up on its next rebuild.
    private static func audioSourceAsset(for clip: Clip, mediaAsset: MediaAsset, fallback: AVURLAsset) -> AVURLAsset {
        let effects = clip.effectiveAudioEffects
        guard !effects.isIdentity,
              let cachedURL = AudioEffectsProcessor.cachedURL(mediaAssetID: mediaAsset.id, effects: effects) else {
            return fallback
        }
        return AVURLAsset(url: cachedURL)
    }

    // MARK: - Duration padding (real content, not an empty range)

    /// Ensures `track`'s real content reaches `totalDuration` by inserting a sliver of
    /// the cached blank video asset and stretching it to fill the gap, starting from
    /// wherever the track's real content currently ends (`.zero` if it has none at all).
    /// Only ever extends the tail, so it can never ripple-shift or overlap content
    /// already inserted earlier in the track.
    ///
    /// Deliberately does NOT use `insertEmptyTimeRange` here: verified empirically that
    /// an otherwise-untouched composition track's `timeRange` stays invalid after an
    /// empty-range-only insert, and `AVComposition.duration` stays zero - an empty range
    /// doesn't count as real content. Only genuinely inserted (even if trivial/stretched)
    /// media registers. Without this, a title-only or image-only project's composition
    /// has zero real duration: the player item has nothing to advance a playhead through
    /// (it just sits at 0) and `AVAssetExportSession` fails outright.
    private static func padTrackDuration(_ track: AVMutableCompositionTrack, upTo totalDuration: CMTime) async {
        let currentEnd = track.timeRange.isValid ? track.timeRange.end : .zero
        guard currentEnd < totalDuration else { return }

        do {
            let blank = try await cachedBlankVideoAsset()
            guard let blankTrack = try await blank.loadTracks(withMediaType: .video).first else { return }
            let sliver = CMTimeRange(start: .zero, duration: CMTime(value: 1, timescale: 30))
            try track.insertTimeRange(sliver, of: blankTrack, at: currentEnd)
            track.scaleTimeRange(CMTimeRange(start: currentEnd, duration: sliver.duration), toDuration: CMTimeSubtract(totalDuration, currentEnd))
        } catch {
            // Best-effort, matching every other `try?`-style fallback in this file:
            // if this fails, the project behaves exactly as it did before this fix
            // existed (short/zero composition duration) rather than throwing and
            // blocking preview/export entirely over what is a secondary concern.
        }
    }

    /// A tiny (16x16, 1-frame) real black video file, generated once and cached on disk
    /// (`AppPaths.blankVideoURL`), used purely as real content for `padTrackDuration`
    /// above. Its pixel content never reaches the screen: any time range with no active
    /// `videoSegments` already renders as plain black via `buildVideoInstructions`'s
    /// `instruction.layerInstructions = []` case, regardless of what's underneath - so
    /// one fixed-size file, shared across every project and render size forever, is
    /// correct, and it's never regenerated once it exists on disk.
    private static func cachedBlankVideoAsset() async throws -> AVURLAsset {
        let url = AppPaths.blankVideoURL
        if FileManager.default.fileExists(atPath: url.path) {
            return AVURLAsset(url: url)
        }

        let writer = try AVAssetWriter(outputURL: url, fileType: .mov)
        let settings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: 16,
            AVVideoHeightKey: 16
        ]
        let input = AVAssetWriterInput(mediaType: .video, outputSettings: settings)
        let pixelAttrs: [String: Any] = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32ARGB]
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: pixelAttrs)
        writer.add(input)
        writer.startWriting()
        writer.startSession(atSourceTime: .zero)

        var pixelBufferOut: CVPixelBuffer?
        CVPixelBufferCreate(kCFAllocatorDefault, 16, 16, kCVPixelFormatType_32ARGB, pixelAttrs as CFDictionary, &pixelBufferOut)
        guard let pixelBuffer = pixelBufferOut else {
            throw NSError(domain: "TimelineEngine", code: 1, userInfo: [NSLocalizedDescriptionKey: "Could not allocate blank pixel buffer"])
        }
        CVPixelBufferLockBaseAddress(pixelBuffer, [])
        if let base = CVPixelBufferGetBaseAddress(pixelBuffer) {
            memset(base, 0, CVPixelBufferGetDataSize(pixelBuffer))
        }
        CVPixelBufferUnlockBaseAddress(pixelBuffer, [])

        adaptor.append(pixelBuffer, withPresentationTime: .zero)
        input.markAsFinished()

        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            writer.finishWriting { continuation.resume() }
        }
        if writer.status == .failed {
            throw writer.error ?? NSError(domain: "TimelineEngine", code: 2, userInfo: [NSLocalizedDescriptionKey: "Blank video writer failed"])
        }
        return AVURLAsset(url: url)
    }

    // MARK: - Transform

    /// Orients the source frame per its `preferredTransform`, aspect-fits (letterboxed)
    /// it into `renderSize`, then applies the clip's own scale/rotate/offset about the
    /// render frame's center.
    static func layerTransform(
        naturalSize: CGSize,
        preferredTransform: CGAffineTransform,
        renderSize: CGSize,
        userTransform: ClipTransform
    ) -> CGAffineTransform {
        let orientedRect = CGRect(origin: .zero, size: naturalSize).applying(preferredTransform)
        let safeWidth = max(orientedRect.width, 1)
        let safeHeight = max(orientedRect.height, 1)

        let normalizing = preferredTransform.concatenating(
            CGAffineTransform(translationX: -orientedRect.origin.x, y: -orientedRect.origin.y)
        )

        let fitScale = min(renderSize.width / safeWidth, renderSize.height / safeHeight)
        let fittedWidth = safeWidth * fitScale
        let fittedHeight = safeHeight * fitScale
        let centerOffsetX = (renderSize.width - fittedWidth) / 2
        let centerOffsetY = (renderSize.height - fittedHeight) / 2

        let fitTransform = normalizing
            .concatenating(CGAffineTransform(scaleX: fitScale, y: fitScale))
            .concatenating(CGAffineTransform(translationX: centerOffsetX, y: centerOffsetY))

        let cx = renderSize.width / 2
        let cy = renderSize.height / 2
        let radians = CGFloat(userTransform.rotationDegrees) * .pi / 180
        let userScale = CGFloat(userTransform.scale)
        let userOffsetX = CGFloat(userTransform.offsetX) * renderSize.width / 2
        let userOffsetY = CGFloat(userTransform.offsetY) * renderSize.height / 2

        let userAdjust = CGAffineTransform(translationX: -cx, y: -cy)
            .concatenating(CGAffineTransform(rotationAngle: radians))
            .concatenating(CGAffineTransform(scaleX: userScale, y: userScale))
            .concatenating(CGAffineTransform(translationX: cx + userOffsetX, y: cy + userOffsetY))

        return fitTransform.concatenating(userAdjust)
    }

    // MARK: - Video composition instructions (cuts + cross-dissolve)

    private static func buildVideoInstructions(
        segments: [VideoSegment],
        totalDuration: CMTime,
        trackA: AVMutableCompositionTrack,
        trackB: AVMutableCompositionTrack
    ) -> [AVMutableVideoCompositionInstruction] {
        guard totalDuration > .zero else { return [] }

        var breakpointTimes: [CMTime] = [.zero, totalDuration]
        for segment in segments {
            breakpointTimes.append(segment.timelineRange.start)
            breakpointTimes.append(segment.timelineRange.end)
        }
        let breakpoints = sortedUniqueTimes(breakpointTimes)

        var instructions: [AVMutableVideoCompositionInstruction] = []

        for i in 0..<(breakpoints.count - 1) {
            let rangeStart = breakpoints[i]
            let rangeEnd = breakpoints[i + 1]
            guard rangeEnd > rangeStart else { continue }

            let active = segments
                .filter { $0.timelineRange.start <= rangeStart && $0.timelineRange.end >= rangeEnd }
                .sorted { $0.timelineRange.start < $1.timelineRange.start }

            let instruction = AVMutableVideoCompositionInstruction()
            instruction.timeRange = CMTimeRange(start: rangeStart, end: rangeEnd)
            instruction.backgroundColor = NSColor.black.cgColor

            switch active.count {
            case 0:
                instruction.layerInstructions = []

            case 1:
                let segment = active[0]
                let layer = AVMutableVideoCompositionLayerInstruction(
                    assetTrack: track(for: segment.trackChoice, a: trackA, b: trackB)
                )
                layer.setTransform(segment.transform, at: rangeStart)
                instruction.layerInstructions = [layer]

            default:
                let earlier = active[0]
                let later = active[1]
                let overlapEnd = minTime(earlier.timelineRange.end, later.timelineRange.end)
                let overlapRange = CMTimeRange(start: later.timelineRange.start, end: maxTime(overlapEnd, later.timelineRange.start))

                let earlierLayer = AVMutableVideoCompositionLayerInstruction(
                    assetTrack: track(for: earlier.trackChoice, a: trackA, b: trackB)
                )
                earlierLayer.setTransform(earlier.transform, at: rangeStart)
                earlierLayer.setOpacityRamp(fromStartOpacity: 1, toEndOpacity: 0, timeRange: overlapRange)

                let laterLayer = AVMutableVideoCompositionLayerInstruction(
                    assetTrack: track(for: later.trackChoice, a: trackA, b: trackB)
                )
                laterLayer.setTransform(later.transform, at: rangeStart)
                laterLayer.setOpacityRamp(fromStartOpacity: 0, toEndOpacity: 1, timeRange: overlapRange)

                instruction.layerInstructions = [earlierLayer, laterLayer]
            }

            instructions.append(instruction)
        }

        return instructions
    }

    private static func track(for choice: TrackChoice, a: AVMutableCompositionTrack, b: AVMutableCompositionTrack) -> AVMutableCompositionTrack {
        choice == .a ? a : b
    }

    // MARK: - Titles & captions (Core Animation burn-in)

    private static func buildAnimationTool(
        renderSize: CGSize,
        titleClips: [Clip],
        imageClips: [(clip: Clip, cgImage: CGImage)],
        captionSegments: [CaptionSegment],
        videoEffectsClips: [Clip],
        totalDuration: CMTime
    ) -> AVVideoCompositionCoreAnimationTool {
        let parentLayer = CALayer()
        parentLayer.frame = CGRect(origin: .zero, size: renderSize)

        let videoLayer = CALayer()
        videoLayer.frame = CGRect(origin: .zero, size: renderSize)
        parentLayer.addSublayer(videoLayer)
        applyVideoEffects(to: videoLayer, clips: videoEffectsClips, totalDuration: totalDuration)

        let totalSeconds = totalDuration.seconds

        // Images are composited full-frame, aspect-fit (`.resizeAspect`, letterboxed,
        // centered) via the same CALayer timing machinery as titles below. Per-clip
        // `transform` (scale/position/rotation) isn't applied to images yet - that math
        // is tuned for CALayer's default center-anchored transform semantics, not the
        // origin-relative one `layerTransform` above produces for real video tracks, so
        // wiring it up needs its own verified pass rather than reusing that function as-is.
        for (clip, cgImage) in imageClips {
            let imageLayer = CALayer()
            imageLayer.frame = CGRect(origin: .zero, size: renderSize)
            imageLayer.contents = cgImage
            imageLayer.contentsGravity = .resizeAspect
            imageLayer.opacity = 0
            let fade = min(0.3, clip.timelineDuration.seconds * 0.2)
            addTiming(
                to: imageLayer,
                start: clip.startTime.seconds,
                duration: clip.timelineDuration.seconds,
                fade: fade,
                totalDuration: totalSeconds
            )
            parentLayer.addSublayer(imageLayer)
        }

        for clip in titleClips {
            guard let style = clip.title else { continue }
            let textLayer = makeTextLayer(style: style, renderSize: renderSize)
            addTiming(
                to: textLayer,
                start: clip.startTime.seconds,
                duration: clip.timelineDuration.seconds,
                fade: style.fadeDuration.seconds,
                totalDuration: totalSeconds
            )
            parentLayer.addSublayer(textLayer)
        }

        for caption in captionSegments {
            let style = TitleStyle(
                text: caption.text,
                fontSize: 44,
                colorHex: "#FFFFFF",
                backgroundOpacity: 0.55,
                position: .bottom,
                fadeDuration: CodableTime(seconds: 0.1)
            )
            let textLayer = makeTextLayer(style: style, renderSize: renderSize)
            let duration = max(0.05, caption.end.seconds - caption.start.seconds)
            addTiming(
                to: textLayer,
                start: caption.start.seconds,
                duration: duration,
                fade: 0.1,
                totalDuration: totalSeconds
            )
            parentLayer.addSublayer(textLayer)
        }

        return AVVideoCompositionCoreAnimationTool(postProcessingAsVideoLayer: videoLayer, in: parentLayer)
    }

    // MARK: - Video FX (CALayer CIFilter chain, export-only)

    /// Attaches the premium Video FX filter chain to the single shared `videoLayer` that
    /// `postProcessingAsVideoLayer` wraps - `CIColorControls -> CIVignette ->
    /// CIGaussianBlur`, in that order (color correction first, then a stylistic vignette,
    /// then blur last) - with each numeric parameter keyframed across the whole timeline
    /// so different clips' different `VideoEffects` settings hold for their own time
    /// range. A no-op (does nothing to `videoLayer`) when no clip in `clips` has
    /// non-identity effects, so an export with the feature unused is unaffected.
    ///
    /// Deliberately only ever touches `videoLayer` - NOT any image/title/caption
    /// sublayer added elsewhere in `buildAnimationTool` - because those are separate
    /// sibling layers in `parentLayer`'s tree, composited alongside (not through)
    /// `videoLayer`. That's why image clips don't get Video FX yet either (same
    /// limitation already called out for `transform` on images) - verified empirically
    /// (standalone AVFoundation harness) that this scoping is exactly what
    /// `postProcessingAsVideoLayer` + sibling CALayers actually do, not assumed.
    private static func applyVideoEffects(to videoLayer: CALayer, clips: [Clip], totalDuration: CMTime) {
        guard clips.contains(where: { !$0.effectiveVideoEffects.isIdentity }) else { return }
        guard let colorControls = CIFilter(name: "CIColorControls"),
              let vignette = CIFilter(name: "CIVignette"),
              let blur = CIFilter(name: "CIGaussianBlur") else { return }

        colorControls.name = "cmVideoFxColor"
        vignette.name = "cmVideoFxVignette"
        blur.name = "cmVideoFxBlur"

        // Explicit IDENTITY baseline for every keyframed key, unconditionally - not
        // optional. `keyframeAnimation` below only adds an animation for a parameter
        // when at least one clip sets it away from identity (`anyNonIdentity`); any
        // parameter NO clip touches (e.g. a project that only ever adjusts saturation)
        // gets no animation at all for brightness/contrast/vignette/blur, which would
        // otherwise leave those keys at each CIFilter's own undocumented built-in
        // default - verified empirically (standalone harness) that this is a REAL,
        // severe bug, not a theoretical one: `CIGaussianBlur`'s default `inputRadius`
        // is NOT 0, so skipping this baseline measurably blurred/darkened footage that
        // never had any Video FX applied to it at all. Setting these explicitly first
        // means "no clip touches this parameter" correctly behaves as a true no-op.
        colorControls.setValue(0.0, forKey: "inputBrightness")
        colorControls.setValue(1.0, forKey: "inputContrast")
        colorControls.setValue(1.0, forKey: "inputSaturation")
        vignette.setValue(0.0, forKey: "inputIntensity")
        // Fixed, non-user-adjustable: only `inputIntensity` is exposed as a slider (see
        // `VideoEffects.vignetteAmount`'s doc comment) - this just picks a reasonable
        // falloff radius for a standard frame, verified visually sane in the standalone
        // harness (a strong vignette noticeably darkens frame corners at this radius).
        vignette.setValue(1.5, forKey: "inputRadius")
        blur.setValue(0.0, forKey: "inputRadius")
        videoLayer.filters = [colorControls, vignette, blur]

        let parameters: [(keyPath: String, identity: Double, valueFor: (VideoEffects) -> Double)] = [
            ("filters.cmVideoFxColor.inputBrightness", 0, { $0.brightness }),
            ("filters.cmVideoFxColor.inputContrast", 1, { $0.contrast }),
            ("filters.cmVideoFxColor.inputSaturation", 1, { $0.saturation }),
            ("filters.cmVideoFxVignette.inputIntensity", 0, { $0.vignetteAmount }),
            ("filters.cmVideoFxBlur.inputRadius", 0, { $0.blurRadius })
        ]
        for parameter in parameters {
            guard let animation = keyframeAnimation(keyPath: parameter.keyPath, clips: clips, identity: parameter.identity, totalDuration: totalDuration, valueFor: parameter.valueFor) else { continue }
            videoLayer.add(animation, forKey: parameter.keyPath)
        }
    }

    /// Builds one discrete-step `CAKeyframeAnimation` for a single Video FX parameter,
    /// covering the WHOLE timeline - not just the clips that set it. Any stretch of the
    /// timeline not covered by a clip in `clips` (a gap, or a title/audio-only moment)
    /// uses `identity`, so unaffected footage renders exactly as it did before this
    /// feature existed. Returns `nil` when every clip's value for this parameter is
    /// already `identity` (nothing to animate).
    ///
    /// Mirrors `buildVideoInstructions`' breakpoint-merge shape (collect every clip's
    /// start/end as a breakpoint, walk the sorted, de-duplicated result) rather than
    /// introducing a second way to slice up the timeline. Constructs
    /// `CAKeyframeAnimation(keyPath:)` directly (keyPath supplied up front, never
    /// assigned after the fact) - the exact initializer shape verified empirically in
    /// the standalone harness, rather than relying on the separate `.keyPath` property
    /// being settable post-construction too.
    private static func keyframeAnimation(
        keyPath: String,
        clips: [Clip],
        identity: Double,
        totalDuration: CMTime,
        valueFor: (VideoEffects) -> Double
    ) -> CAKeyframeAnimation? {
        let totalSeconds = totalDuration.seconds
        guard totalSeconds > 0 else { return nil }

        var breakpoints: Set<Double> = [0, totalSeconds]
        for clip in clips {
            breakpoints.insert(min(totalSeconds, max(0, clip.startTime.seconds)))
            breakpoints.insert(min(totalSeconds, max(0, clip.endTime.seconds)))
        }
        let sorted = breakpoints.sorted()
        guard sorted.count > 1 else { return nil }

        var keyTimes: [NSNumber] = []
        var values: [Double] = []
        var anyNonIdentity = false

        for i in 0..<(sorted.count - 1) {
            let segmentStart = sorted[i]
            // Last match wins if clips ever overlap on one video track (shouldn't
            // normally happen, but stays harmless/deterministic either way).
            let activeClip = clips.last { $0.startTime.seconds <= segmentStart && $0.endTime.seconds > segmentStart }
            let value = activeClip.map { valueFor($0.effectiveVideoEffects) } ?? identity
            if value != identity { anyNonIdentity = true }
            keyTimes.append(NSNumber(value: segmentStart / totalSeconds))
            values.append(value)
        }
        // Discrete mode holds values[i] from keyTimes[i] up to (not including)
        // keyTimes[i+1] - verified empirically (standalone harness) - so this needs one
        // trailing keyTime (1.0) to close out the final segment; its paired value is
        // never actually sampled (discrete mode has nothing after the last keyTime) but
        // keyTimes.count must equal values.count.
        keyTimes.append(1.0)
        values.append(values.last ?? identity)

        guard anyNonIdentity else { return nil }

        let animation = CAKeyframeAnimation(keyPath: keyPath)
        animation.beginTime = AVCoreAnimationBeginTimeAtZero
        animation.duration = totalSeconds
        animation.isRemovedOnCompletion = false
        animation.fillMode = .both
        animation.calculationMode = .discrete
        animation.keyTimes = keyTimes
        animation.values = values
        return animation
    }

    private static func makeTextLayer(style: TitleStyle, renderSize: CGSize) -> CATextLayer {
        let padding: CGFloat = 40
        let height: CGFloat = CGFloat(style.fontSize) * 1.8
        let width = renderSize.width - padding * 2

        let yPosition: CGFloat
        switch style.position {
        case .top: yPosition = renderSize.height - padding - height
        case .center: yPosition = (renderSize.height - height) / 2
        case .bottom: yPosition = padding
        }

        let layer = CATextLayer()
        layer.frame = CGRect(x: padding, y: yPosition, width: max(width, 1), height: height)
        layer.string = style.text
        layer.font = CTFontCreateWithName(style.fontName as CFString, CGFloat(style.fontSize), nil)
        layer.fontSize = CGFloat(style.fontSize)
        layer.foregroundColor = NSColor(hex: style.colorHex).cgColor
        layer.alignmentMode = .center
        layer.isWrapped = true
        layer.contentsScale = 2.0
        layer.opacity = 0

        if style.backgroundOpacity > 0 {
            layer.backgroundColor = NSColor.black.withAlphaComponent(style.backgroundOpacity).cgColor
        }

        return layer
    }

    private static func addTiming(to layer: CALayer, start: Double, duration: Double, fade: Double, totalDuration: Double) {
        guard totalDuration > 0, duration > 0 else { return }
        let clampedFade = max(0, min(fade, duration * 0.49))
        let fadeFraction = clampedFade / duration

        let animation = CAKeyframeAnimation(keyPath: "opacity")
        animation.beginTime = AVCoreAnimationBeginTimeAtZero + start
        animation.duration = duration
        animation.isRemovedOnCompletion = false
        animation.fillMode = .both
        animation.calculationMode = .linear

        if fadeFraction > 0 {
            animation.keyTimes = [0, NSNumber(value: fadeFraction), NSNumber(value: 1 - fadeFraction), 1]
            animation.values = [0, 1, 1, 0]
        } else {
            animation.keyTimes = [0, 1]
            animation.values = [1, 1]
        }

        layer.opacity = 0
        layer.add(animation, forKey: "titleOpacity")
    }

    // MARK: - CMTime helpers (deliberately avoid stdlib Comparable-constrained APIs)

    private static func minTime(_ a: CMTime, _ b: CMTime) -> CMTime { a < b ? a : b }
    private static func maxTime(_ a: CMTime, _ b: CMTime) -> CMTime { a > b ? a : b }

    private static func sortedUniqueTimes(_ times: [CMTime]) -> [CMTime] {
        let sorted = times.sorted { $0 < $1 }
        var result: [CMTime] = []
        for t in sorted {
            if let last = result.last, last == t { continue }
            result.append(t)
        }
        return result
    }
}

// MARK: - Supporting types

private enum TrackChoice {
    case a, b
}

private struct VideoSegment {
    let clipID: UUID
    let trackChoice: TrackChoice
    let timelineRange: CMTimeRange
    let transform: CGAffineTransform
}

/// A piecewise-linear volume curve built from clip fades and (optionally) ducking
/// dips under another track's clips, ready to hand to `AVMutableAudioMixInputParameters`.
private struct VolumeEnvelope {
    struct Point {
        let time: CMTime
        let volume: Float
    }

    var points: [Point]

    func value(at time: CMTime) -> Float {
        guard let first = points.first, let last = points.last else { return 1 }
        if time < first.time { return first.volume }
        if time > last.time { return last.volume }
        for i in 0..<(points.count - 1) {
            let a = points[i]
            let b = points[i + 1]
            if time >= a.time && time <= b.time {
                if b.time == a.time { return b.volume }
                let span = CMTimeGetSeconds(CMTimeSubtract(b.time, a.time))
                guard span > 0 else { return b.volume }
                let t = CMTimeGetSeconds(CMTimeSubtract(time, a.time)) / span
                return a.volume + Float(t) * (b.volume - a.volume)
            }
        }
        return last.volume
    }

    func makeParameters(for track: AVMutableCompositionTrack) -> AVMutableAudioMixInputParameters {
        let params = AVMutableAudioMixInputParameters(track: track)
        guard points.count >= 2 else {
            if let only = points.first {
                params.setVolume(only.volume, at: .zero)
            }
            return params
        }
        for i in 0..<(points.count - 1) {
            let a = points[i]
            let b = points[i + 1]
            guard b.time > a.time else { continue }
            params.setVolumeRamp(fromStartVolume: a.volume, toEndVolume: b.volume, timeRange: CMTimeRange(start: a.time, end: b.time))
        }
        return params
    }

    static func forClips(_ clips: [Clip], trackVolume: Float, duckTriggerRanges: [CMTimeRange]) -> VolumeEnvelope {
        var fadePoints: [Point] = []
        for clip in clips {
            let base: Float = clip.isMuted ? 0 : clip.volume * trackVolume
            let start = clip.startTime.time
            let end = clip.endTime.time
            let fadeIn = clip.fadeIn.time < clip.timelineDuration.time ? clip.fadeIn.time : clip.timelineDuration.time
            let fadeOut = clip.fadeOut.time < clip.timelineDuration.time ? clip.fadeOut.time : clip.timelineDuration.time

            fadePoints.append(Point(time: start, volume: 0))
            if fadeIn > .zero {
                fadePoints.append(Point(time: CMTimeAdd(start, fadeIn), volume: base))
            } else {
                fadePoints.append(Point(time: start, volume: base))
            }
            if fadeOut > .zero {
                fadePoints.append(Point(time: CMTimeSubtract(end, fadeOut), volume: base))
            }
            fadePoints.append(Point(time: end, volume: 0))
        }
        fadePoints.sort { $0.time < $1.time }
        if fadePoints.isEmpty {
            fadePoints = [Point(time: .zero, volume: 0)]
        }
        let fadeEnvelope = VolumeEnvelope(points: fadePoints)

        guard !duckTriggerRanges.isEmpty else { return fadeEnvelope }

        let attack = CMTime(seconds: 0.3, preferredTimescale: 600)
        let release = CMTime(seconds: 0.5, preferredTimescale: 600)
        let duckLevel: Float = 0.25

        var duckPoints: [Point] = [Point(time: .zero, volume: 1)]
        for range in mergeRanges(duckTriggerRanges) {
            let dipStartRaw = CMTimeSubtract(range.start, attack)
            let dipStart = dipStartRaw > .zero ? dipStartRaw : .zero
            let dipEnd = CMTimeAdd(range.end, release)
            duckPoints.append(Point(time: dipStart, volume: 1))
            duckPoints.append(Point(time: range.start, volume: duckLevel))
            duckPoints.append(Point(time: range.end, volume: duckLevel))
            duckPoints.append(Point(time: dipEnd, volume: 1))
        }
        duckPoints.sort { $0.time < $1.time }
        let duckEnvelope = VolumeEnvelope(points: duckPoints)

        var allTimes = fadePoints.map(\.time)
        allTimes.append(contentsOf: duckPoints.map(\.time))
        let sortedTimes = allTimes.sorted { $0 < $1 }
        var uniqueTimes: [CMTime] = []
        for t in sortedTimes {
            if let last = uniqueTimes.last, last == t { continue }
            uniqueTimes.append(t)
        }

        let combinedPoints = uniqueTimes.map { t in
            Point(time: t, volume: fadeEnvelope.value(at: t) * duckEnvelope.value(at: t))
        }
        return VolumeEnvelope(points: combinedPoints)
    }

    private static func mergeRanges(_ ranges: [CMTimeRange]) -> [CMTimeRange] {
        guard !ranges.isEmpty else { return [] }
        let sorted = ranges.sorted { $0.start < $1.start }
        var merged: [CMTimeRange] = [sorted[0]]
        for range in sorted.dropFirst() {
            let lastIndex = merged.count - 1
            if range.start <= merged[lastIndex].end {
                let newEnd = range.end > merged[lastIndex].end ? range.end : merged[lastIndex].end
                merged[lastIndex] = CMTimeRange(start: merged[lastIndex].start, end: newEnd)
            } else {
                merged.append(range)
            }
        }
        return merged
    }
}
