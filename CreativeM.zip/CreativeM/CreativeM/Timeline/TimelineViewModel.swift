import AVFoundation
import Foundation

/// All clip/track editing operations, layered onto `AppState` as an extension so
/// `AppState.swift` can stay focused on state + app-level orchestration.
///
/// Every mutation goes through `performEdit`, which snapshots the project for undo,
/// marks it dirty, and recompiles the preview - so no editing action can accidentally
/// skip undo registration or leave the preview stale.
extension AppState {

    // MARK: - Undo-aware mutation core

    func performEdit(_ mutation: (inout Project) -> Void) {
        var newProject = project
        mutation(&newProject)
        setProject(newProject)
    }

    /// Classic Cocoa "snapshot" undo: registering `setProject(oldProject)` as the undo
    /// action, and because that handler calls `setProject` again when it runs, the
    /// undo manager automatically turns that into the matching redo action.
    func setProject(_ newProject: Project, actionName: String? = nil) {
        let oldProject = project
        undoManager.registerUndo(withTarget: self) { target in
            target.setProject(oldProject)
        }
        if let actionName {
            undoManager.setActionName(actionName)
        }
        project = newProject
        markDirty()
        rebuildPreview()
    }

    private func clipKind(for trackKind: TrackKind) -> ClipKind {
        switch trackKind {
        case .video: return .video
        case .audio: return .audio
        case .title: return .title
        }
    }

    // MARK: - Adding clips

    /// `initialAudioEffects` lets a caller (e.g. a freshly-recorded mic clip with a
    /// voice preset already chosen) bake Audio FX settings into the SAME undo step
    /// that creates the clip, rather than creating it dry and setting effects as a
    /// separate `setClipAudioEffects` call afterward (two undo steps, plus a brief
    /// dry-audio flash in the project before the second edit lands).
    @discardableResult
    func appendClipToEnd(of trackID: UUID, mediaAsset: MediaAsset, initialAudioEffects: AudioEffects? = nil) -> UUID {
        let newID = UUID()
        performEdit { proj in
            guard let track = proj.tracks.first(where: { $0.id == trackID }) else { return }
            let start = proj.clips(on: track.id).last?.endTime ?? .zero
            let clip = Clip(
                id: newID,
                trackID: trackID,
                kind: clipKind(for: track.kind),
                mediaAssetID: mediaAsset.id,
                startTime: start,
                sourceInPoint: .zero,
                timelineDuration: mediaAsset.duration,
                audioEffects: initialAudioEffects,
                displayName: mediaAsset.displayName
            )
            proj.clips.append(clip)
        }
        selectedClipID = newID
        return newID
    }

    /// Inserts at an explicit timeline position, rippling later clips on the *same*
    /// track forward to make room.
    @discardableResult
    func insertClip(mediaAsset: MediaAsset, trackID: UUID, atSeconds seconds: Double) -> UUID {
        let newID = UUID()
        performEdit { proj in
            guard let track = proj.tracks.first(where: { $0.id == trackID }) else { return }
            let insertStart = CodableTime(seconds: max(0, seconds))
            let clipDuration = mediaAsset.duration

            for index in proj.clips.indices where proj.clips[index].trackID == trackID {
                if proj.clips[index].startTime >= insertStart {
                    proj.clips[index].startTime = proj.clips[index].startTime + clipDuration
                }
            }

            let clip = Clip(
                id: newID,
                trackID: trackID,
                kind: clipKind(for: track.kind),
                mediaAssetID: mediaAsset.id,
                startTime: insertStart,
                sourceInPoint: .zero,
                timelineDuration: clipDuration,
                displayName: mediaAsset.displayName
            )
            proj.clips.append(clip)
        }
        selectedClipID = newID
        return newID
    }

    @discardableResult
    func addTitleClip(atSeconds seconds: Double, durationSeconds: Double = 3.0) -> UUID? {
        guard let titleTrack = project.titleTrack else { return nil }
        let newID = UUID()
        performEdit { proj in
            let clip = Clip(
                id: newID,
                trackID: titleTrack.id,
                kind: .title,
                mediaAssetID: nil,
                startTime: CodableTime(seconds: max(0, seconds)),
                sourceInPoint: .zero,
                timelineDuration: CodableTime(seconds: durationSeconds),
                title: TitleStyle(),
                displayName: "Title"
            )
            proj.clips.append(clip)
        }
        selectedClipID = newID
        return newID
    }

    // MARK: - Splitting & deleting

    func splitAtPlayhead() {
        let seconds = playheadSeconds
        let newSecondID = UUID()
        var didSplit = false

        performEdit { proj in
            guard let index = proj.clips.firstIndex(where: { clip in
                seconds > clip.startTime.seconds + 0.05 && seconds < clip.endTime.seconds - 0.05
            }) else { return }

            let original = proj.clips[index]
            let splitSeconds = seconds - original.startTime.seconds
            let consumedSourceSeconds = splitSeconds * original.speed

            var first = original
            first.timelineDuration = CodableTime(seconds: splitSeconds)
            first.fadeOut = .zero

            var second = original
            second.id = newSecondID
            second.startTime = CodableTime(seconds: seconds)
            second.timelineDuration = CodableTime(seconds: original.endTime.seconds - seconds)
            second.sourceInPoint = CodableTime(seconds: original.sourceInPoint.seconds + consumedSourceSeconds)
            second.transitionIn = .none
            second.fadeIn = .zero

            proj.clips[index] = first
            proj.clips.insert(second, at: index + 1)
            didSplit = true
        }

        if didSplit {
            selectedClipID = newSecondID
        }
    }

    func deleteClip(_ clipID: UUID, ripple: Bool = false) {
        performEdit { proj in
            guard let clip = proj.clips.first(where: { $0.id == clipID }) else { return }
            let trackID = clip.trackID
            let duration = clip.timelineDuration.seconds
            let start = clip.startTime

            proj.clips.removeAll { $0.id == clipID }

            if ripple {
                for index in proj.clips.indices where proj.clips[index].trackID == trackID {
                    if proj.clips[index].startTime >= start {
                        let newStart = proj.clips[index].startTime.seconds - duration
                        proj.clips[index].startTime = CodableTime(seconds: max(0, newStart))
                    }
                }
            }
        }
        if selectedClipID == clipID {
            selectedClipID = nil
        }
    }

    func deleteSelectedClip() {
        guard let id = selectedClipID else { return }
        deleteClip(id)
    }

    // MARK: - Moving & trimming

    func moveClip(_ clipID: UUID, toStartSeconds proposedSeconds: Double) {
        let threshold = 8.0 / max(pixelsPerSecond, 1)
        let headSeconds = playheadSeconds
        performEdit { proj in
            guard let index = proj.clips.firstIndex(where: { $0.id == clipID }) else { return }
            let duration = proj.clips[index].timelineDuration.seconds
            let trackID = proj.clips[index].trackID
            let snapped = Self.snappedSeconds(
                proposedSeconds: proposedSeconds,
                duration: duration,
                excludingClipID: clipID,
                onTrack: trackID,
                project: proj,
                playheadSeconds: headSeconds,
                threshold: threshold
            )
            proj.clips[index].startTime = CodableTime(seconds: max(0, snapped))
        }
    }

    func trimClipStart(_ clipID: UUID, toSeconds proposedSeconds: Double) {
        performEdit { proj in
            guard let index = proj.clips.firstIndex(where: { $0.id == clipID }) else { return }
            let clip = proj.clips[index]
            let oldStart = clip.startTime.seconds
            let oldEnd = clip.endTime.seconds
            let oldSourceIn = clip.sourceInPoint.seconds

            var newStart = max(0, proposedSeconds)
            newStart = min(newStart, oldEnd - 0.05)

            let deltaSeconds = newStart - oldStart
            let newSourceIn = oldSourceIn + deltaSeconds * clip.speed
            guard newSourceIn >= 0 else { return }

            proj.clips[index].startTime = CodableTime(seconds: newStart)
            proj.clips[index].timelineDuration = CodableTime(seconds: oldEnd - newStart)
            proj.clips[index].sourceInPoint = CodableTime(seconds: newSourceIn)
        }
    }

    func trimClipEnd(_ clipID: UUID, toSeconds proposedSeconds: Double) {
        performEdit { proj in
            guard let index = proj.clips.firstIndex(where: { $0.id == clipID }) else { return }
            let clip = proj.clips[index]
            let mediaDuration = proj.mediaAsset(clip.mediaAssetID)?.duration.seconds
            let oldStart = clip.startTime.seconds

            var newEnd = max(proposedSeconds, oldStart + 0.05)

            if let mediaDuration {
                let newDuration = newEnd - oldStart
                let newSourceOut = clip.sourceInPoint.seconds + newDuration * clip.speed
                if newSourceOut > mediaDuration {
                    let clampedDuration = (mediaDuration - clip.sourceInPoint.seconds) / clip.speed
                    guard clampedDuration > 0.05 else { return }
                    newEnd = oldStart + clampedDuration
                }
            }

            proj.clips[index].timelineDuration = CodableTime(seconds: newEnd - oldStart)
        }
    }

    private static func snappedSeconds(
        proposedSeconds: Double,
        duration: Double,
        excludingClipID: UUID,
        onTrack trackID: UUID,
        project: Project,
        playheadSeconds: Double,
        threshold: Double
    ) -> Double {
        var candidates: [Double] = [playheadSeconds, 0]
        for clip in project.clips where clip.trackID == trackID && clip.id != excludingClipID {
            candidates.append(clip.startTime.seconds)
            candidates.append(clip.endTime.seconds)
        }

        let proposedEnd = proposedSeconds + duration
        var best = proposedSeconds
        var bestDelta = Double.greatestFiniteMagnitude

        for candidate in candidates {
            let deltaStart = abs(proposedSeconds - candidate)
            if deltaStart < threshold, deltaStart < bestDelta {
                best = candidate
                bestDelta = deltaStart
            }
            let deltaEnd = abs(proposedEnd - candidate)
            if deltaEnd < threshold, deltaEnd < bestDelta {
                best = candidate - duration
                bestDelta = deltaEnd
            }
        }

        return best
    }

    // MARK: - Transitions

    /// Sets (or clears) the cross-dissolve between a clip and whatever precedes it on
    /// the same track, sliding this clip - and rippling every later clip on the track -
    /// so the transition overlaps rather than eating into either clip's trim points.
    func setTransitionIn(_ clipID: UUID, transition: TransitionType) {
        performEdit { proj in
            guard let index = proj.clips.firstIndex(where: { $0.id == clipID }) else { return }
            let trackID = proj.clips[index].trackID
            let sortedOnTrack = proj.clips(on: trackID)
            guard let orderIndex = sortedOnTrack.firstIndex(where: { $0.id == clipID }), orderIndex > 0 else { return }

            let previous = sortedOnTrack[orderIndex - 1]
            let oldTransitionDuration = proj.clips[index].transitionIn.duration
            let currentStart = proj.clips[index].startTime.time
            let unshiftedStart = CMTimeAdd(currentStart, oldTransitionDuration)

            let maxAllowedOverlapSeconds = previous.timelineDuration.seconds * 0.9
            let clampedDurationSeconds = min(transition.duration.seconds, max(0, maxAllowedOverlapSeconds))
            let clampedDuration = CMTime(seconds: clampedDurationSeconds, preferredTimescale: 600)

            let newStart = CMTimeSubtract(unshiftedStart, clampedDuration)
            let deltaSeconds = CMTimeGetSeconds(newStart) - CMTimeGetSeconds(currentStart)

            proj.clips[index].startTime = CodableTime(newStart)
            proj.clips[index].transitionIn = transition

            for laterClip in sortedOnTrack[(orderIndex + 1)...] {
                guard let laterIndex = proj.clips.firstIndex(where: { $0.id == laterClip.id }) else { continue }
                let newLaterStart = proj.clips[laterIndex].startTime.seconds + deltaSeconds
                proj.clips[laterIndex].startTime = CodableTime(seconds: max(0, newLaterStart))
            }
        }
    }

    // MARK: - Per-clip property setters

    func setClipTransform(_ clipID: UUID, transform: ClipTransform) {
        performEdit { proj in
            guard let index = proj.clips.firstIndex(where: { $0.id == clipID }) else { return }
            proj.clips[index].transform = transform
        }
    }

    func setClipVolume(_ clipID: UUID, volume: Float) {
        performEdit { proj in
            guard let index = proj.clips.firstIndex(where: { $0.id == clipID }) else { return }
            proj.clips[index].volume = volume
        }
    }

    func setClipMuted(_ clipID: UUID, isMuted: Bool) {
        performEdit { proj in
            guard let index = proj.clips.firstIndex(where: { $0.id == clipID }) else { return }
            proj.clips[index].isMuted = isMuted
        }
    }

    func setClipFades(_ clipID: UUID, fadeInSeconds: Double, fadeOutSeconds: Double) {
        performEdit { proj in
            guard let index = proj.clips.firstIndex(where: { $0.id == clipID }) else { return }
            proj.clips[index].fadeIn = CodableTime(seconds: max(0, fadeInSeconds))
            proj.clips[index].fadeOut = CodableTime(seconds: max(0, fadeOutSeconds))
        }
    }

    func setClipSpeed(_ clipID: UUID, speed: Double) {
        performEdit { proj in
            guard let index = proj.clips.firstIndex(where: { $0.id == clipID }) else { return }
            let clip = proj.clips[index]
            let clampedSpeed = min(max(speed, 0.1), 4.0)
            let sourceDurationSeconds = clip.timelineDuration.seconds * clip.speed
            proj.clips[index].speed = clampedSpeed
            proj.clips[index].timelineDuration = CodableTime(seconds: sourceDurationSeconds / clampedSpeed)
        }
    }

    func updateTitleStyle(_ clipID: UUID, style: TitleStyle) {
        performEdit { proj in
            guard let index = proj.clips.firstIndex(where: { $0.id == clipID }) else { return }
            proj.clips[index].title = style
        }
    }

    /// Updates a clip's Audio FX settings, then schedules a debounced background render
    /// so live preview catches up shortly after the user stops adjusting - effects
    /// themselves only ever take effect via the cache `TimelineEngine.build` reads
    /// (see `AudioEffectsProcessor`), never inline during this edit.
    func setClipAudioEffects(_ clipID: UUID, effects: AudioEffects) {
        performEdit { proj in
            guard let index = proj.clips.firstIndex(where: { $0.id == clipID }) else { return }
            proj.clips[index].audioEffects = effects.isIdentity ? nil : effects
        }
        scheduleAudioEffectsPrewarm(clipID)
    }

    /// Updates a clip's Video FX settings. Unlike `setClipAudioEffects`, there's no
    /// prewarm/cache step to schedule: video effects are applied inline, every time,
    /// via a CALayer filter chain `TimelineEngine.build` attaches directly to the
    /// export-only `animationTool` (see `VideoEffects`'s doc comment) - there's no
    /// separate offline render to kick off in the background, so `performEdit`
    /// (which already triggers `rebuildPreview()`) is the whole job. Preview itself
    /// still won't show the effect (`animationTool` is export-only), matching the
    /// `.help()` caption in `InspectorView`'s Video FX section.
    func setClipVideoEffects(_ clipID: UUID, effects: VideoEffects) {
        performEdit { proj in
            guard let index = proj.clips.firstIndex(where: { $0.id == clipID }) else { return }
            proj.clips[index].videoEffects = effects.isIdentity ? nil : effects
        }
    }

    func renameClip(_ clipID: UUID, name: String) {
        performEdit { proj in
            guard let index = proj.clips.firstIndex(where: { $0.id == clipID }) else { return }
            proj.clips[index].displayName = name
        }
    }

    // MARK: - Tracks

    func addAudioTrack(named name: String = "Audio") {
        performEdit { proj in
            proj.tracks.append(Track(kind: .audio, name: name))
        }
    }

    func removeTrack(_ trackID: UUID) {
        performEdit { proj in
            proj.clips.removeAll { $0.trackID == trackID }
            proj.tracks.removeAll { $0.id == trackID }
        }
    }

    func toggleDuckingTarget(_ trackID: UUID) {
        performEdit { proj in
            guard let index = proj.tracks.firstIndex(where: { $0.id == trackID }) else { return }
            proj.tracks[index].isDuckingTarget.toggle()
        }
    }

    func toggleDuckingTrigger(_ trackID: UUID) {
        performEdit { proj in
            guard let index = proj.tracks.firstIndex(where: { $0.id == trackID }) else { return }
            proj.tracks[index].isDuckingTrigger.toggle()
        }
    }

    func setTrackVolume(_ trackID: UUID, volume: Float) {
        performEdit { proj in
            guard let index = proj.tracks.firstIndex(where: { $0.id == trackID }) else { return }
            proj.tracks[index].volume = volume
        }
    }

    func setTrackEnabled(_ trackID: UUID, isEnabled: Bool) {
        performEdit { proj in
            guard let index = proj.tracks.firstIndex(where: { $0.id == trackID }) else { return }
            proj.tracks[index].isEnabled = isEnabled
        }
    }

    // MARK: - Zoom

    func zoomIn() { pixelsPerSecond = min(pixelsPerSecond * 1.25, 400) }
    func zoomOut() { pixelsPerSecond = max(pixelsPerSecond / 1.25, 10) }

    // MARK: - Captions
    // Routed through `performEdit` (rather than mutated directly on `project`) so
    // hand-editing a generated transcript is undoable like any other edit.

    func updateCaptionSegment(_ segmentID: UUID, text: String, startSeconds: Double, endSeconds: Double) {
        performEdit { proj in
            guard let index = proj.captionSegments.firstIndex(where: { $0.id == segmentID }) else { return }
            proj.captionSegments[index].text = text
            proj.captionSegments[index].start = CodableTime(seconds: max(0, startSeconds))
            proj.captionSegments[index].end = CodableTime(seconds: max(startSeconds + 0.1, endSeconds))
        }
    }

    func deleteCaptionSegment(_ segmentID: UUID) {
        performEdit { proj in
            proj.captionSegments.removeAll { $0.id == segmentID }
        }
    }

    func addCaptionSegment(atSeconds seconds: Double) {
        performEdit { proj in
            let segment = CaptionSegment(
                text: "New caption",
                start: CodableTime(seconds: max(0, seconds)),
                end: CodableTime(seconds: max(0, seconds) + 2)
            )
            proj.captionSegments.append(segment)
        }
    }

    func setBurnInCaptions(_ enabled: Bool) {
        performEdit { proj in
            proj.burnInCaptions = enabled
        }
    }
}
